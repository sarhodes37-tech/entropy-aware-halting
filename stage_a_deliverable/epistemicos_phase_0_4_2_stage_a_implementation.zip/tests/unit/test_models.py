"""
Unit tests for epistemicos.models.
Targets edge cases in Popperian contracts, Bayesian updates, 
PermissionScope quarantine logic, CPR serialization, and Surprisal Sensors.
"""

import json
import math
import os
import sys
from typing import List, Dict, Any, Tuple
from datetime import datetime, timezone
import pytest
from epistemicos.models import (
    PopperianContract,
    BayesFactorUpdate,
    BeliefObject,
    PermissionScope,
    CanonicalProblemRepresentation,
    EpistemicStatus,
    BayesianBeliefKernel,
    TokenSurprisalSensor,
    _DEFAULT_QUARANTINE_SUBNETS,
    DEFAULT_REDACTION_KEYS,
    _estimate_payload_size
)

# ==========================================
# ESTIMATE PAYLOAD SIZE TESTS
# ==========================================

def test_estimate_payload_size_primitives():
    """Validates memory estimation for basic primitive types."""
    assert _estimate_payload_size(1) == sys.getsizeof(1)
    assert _estimate_payload_size("test") == sys.getsizeof("test")
    assert _estimate_payload_size(True) == sys.getsizeof(True)
    assert _estimate_payload_size(None) == sys.getsizeof(None)


def test_estimate_payload_size_collections():
    """Validates memory estimation for basic collections without nesting."""
    lst = [1, 2, 3]
    expected_lst = sys.getsizeof(lst) + sys.getsizeof(1) + sys.getsizeof(2) + sys.getsizeof(3)
    assert _estimate_payload_size(lst) == expected_lst

    tpl = (1, 2)
    expected_tpl = sys.getsizeof(tpl) + sys.getsizeof(1) + sys.getsizeof(2)
    assert _estimate_payload_size(tpl) == expected_tpl

    st = {1, 2}
    expected_st = sys.getsizeof(st) + sys.getsizeof(1) + sys.getsizeof(2)
    assert _estimate_payload_size(st) == expected_st


def test_estimate_payload_size_nested_dict():
    """Validates memory estimation for nested dictionaries."""
    d = {"a": 1, "b": {"c": 2}}

    expected_size = sys.getsizeof(d)
    expected_size += sys.getsizeof("a") + sys.getsizeof(1)
    expected_size += sys.getsizeof("b")

    inner_d = d["b"]
    expected_size += sys.getsizeof(inner_d)
    expected_size += sys.getsizeof("c") + sys.getsizeof(2)

    assert _estimate_payload_size(d) == expected_size


def test_estimate_payload_size_circular_reference():
    """Validates that circular references do not cause infinite recursion and are sized correctly."""
    lst = [1, 2]
    lst.append(lst) # Circular reference

    # Size should be size of list + size of 1 + size of 2 + 0 (since lst is already seen)
    expected_size = sys.getsizeof(lst) + sys.getsizeof(1) + sys.getsizeof(2)
    assert _estimate_payload_size(lst) == expected_size

    d = {"a": 1}
    d["self"] = d # Circular reference

    # Size should be size of d + size of "a" + size of 1 + size of "self" + 0
    expected_size_d = sys.getsizeof(d) + sys.getsizeof("a") + sys.getsizeof(1) + sys.getsizeof("self")
    assert _estimate_payload_size(d) == expected_size_d


# ==========================================
# TOKEN SURPRISAL SENSOR TESTS
# ==========================================
def test_token_surprisal_sensor_empty_logprobs():
    """Validates safe handling of empty telemetry streams."""
    sensor = TokenSurprisalSensor()
    assert sensor.compute_z_scores([]) == []


def test_token_surprisal_sensor_warmup_period_anomaly():
    """Validates that initial token logprobs (index 0 and 1) are evaluated against baseline_prior_surprisal."""
    sensor = TokenSurprisalSensor(z_threshold=2.85, baseline_prior_surprisal=1.0, baseline_prior_std=1.0, std_floor=0.05)

    # Low surprisal initial tokens (-0.1 -> surprisal 0.1, z = (0.1 - 1.0)/1.0 = -0.9)
    z_scores_low = sensor.compute_z_scores([-0.1, -0.2])
    assert len(z_scores_low) == 2
    assert z_scores_low[0] < sensor.z_threshold
    assert z_scores_low[1] < sensor.z_threshold


def test_token_surprisal_extreme_anomaly_at_index_0():
    """Validates that extreme surprisal at token index 0 (during warm-up) is flagged."""
    sensor = TokenSurprisalSensor(z_threshold=2.85)
    result = sensor.evaluate([-25.0, -0.1, -0.1])
    assert result["passed"] is False
    assert result["flagged_tokens"] >= 1
    assert result["token_z_scores"][0] > sensor.z_threshold


def test_token_surprisal_extreme_anomaly_at_index_1():
    """Validates that extreme surprisal at token index 1 (during warm-up) is flagged."""
    sensor = TokenSurprisalSensor(z_threshold=2.85)
    result = sensor.evaluate([-0.1, -25.0, -0.1])
    assert result["passed"] is False
    assert result["flagged_tokens"] >= 1
    assert result["token_z_scores"][1] > sensor.z_threshold


def test_token_surprisal_extreme_anomaly_after_warmup():
    """Validates that extreme surprisal after the warm-up period (index >= 2) is flagged."""
    sensor = TokenSurprisalSensor(z_threshold=2.85)
    result = sensor.evaluate([-0.1, -0.1, -25.0, -0.1])
    assert result["passed"] is False
    assert result["flagged_tokens"] >= 1
    assert result["token_z_scores"][2] > sensor.z_threshold


def test_token_surprisal_ordinary_tokens_not_flagged():
    """Validates that ordinary, low-surprisal tokens throughout the sequence are not flagged."""
    sensor = TokenSurprisalSensor(z_threshold=2.85)
    result = sensor.evaluate([-0.1, -0.2, -0.15, -0.1, -0.2, -0.1])
    assert result["passed"] is True
    assert result["flagged_tokens"] == 0
    assert result["max_z_score"] < sensor.z_threshold


# ==========================================
# BAYESIAN BELIEF KERNEL TESTS
# ==========================================
def test_bayesian_belief_kernel_update_and_map():
    """Validates posterior normalization and MAP estimation in the core kernel."""
    priors = {"H_SAFE": 0.6, "H_COMPROMISED": 0.4}
    kernel = BayesianBeliefKernel(prior_probabilities=priors)

    # Evidence strongly suggests compromise
    likelihoods = {"H_SAFE": 0.2, "H_COMPROMISED": 0.8}
    
    posteriors = kernel.update_beliefs(likelihoods)
    
    # Unnormalized: H_SAFE = 0.6 * 0.2 = 0.12. H_COMPROMISED = 0.4 * 0.8 = 0.32
    # Total evidence = 0.44
    # Normalized: 0.12/0.44 = 0.2727..., 0.32/0.44 = 0.7272...
    assert math.isclose(posteriors["H_SAFE"], 0.27272727, rel_tol=1e-5)
    assert math.isclose(posteriors["H_COMPROMISED"], 0.72727272, rel_tol=1e-5)
    
    assert kernel.get_map_estimate() == "H_COMPROMISED"


# ==========================================
# POPPERIAN CONTRACT TESTS
# ==========================================
@pytest.mark.parametrize("operator, observed, threshold, expected", [
    (">", 10.0, 5.0, True),
    ("<", 3.0, 5.0, True),
    (">=", 5.0, 5.0, True),
    ("<=", 5.0, 5.0, True),
    ("==", 5.0, 5.0, True),
    ("!=", 6.0, 5.0, True),
    (">", 4.0, 5.0, False),
    ("==", 6.0, 5.0, False),
])
def test_popperian_contract_evaluate_falsification(operator, observed, threshold, expected):
    """Validates all mathematical operators in the falsification contract."""
    contract = PopperianContract(
        claim_id="claim_001",
        target_metric="loss_ratio",
        falsification_threshold=threshold,
        comparison_operator=operator,
        observation_window_days=30,
        falsification_impact_posterior=0.1
    )
    assert contract.evaluate_falsification(observed) == expected


def test_popperian_contract_unsupported_operator():
    """Validates error handling for invalid operators."""
    contract = PopperianContract(
        claim_id="claim_002",
        target_metric="loss_ratio",
        falsification_threshold=5.0,
        comparison_operator=">>",
        observation_window_days=30
    )
    with pytest.raises(ValueError, match="Unsupported comparison operator"):
        contract.evaluate_falsification(10.0)


# ==========================================
# BELIEF OBJECT TESTS
# ==========================================
def test_bayes_factor_update_computation():
    """Validates the Pydantic validator computes Bayes factors correctly."""
    update = BayesFactorUpdate(
        evidence_id="ev_001",
        source_provenance=["log_a"],
        p_evidence_given_hypothesis=0.8,
        p_evidence_given_not_hypothesis=0.2
    )
    assert update.bayes_factor == 4.0
    assert update.bayes_factor_db == 6.02


def test_belief_object_update_and_falsify():
    """Validates posterior math and status state transitions."""
    contract = PopperianContract(
        claim_id="claim_003",
        target_metric="latency",
        falsification_threshold=200.0,
        comparison_operator=">",
        observation_window_days=7,
        falsification_impact_posterior=0.01
    )
    
    belief = BeliefObject(
        belief_id="bel_001",
        cpr_frame_id="cpr_001",
        assertion="System is stable",
        prior_probability=0.5,
        current_posterior=0.5,
        popp_contract=contract
    )

    update = BayesFactorUpdate(
        evidence_id="ev_002",
        source_provenance=["telemetry"],
        p_evidence_given_hypothesis=0.9,
        p_evidence_given_not_hypothesis=0.1
    )
    belief.update_belief(update)
    assert belief.current_posterior == 0.9
    assert len(belief.evidence_ledger) == 1

    # Apply Falsification (True branch)
    falsified = belief.check_and_apply_falsification(250.0)
    assert falsified is True
    assert belief.status == EpistemicStatus.FALSIFIED
    assert belief.current_posterior == 0.01


def test_belief_object_falsification_safe_bounds():
    """Validates the negative branch when observation remains within safe parameters."""
    contract = PopperianContract(
        claim_id="claim_004",
        target_metric="latency",
        falsification_threshold=200.0,
        comparison_operator=">",
        observation_window_days=7
    )
    belief = BeliefObject(
        belief_id="bel_002",
        cpr_frame_id="cpr_002",
        assertion="System stable",
        prior_probability=0.5,
        current_posterior=0.5,
        popp_contract=contract
    )
    
    # Metric is 150 (Safe, does not breach > 200 threshold)
    falsified = belief.check_and_apply_falsification(150.0)
    assert falsified is False
    assert belief.status == EpistemicStatus.UNVERIFIED


# ==========================================
# PERMISSION SCOPE TESTS
# ==========================================
def test_permission_scope_quarantine_rmm_mutating_action():
    """Validates RMM origin flag blocks mutating operations like 'update_db'."""
    scope = PermissionScope(
        allowed_operations=["read", "update_db"],
        is_rmm_origin=True
    )
    assert scope.is_quarantined_channel() is True
    assert scope.validate_action({"op": "update_db"}) is False
    assert scope.validate_action({"op": "read"}) is True


def test_permission_scope_quarantine_subnet_mutating_action():
    """Validates subnet prefix matching blocks mutating operations."""
    scope = PermissionScope(
        allowed_operations=["read", "issue_binder"],
        origin_subnet="10.240.5.15",
        quarantine_subnets=["10.240."]
    )
    assert scope.is_quarantined_channel() is True
    assert scope.validate_action({"op": "issue_binder"}) is False


def test_permission_scope_clean_internal_subnet():
    """Validates safe internal subnets bypass the quarantine lock."""
    scope = PermissionScope(
        allowed_operations=["read", "issue_binder"],
        origin_subnet="192.168.1.150"
    )
    assert scope.is_quarantined_channel() is False
    assert scope.validate_action({"op": "issue_binder"}) is True


def test_permission_scope_validate_egress_valid_payload():
    """Validates egress allowed when payload size and row count are within limits."""
    scope = PermissionScope(max_payload_bytes=4096, max_row_count=10)
    payload = {"data": [1, 2, 3]}
    assert scope.validate_egress(payload) is True


def test_permission_scope_validate_egress_exceeds_payload_bytes():
    """Validates egress blocked when payload size exceeds max_payload_bytes."""
    scope = PermissionScope(max_payload_bytes=50, max_row_count=10)
    payload = {"data": "x" * 100}
    assert scope.validate_egress(payload) is False


def test_permission_scope_validate_egress_exceeds_row_count_list():
    """Validates egress blocked when nested list size exceeds max_row_count."""
    scope = PermissionScope(max_payload_bytes=4096, max_row_count=5)
    payload = {"data": [1, 2, 3, 4, 5, 6]}
    assert scope.validate_egress(payload) is False


def test_permission_scope_validate_egress_exceeds_row_count_dict():
    """Validates egress blocked when nested dict keys exceed max_row_count."""
    scope = PermissionScope(max_payload_bytes=4096, max_row_count=3)
    payload = {"a": 1, "b": {"c": 2, "d": 3, "e": 4, "f": 5}}
    assert scope.validate_egress(payload) is False


# ==========================================
# CPR SERIALIZATION TESTS
# ==========================================
def test_cpr_serialize_fleet_data():
    """Validates metric extraction when fleet_data is present."""
    cpr = CanonicalProblemRepresentation(
        policy_id="POL-123",
        fleet_data={
            "vehicle_count": 500,
            "operating_radius_miles": 2500,
            "loss_modifier": 1.25
        }
    )
    assert cpr.serialize_for_belief_kernel() == [5.0, 2.5, 1.25]


def test_cpr_serialize_risk_details():
    """Validates metric extraction when risk_details is present (fallback)."""
    cpr = CanonicalProblemRepresentation(
        policy_id="POL-124",
        primary_metric=0.85,
        risk_details={
            "loss_ratio_3yr": 0.95
        }
    )
    assert cpr.serialize_for_belief_kernel() == [0.85, 0.95]


def test_cpr_serialize_empty():
    """Validates default empty state serialization."""
    cpr = CanonicalProblemRepresentation(policy_id="POL-125")
    assert cpr.serialize_for_belief_kernel() == [0.0, 0.0, 0.0]

def test_token_surprisal_sensor_evaluate_integration_passed():
    """Validates the evaluate method using the real compute_z_scores when values pass."""
    sensor = TokenSurprisalSensor(z_threshold=2.85, window_size=10, std_floor=0.05)
    # Log probabilities representing normal, expected tokens (low surprisal/high probability)
    # Using logprobs close to 0, meaning very high probability.
    logprobs = [-0.1, -0.15, -0.2, -0.1, -0.15, -0.2, -0.1, -0.15, -0.2, -0.1, -0.1]

    result = sensor.evaluate(logprobs)

    assert result["passed"] is True
    assert result["flagged_tokens"] == 0
    assert result["max_z_score"] < 2.85
    assert len(result["token_z_scores"]) == len(logprobs)

def test_token_surprisal_sensor_evaluate_integration_flagged():
    """Validates the evaluate method using the real compute_z_scores when an anomaly occurs."""
    sensor = TokenSurprisalSensor(z_threshold=2.85, window_size=10, std_floor=0.05)
    # Log probabilities representing normal tokens followed by a highly surprising one (large negative logprob)
    logprobs = [-0.1, -0.15, -0.2, -0.1, -0.15, -0.2, -0.1, -0.15, -0.2, -0.1, -5.0]

    result = sensor.evaluate(logprobs)

    assert result["passed"] is False
    assert result["flagged_tokens"] > 0
    assert result["max_z_score"] > 2.85
    assert len(result["token_z_scores"]) == len(logprobs)


@pytest.mark.parametrize("non_finite_val", [float('nan'), float('inf'), float('-inf')])
def test_token_surprisal_sensor_evaluate_non_finite_z_scores(monkeypatch, non_finite_val):
    """Validates that NaN, +inf, and -inf Z-scores are rejected as malformed numerical output and sanitized for JSON."""
    sensor = TokenSurprisalSensor(z_threshold=2.85)

    # Mock compute_z_scores to simulate a computation producing a non-finite Z-score
    monkeypatch.setattr(sensor, "compute_z_scores", lambda logprobs: [0.0, non_finite_val, 1.2])

    result = sensor.evaluate([-0.1, -0.2, -0.3])

    assert result["passed"] is False
    assert result["reason"] == "MALFORMED_NON_FINITE_LOGPROBS"
    assert "Derived Z-scores contain 1 non-finite value(s)" in result["error"]
    assert result["max_z_score"] == 0.0
    assert result["flagged_tokens"] == 3
    assert result["token_z_scores"] == [0.0, None, 1.2]
    # Ensure JSON serializability without allow_nan
    serialized = json.dumps(result, allow_nan=False)
    assert "null" in serialized


@pytest.mark.parametrize("non_finite_lp", [float('nan'), float('inf'), float('-inf')])
def test_token_surprisal_sensor_evaluate_malformed_non_finite_logprob(non_finite_lp):
    """Validates that NaN, +inf, and -inf input logprobs trigger ValueError handling and return failure."""
    sensor = TokenSurprisalSensor(z_threshold=2.85)
    result = sensor.evaluate([non_finite_lp, -0.5])

    assert result["passed"] is False
    assert result["reason"] == "MALFORMED_NON_FINITE_LOGPROBS"
    assert result["max_z_score"] == 0.0
    assert result["flagged_tokens"] == 2


def test_token_surprisal_ramping_evasion_blocked_by_ceiling():
    """Validates that smooth surprisal ramping that breaches max_surprisal_ceiling is flagged."""
    sensor = TokenSurprisalSensor(z_threshold=2.85, window_size=10, max_surprisal_ceiling=10.0)

    # Base low surprisals (around 1.0)
    base = [1.0, 1.5, 0.8, 1.4, 0.9, 1.6, 0.7, 1.3, 0.8, 1.2]
    # Gradually ramp surprisal up to 15.0 with step size 0.15 so Z-score stays low
    ramp = [1.2 + 0.15 * i for i in range(1, 100)]
    logprobs = [-x for x in (base + ramp)]

    result = sensor.evaluate(logprobs)
    assert result["passed"] is False
    assert result["flagged_tokens"] > 0


# ==========================================
# MODEL SERIALIZATION & DEFAULTS TESTS
# ==========================================

def test_permission_scope_defaults_and_isolation():
    """Validates PermissionScope defaults, quarantine subnet env-awareness, and mutable list isolation."""
    scope1 = PermissionScope()
    assert scope1.allowed_resources == []
    assert scope1.allowed_operations == []
    assert scope1.origin_subnet is None
    assert scope1.quarantine_subnets == list(_DEFAULT_QUARANTINE_SUBNETS)

    scope2 = PermissionScope()
    # Mutate scope1 lists and verify scope2 is isolated
    scope1.allowed_resources.append("res_1")
    scope1.allowed_operations.append("op_1")
    scope1.quarantine_subnets.append("10.99.")

    assert scope2.allowed_resources == []
    assert scope2.allowed_operations == []
    assert scope2.quarantine_subnets == list(_DEFAULT_QUARANTINE_SUBNETS)


def test_belief_object_defaults_and_isolation():
    """Validates BeliefObject default fields and mutable list isolation."""
    contract = PopperianContract(
        claim_id="claim_def",
        target_metric="metric_def",
        falsification_threshold=10.0,
        comparison_operator=">",
        observation_window_days=7
    )
    b1 = BeliefObject(
        belief_id="bel_def1",
        cpr_frame_id="cpr_def1",
        assertion="Default belief assertions",
        prior_probability=0.5,
        current_posterior=0.5,
        popp_contract=contract
    )
    assert b1.status == EpistemicStatus.UNVERIFIED
    assert b1.evidence_ledger == []
    assert b1.invalidation_triggers == []

    b2 = BeliefObject(
        belief_id="bel_def2",
        cpr_frame_id="cpr_def2",
        assertion="Second belief assertion",
        prior_probability=0.5,
        current_posterior=0.5,
        popp_contract=contract
    )
    # Mutate b1 lists and verify b2 remains isolated
    b1.evidence_ledger.append(
        BayesFactorUpdate(
            evidence_id="ev_mut",
            source_provenance=["src"],
            p_evidence_given_hypothesis=0.8,
            p_evidence_given_not_hypothesis=0.2
        )
    )
    b1.invalidation_triggers.append("trigger_1")

    assert b2.evidence_ledger == []
    assert b2.invalidation_triggers == []


def test_popperian_contract_serialization():
    """Validates PopperianContract dict/JSON serialization and round-trip deserialization."""
    contract = PopperianContract(
        claim_id="claim_001",
        target_metric="loss_ratio",
        falsification_threshold=5.0,
        comparison_operator=">",
        observation_window_days=30,
        falsification_impact_posterior=0.05
    )
    data_dict = contract.model_dump(mode="json")
    assert data_dict == {
        "claim_id": "claim_001",
        "target_metric": "loss_ratio",
        "falsification_threshold": 5.0,
        "comparison_operator": ">",
        "observation_window_days": 30,
        "falsification_impact_posterior": 0.05
    }

    json_str = contract.model_dump_json()
    parsed_json = json.loads(json_str)
    assert parsed_json["claim_id"] == "claim_001"
    assert parsed_json["falsification_threshold"] == 5.0

    restored = PopperianContract.model_validate_json(json_str)
    assert restored == contract


def test_bayes_factor_update_serialization():
    """Validates BayesFactorUpdate dict/JSON serialization and round-trip verification of computed fields."""
    update = BayesFactorUpdate(
        evidence_id="ev_001",
        source_provenance=["log_a", "log_b"],
        p_evidence_given_hypothesis=0.8,
        p_evidence_given_not_hypothesis=0.2
    )
    # Check computed fields on original instance
    assert update.bayes_factor == 4.0
    assert update.bayes_factor_db == 6.02

    data_dict = update.model_dump(mode="json")
    assert data_dict["evidence_id"] == "ev_001"
    assert data_dict["source_provenance"] == ["log_a", "log_b"]
    assert data_dict["bayes_factor"] == 4.0
    assert data_dict["bayes_factor_db"] == 6.02

    json_str = update.model_dump_json()
    parsed = json.loads(json_str)
    assert parsed["p_evidence_given_hypothesis"] == 0.8
    assert parsed["p_evidence_given_not_hypothesis"] == 0.2
    assert parsed["bayes_factor"] == 4.0
    assert parsed["bayes_factor_db"] == 6.02

    # Restore from JSON and explicitly verify both computed fields and underlying likelihoods
    restored = BayesFactorUpdate.model_validate_json(json_str)
    assert restored == update
    assert restored.p_evidence_given_hypothesis == 0.8
    assert restored.p_evidence_given_not_hypothesis == 0.2
    assert restored.bayes_factor == 4.0
    assert restored.bayes_factor_db == 6.02


def test_belief_object_nested_serialization_and_datetime_roundtrip():
    """Validates BeliefObject nested serialization with PopperianContract, BayesFactorUpdate list, EpistemicStatus enum, and datetime instant preservation."""
    # Deterministic, timezone-aware datetime
    fixed_time = datetime(2026, 5, 15, 14, 30, 0, 123456, tzinfo=timezone.utc)
    contract = PopperianContract(
        claim_id="claim_100",
        target_metric="error_rate",
        falsification_threshold=0.01,
        comparison_operator=">=",
        observation_window_days=14,
        falsification_impact_posterior=0.0
    )
    update = BayesFactorUpdate(
        evidence_id="ev_100",
        source_provenance=["provenance_trace_1"],
        p_evidence_given_hypothesis=0.9,
        p_evidence_given_not_hypothesis=0.1
    )
    belief = BeliefObject(
        belief_id="bel_100",
        cpr_frame_id="cpr_100",
        assertion="Unicórniö test assertióñ with unicode",
        prior_probability=0.5,
        current_posterior=0.9,
        status=EpistemicStatus.CONFIRMED,
        evidence_ledger=[update],
        popp_contract=contract,
        created_at=fixed_time,
        ttl_days=90,
        invalidation_triggers=["trigger_alpha", "trigger_beta"]
    )

    data_dict = belief.model_dump(mode="json")
    assert data_dict["belief_id"] == "bel_100"
    assert data_dict["status"] == "CONFIRMED"
    assert isinstance(data_dict["created_at"], str)
    assert data_dict["created_at"].startswith("2026-05-15T14:30:00")
    assert data_dict["popp_contract"]["claim_id"] == "claim_100"
    assert len(data_dict["evidence_ledger"]) == 1
    assert data_dict["evidence_ledger"][0]["bayes_factor"] == 9.0

    json_str = belief.model_dump_json()
    parsed = json.loads(json_str)
    assert parsed["status"] == "CONFIRMED"
    assert parsed["popp_contract"]["comparison_operator"] == ">="
    assert parsed["assertion"] == "Unicórniö test assertióñ with unicode"

    restored = BeliefObject.model_validate_json(json_str)
    assert restored.belief_id == belief.belief_id
    assert restored.status == EpistemicStatus.CONFIRMED
    assert restored.popp_contract == contract
    assert restored.evidence_ledger[0] == update
    # Verify exact datetime instant preservation
    assert restored.created_at == fixed_time
    assert restored.created_at.timestamp() == fixed_time.timestamp()


def test_permission_scope_serialization_and_defaults():
    """Validates PermissionScope serialization with custom subnets, defaults, and optional fields."""
    scope = PermissionScope(
        allowed_resources=["res_a", "res_b"],
        allowed_operations=["read"],
        expires_at=1700000000.0,
        max_attempts=5,
        attempt_count=2,
        origin_subnet="10.0.0.1",
        is_rmm_origin=False,
        quarantine_subnets=["10.240.", "172.16."]
    )

    data_dict = scope.model_dump(mode="json")
    assert data_dict["allowed_resources"] == ["res_a", "res_b"]
    assert data_dict["expires_at"] == 1700000000.0
    assert data_dict["origin_subnet"] == "10.0.0.1"
    assert data_dict["quarantine_subnets"] == ["10.240.", "172.16."]

    json_str = scope.model_dump_json()
    parsed = json.loads(json_str)
    assert parsed["max_attempts"] == 5

    restored = PermissionScope.model_validate_json(json_str)
    assert restored == scope


def test_cpr_nested_serialization_fidelity_and_excluded_fields():
    """
    Validates CanonicalProblemRepresentation nested serialization fidelity.
    Confirms model serialization preserves raw_payload fidelity as-is (including sensitive keys)
    and excludes class attribute SENSITIVE_FIELDS.
    """
    scope = PermissionScope(
        allowed_resources=["logistics_db"],
        allowed_operations=["read"]
    )
    cpr = CanonicalProblemRepresentation(
        policy_id="POL-999",
        raw_payload={"user_id": 123, "API_KEY": "synthetic_key_xyz", "account_number": "ACC-9999"},
        fleet_data={"vehicle_count": 200, "operating_radius_miles": 500, "loss_modifier": 1.1},
        risk_details={"loss_mod": 1.1},
        primary_metric=42.0,
        scope=scope
    )

    # Ordinary model serialization preserves raw_payload intact
    data_dict = cpr.model_dump(mode="json")
    assert data_dict["policy_id"] == "POL-999"
    assert data_dict["raw_payload"] == {"user_id": 123, "API_KEY": "synthetic_key_xyz", "account_number": "ACC-9999"}
    assert data_dict["fleet_data"]["vehicle_count"] == 200
    assert data_dict["scope"]["allowed_resources"] == ["logistics_db"]

    # Verify class attribute SENSITIVE_FIELDS is excluded from model output fields
    assert "SENSITIVE_FIELDS" not in data_dict

    json_str = cpr.model_dump_json()
    parsed = json.loads(json_str)
    assert parsed["primary_metric"] == 42.0
    assert "SENSITIVE_FIELDS" not in parsed

    restored = CanonicalProblemRepresentation.model_validate_json(json_str)
    assert restored.policy_id == cpr.policy_id
    assert restored.raw_payload == cpr.raw_payload
    assert restored.fleet_data == cpr.fleet_data
    assert restored.scope.allowed_resources == ["logistics_db"]


def test_cpr_mask_egress_payload_redaction():
    """
    Validates CanonicalProblemRepresentation.mask_egress_payload contract.
    Egress masking is separate from model serialization, performing top-level key redaction.
    Tests case-insensitive key matching against DEFAULT_REDACTION_KEYS, custom redaction keys,
    and preservation of benign top-level keys.
    """
    cpr = CanonicalProblemRepresentation(
        policy_id="POL-EGR-1",
        raw_payload={
            "User_ID": "usr_777",
            "API_KEY": "synthetic_secret_1",
            "Token": "synthetic_token_2",
            "Password": "synthetic_password_3",
            "SECRET": "synthetic_secret_4",
            "Organization": "Acme Corp",
            "nested_data": {"api_key": "nested_value_remains_unfiltered"}
        }
    )

    # 1. Default egress masking using DEFAULT_REDACTION_KEYS (case-insensitive top-level check)
    masked_default = cpr.mask_egress_payload()
    assert masked_default == {
        "User_ID": "usr_777",
        "Organization": "Acme Corp",
        "nested_data": {"api_key": "nested_value_remains_unfiltered"}
    }
    assert "API_KEY" not in masked_default
    assert "Token" not in masked_default
    assert "Password" not in masked_default
    assert "SECRET" not in masked_default

    # 2. Custom egress masking policy
    custom_keys = frozenset({"user_id", "organization"})
    masked_custom = cpr.mask_egress_payload(custom_redactions=custom_keys)
    assert masked_custom == {
        "API_KEY": "synthetic_secret_1",
        "Token": "synthetic_token_2",
        "Password": "synthetic_password_3",
        "SECRET": "synthetic_secret_4",
        "nested_data": {"api_key": "nested_value_remains_unfiltered"}
    }
    assert "User_ID" not in masked_custom
    assert "Organization" not in masked_custom

    # 3. Model raw_payload itself is unchanged by mask_egress_payload()
    assert "API_KEY" in cpr.raw_payload


# ==========================================
# SURPRISAL SENSOR NUMERICAL STABILITY & EQUIVALENCE TESTS
# ==========================================

def _pre_pr_compute_z_scores(sensor, logprobs):
    """Isolated reference implementation matching the exact pre-PR implementation."""
    if not logprobs:
        return []

    sanitized_logprobs = []
    for i, lp in enumerate(logprobs):
        if type(lp) in (float, int):
            if math.isnan(lp) or math.isinf(lp):
                raise ValueError(f"Malformed or non-finite logprob encountered at index {i}: {lp}")
            sanitized_logprobs.append(float(lp))
        else:
            try:
                val = float(lp)
                if math.isnan(val) or math.isinf(val):
                    raise ValueError(f"Malformed or non-finite logprob encountered at index {i}: {val}")
                sanitized_logprobs.append(val)
            except (TypeError, ValueError) as e:
                raise ValueError(f"Malformed or non-finite logprob encountered at index {i}: {lp}") from e

    surprisals = [-lp for lp in sanitized_logprobs]
    z_scores = []

    sum_x = 0.0
    sum_sq = 0.0

    for i, h in enumerate(surprisals):
        if i < 2:
            std_prior = max(sensor.baseline_prior_std, sensor.std_floor)
            z_scores.append(float((h - sensor.baseline_prior_surprisal) / std_prior))
            sum_x += h
            sum_sq += h * h
            continue

        n = min(i, sensor.window_size)
        mean_h = sum_x / n
        variance = (sum_sq / n) - (mean_h * mean_h)
        if variance < 0.0:
            variance = 0.0

        std_h = max(math.sqrt(variance), sensor.std_floor)
        z_scores.append(float((h - mean_h) / std_h))

        sum_x += h
        sum_sq += h * h

        if i >= sensor.window_size:
            old_val = surprisals[i - sensor.window_size]
            sum_x -= old_val
            sum_sq -= old_val * old_val

    return z_scores


def test_surprisal_sensor_intermediate_overflow_nan_preservation():
    """
    Priority 1 & 2: Validates that arithmetic overflow in running sum-of-squares (producing inf - inf = nan)
    correctly propagates NaN z-scores and triggers evaluate() fail-closed rejection.
    """
    sensor = TokenSurprisalSensor(window_size=2)
    # 1e200 squared overflows float to inf. When sliding window subtracts 1e200^2, inf - inf produces nan.
    overflow_logprobs = [-1e200, -1.0, -1.0, -1.0]

    z_scores_opt = sensor.compute_z_scores(overflow_logprobs)
    z_scores_ref = _pre_pr_compute_z_scores(sensor, overflow_logprobs)

    assert len(z_scores_opt) == len(z_scores_ref) == 4
    for opt, ref in zip(z_scores_opt, z_scores_ref):
        if math.isnan(ref):
            assert math.isnan(opt), f"Expected NaN propagation, got {opt}"
        else:
            assert opt == ref

    # Verify evaluate() rejects non-finite derived scores
    eval_result = sensor.evaluate(overflow_logprobs)
    assert eval_result["passed"] is False
    assert eval_result["reason"] == "MALFORMED_NON_FINITE_LOGPROBS"
    assert "Derived Z-scores contain" in eval_result["error"]


def test_surprisal_sensor_non_finite_baseline_prior_std():
    """
    Priority 1: Validates that non-finite baseline_prior_std (e.g. NaN) is preserved
    in warm-up token z-scores rather than silently masked by std_floor.
    """
    nan_sensor = TokenSurprisalSensor(baseline_prior_std=float("nan"))
    z_scores = nan_sensor.compute_z_scores([-0.5, -0.5, -0.5])
    assert math.isnan(z_scores[0])
    assert math.isnan(z_scores[1])

    eval_res = nan_sensor.evaluate([-0.5, -0.5, -0.5])
    assert eval_res["passed"] is False
    assert eval_res["reason"] == "MALFORMED_NON_FINITE_LOGPROBS"


def test_surprisal_sensor_signed_zero_and_equality_preservation():
    """
    Validates first-argument-on-equality semantics including signed zero (-0.0 vs 0.0),
    std_floor=0.0, infinities, and NaNs matching Python max(a, b).
    """
    # 1. ZeroDivisionError exception equivalence on std_floor=0.0 and baseline_prior_std=-0.0
    s_neg_zero = TokenSurprisalSensor(std_floor=0.0, baseline_prior_std=-0.0, baseline_prior_surprisal=0.0)
    with pytest.raises(ZeroDivisionError):
        s_neg_zero.compute_z_scores([-1.0])

    with pytest.raises(ZeroDivisionError):
        _pre_pr_compute_z_scores(s_neg_zero, [-1.0])

    # 2. Test floor comparisons across all operand combinations
    operand_pairs = [
        (-0.0, 0.0),
        (0.0, -0.0),
        (-0.0, -0.0),
        (0.0, 0.0),
        (float("nan"), 0.05),
        (0.05, float("nan")),
        (float("inf"), 0.05),
        (-float("inf"), 0.05),
        (0.05, float("inf")),
        (0.05, -float("inf")),
        (float("nan"), float("nan")),
        (1.0, 1.0),
        (1.0, 2.0),
        (2.0, 1.0),
    ]

    for a, b in operand_pairs:
        # Pre-PR Python max(a, b) behavior
        expected = max(a, b)
        # Optimized conditional floor expression: b if b > a else a
        actual = b if b > a else a

        if math.isnan(expected):
            assert math.isnan(actual), f"Failed for pair ({a}, {b})"
        elif math.isinf(expected):
            assert actual == expected, f"Failed for pair ({a}, {b})"
        else:
            assert actual == expected, f"Failed for pair ({a}, {b})"
            assert math.copysign(1.0, actual) == math.copysign(1.0, expected), f"Signed zero mismatch for pair ({a}, {b})"


def test_surprisal_sensor_differential_equivalence_exhaustive():
    """
    Priority 2: Differential testing against pre-PR implementation across configurations,
    types, and edge cases.
    """
    test_configs = [
        {"window_size": 1, "std_floor": 0.05, "baseline_prior_std": 1.0, "baseline_prior_surprisal": 1.0},
        {"window_size": 5, "std_floor": 0.1, "baseline_prior_std": 2.0, "baseline_prior_surprisal": 0.5},
        {"window_size": 20, "std_floor": 0.001, "baseline_prior_std": 0.5, "baseline_prior_surprisal": 1.5},
    ]

    class CustomFloat(float):
        pass

    class CustomInt(int):
        pass

    test_sequences = [
        [],  # Empty
        [-0.1],  # Length 1
        [-0.1, -0.2],  # Length 2
        [-0.5, -0.25, -0.1, -0.05, -0.8, -1.2, -0.3],  # Typical
        [CustomFloat(-0.2), CustomInt(-1), -0.5],  # Custom numeric subclasses
        ["-0.3", "-0.7", "-0.1"],  # String float-convertible
        [-1e50, -2e50, -1e50, -5e50],  # Large-magnitude finite
        [-1e200, -1.0, -1.0, -1.0],  # Intermediate overflow
    ]

    for cfg in test_configs:
        sensor = TokenSurprisalSensor(**cfg)
        for seq in test_sequences:
            opt = sensor.compute_z_scores(seq)
            ref = _pre_pr_compute_z_scores(sensor, seq)

            assert len(opt) == len(ref)
            for val_opt, val_ref in zip(opt, ref):
                if math.isnan(val_ref):
                    assert math.isnan(val_opt)
                elif math.isinf(val_ref):
                    assert val_opt == val_ref
                else:
                    assert math.isclose(val_opt, val_ref, rel_tol=1e-12, abs_tol=1e-12)

    # Test error equivalence for malformed inputs (NaN, +/- inf, invalid strings)
    error_sequences = [
        [float("nan")],
        [float("inf")],
        [float("-inf")],
        ["not_a_number"],
    ]
    sensor = TokenSurprisalSensor()
    for seq in error_sequences:
        err_opt, err_ref = None, None
        try:
            sensor.compute_z_scores(seq)
        except Exception as e:
            err_opt = (type(e), str(e))

        try:
            _pre_pr_compute_z_scores(sensor, seq)
        except Exception as e:
            err_ref = (type(e), str(e))

        assert err_opt is not None
        assert err_ref is not None
        assert err_opt == err_ref


# =========================================================================
# TOKEN SURPRISAL SENSOR EVALUATE DIFFERENTIAL EQUIVALENCE TESTS
# =========================================================================

def _pre_pr_evaluate(sensor: TokenSurprisalSensor, logprobs: List[float]) -> Dict[str, Any]:
    """Reference implementation of pre-PR multi-pass evaluate() for differential testing."""
    try:
        z_scores = sensor.compute_z_scores(logprobs)
    except ValueError as e:
        return {
            "passed": False,
            "reason": "MALFORMED_NON_FINITE_LOGPROBS",
            "error": str(e),
            "max_z_score": 0.0,
            "flagged_tokens": len(logprobs) if logprobs else 1,
            "token_z_scores": []
        }

    isfinite = math.isfinite
    if any(not isfinite(z) for z in z_scores):
        sanitized_z_scores = [z if isfinite(z) else None for z in z_scores]
        non_finite_count = sanitized_z_scores.count(None)
        return {
            "passed": False,
            "reason": "MALFORMED_NON_FINITE_LOGPROBS",
            "error": f"Derived Z-scores contain {non_finite_count} non-finite value(s)",
            "max_z_score": 0.0,
            "flagged_tokens": len(logprobs) if logprobs else 1,
            "token_z_scores": sanitized_z_scores
        }

    flagged_count = 0
    for i, z in enumerate(z_scores):
        lp = float(logprobs[i])
        surprisal = -lp
        is_z_anomaly = z > sensor.z_threshold
        is_ceiling_anomaly = (
            sensor.max_surprisal_ceiling is not None
            and surprisal > sensor.max_surprisal_ceiling
        )
        if is_z_anomaly or is_ceiling_anomaly:
            flagged_count += 1

    max_z = float(max(z_scores)) if z_scores else 0.0

    return {
        "passed": flagged_count == 0,
        "max_z_score": max_z,
        "flagged_tokens": flagged_count,
        "token_z_scores": z_scores
    }


def test_token_surprisal_sensor_evaluate_differential_equivalence():
    """
    Exhaustively verifies differential equivalence between pre-PR multi-pass
    and post-PR single-pass implementations across all required edge cases:
    - Empty input
    - Ordinary finite inputs
    - Z-score anomalies alone
    - Surprisal-ceiling anomalies alone
    - Overlapping z-score and surprisal-ceiling anomalies
    - Boundary equality at z_threshold and max_surprisal_ceiling
    - Non-finite derived z-scores (NaN, +inf, -inf at start, middle, end)
    - Multiple non-finite values and correct sanitization/counting
    - Float-convertible inputs and numeric subclasses
    """
    class NumericFloatSubclass(float):
        pass

    class NumericIntSubclass(int):
        pass

    sensor_default = TokenSurprisalSensor(z_threshold=2.85, max_surprisal_ceiling=10.0)
    sensor_no_ceiling = TokenSurprisalSensor(z_threshold=2.85, max_surprisal_ceiling=None)
    sensor_strict_ceiling = TokenSurprisalSensor(z_threshold=5.0, max_surprisal_ceiling=2.0)

    test_cases: List[Tuple[TokenSurprisalSensor, List[Any], str]] = [
        # 1. Empty input
        (sensor_default, [], "empty input"),
        (sensor_no_ceiling, [], "empty input no ceiling"),

        # 2. Ordinary finite inputs (lengths 1, 2, 5, 20)
        (sensor_default, [-0.5], "single finite token"),
        (sensor_default, [-0.5, -0.3], "two finite tokens"),
        (sensor_default, [-0.1, -0.2, -0.15, -0.3, -0.25], "5 finite tokens"),
        (sensor_default, [-0.1 * ((i % 5) + 1) for i in range(20)], "20 normal tokens"),

        # 3. Z-score anomaly alone (z > z_threshold while surprisal <= ceiling)
        # Using a distribution where token surprisal is low (< 10.0) but z exceeds threshold
        (TokenSurprisalSensor(z_threshold=1.5, max_surprisal_ceiling=20.0),
         [-0.01] * 10 + [-1.0], "z-score anomaly alone"),

        # 4. Surprisal ceiling anomaly alone (surprisal > ceiling while z <= z_threshold)
        (sensor_strict_ceiling, [-2.5] * 10, "surprisal ceiling anomaly alone"),

        # 5. Overlapping z-score and surprisal ceiling anomalies
        (sensor_default, [-0.1] * 10 + [-15.0], "overlapping z anomaly and ceiling anomaly"),

        # 6. Boundary equality tests (z == z_threshold or surprisal == max_surprisal_ceiling)
        # Exactly equal should NOT be flagged as anomaly (strict > required)
        (TokenSurprisalSensor(z_threshold=0.0, max_surprisal_ceiling=1.0),
         [-1.0] * 5, "exact boundary equality for ceiling"),

        # 7. Float-convertible inputs and numeric subclasses
        (sensor_default, [NumericFloatSubclass(-0.5), NumericIntSubclass(-1), "-0.25", -0.75],
         "numeric subclasses and string floats"),

        # 8. Malformed inputs in raw logprobs (caught in compute_z_scores)
        (sensor_default, [float("nan")], "raw nan"),
        (sensor_default, [float("inf")], "raw inf"),
        (sensor_default, [float("-inf")], "raw -inf"),
        (sensor_default, [-0.5, float("nan"), -0.2], "raw nan in middle"),
        (sensor_default, ["invalid_token"], "invalid string"),
    ]

    for sensor, logprobs, label in test_cases:
        res_ref = _pre_pr_evaluate(sensor, logprobs)
        res_act = sensor.evaluate(logprobs)
        assert res_act == res_ref, (
            f"Mismatch in {label}:\n  Expected: {res_ref}\n  Actual:   {res_act}"
        )

    # 9. Derived Z-score non-finite handling (mock compute_z_scores to test post-processing)
    # Tests non-finite values at beginning, middle, end, and multiple non-finites
    non_finite_patterns = [
        ([float("nan"), 1.0, 2.0], "NaN at beginning"),
        ([1.0, float("nan"), 2.0], "NaN in middle"),
        ([1.0, 2.0, float("nan")], "NaN at end"),
        ([float("inf"), 1.0, 2.0], "+inf at beginning"),
        ([1.0, float("-inf"), 2.0], "-inf in middle"),
        ([float("nan"), float("inf"), float("-inf")], "all non-finite"),
        (
            [1.0, float("nan"), 2.0, float("inf"), 3.0, float("-inf")],
            "multiple non-finites interspersed"
        ),
    ]

    for z_pattern, label in non_finite_patterns:
        mock_sensor = TokenSurprisalSensor()
        dummy_logprobs = [-0.5] * len(z_pattern)
        mock_sensor.compute_z_scores = lambda lp, z_pat=z_pattern: list(z_pat)

        ref_sensor = TokenSurprisalSensor()
        ref_sensor.compute_z_scores = lambda lp, z_pat=z_pattern: list(z_pat)

        res_ref = _pre_pr_evaluate(ref_sensor, dummy_logprobs)
        res_act = mock_sensor.evaluate(dummy_logprobs)

        assert res_act == res_ref, (
            f"Mismatch in non-finite derived z-score test ({label}):\n"
            f"  Expected: {res_ref}\n  Actual:   {res_act}"
        )
        assert res_act["passed"] is False
        assert res_act["reason"] == "MALFORMED_NON_FINITE_LOGPROBS"
        assert res_act["max_z_score"] == 0.0
        assert res_act["flagged_tokens"] == len(dummy_logprobs)
        expected_none_count = sum(1 for z in z_pattern if not math.isfinite(z))
        assert res_act["token_z_scores"].count(None) == expected_none_count


def test_token_surprisal_sensor_observable_float_conversion():
    """
    Verifies that float(logprobs[i]) conversion semantics and invocation counts
    are identically preserved between pre-PR and post-PR implementations
    both when max_surprisal_ceiling is set and when it is None.
    """
    class ObservableFloat:
        def __init__(self, val: float):
            self.val = val
            self.float_conversions = 0

        def __float__(self) -> float:
            self.float_conversions += 1
            return float(self.val)

    # 1. With ceiling set
    sensor_with_ceiling = TokenSurprisalSensor(z_threshold=2.85, max_surprisal_ceiling=10.0)
    obs_tokens_ref = [ObservableFloat(-0.5), ObservableFloat(-0.2), ObservableFloat(-15.0)]
    obs_tokens_act = [ObservableFloat(-0.5), ObservableFloat(-0.2), ObservableFloat(-15.0)]

    res_ref = _pre_pr_evaluate(sensor_with_ceiling, obs_tokens_ref)
    res_act = sensor_with_ceiling.evaluate(obs_tokens_act)

    assert res_act == res_ref
    # In both pre-PR and post-PR:
    # compute_z_scores converts each token once (via float(lp))
    # evaluate() loop converts each token once (via float(logprobs[i]))
    # Total conversions must be identical for each token
    for ref_tok, act_tok in zip(obs_tokens_ref, obs_tokens_act):
        assert act_tok.float_conversions == ref_tok.float_conversions == 2

    # 2. With ceiling=None
    sensor_no_ceiling = TokenSurprisalSensor(z_threshold=2.85, max_surprisal_ceiling=None)
    obs_tokens_ref_none = [ObservableFloat(-0.1), ObservableFloat(-0.3)]
    obs_tokens_act_none = [ObservableFloat(-0.1), ObservableFloat(-0.3)]

    res_ref_none = _pre_pr_evaluate(sensor_no_ceiling, obs_tokens_ref_none)
    res_act_none = sensor_no_ceiling.evaluate(obs_tokens_act_none)

    assert res_act_none == res_ref_none
    for ref_tok, act_tok in zip(obs_tokens_ref_none, obs_tokens_act_none):
        assert act_tok.float_conversions == ref_tok.float_conversions == 2


def test_token_surprisal_sensor_input_contract_and_nonfinite_conversion_order():
    """
    Documents and verifies input assumptions for TokenSurprisalSensor.evaluate:
    1. Supported input types:
       - 1D Sequence of real numbers (float, int, or numeric subclasses) or string representations
         convertible to float without stateful/observable side effects.
    2. compute_z_scores validation:
       - Any non-finite value (NaN, +inf, -inf) in logprobs is detected upfront during
         compute_z_scores, raising ValueError and returning the fail-closed
         MALFORMED_NON_FINITE_LOGPROBS outcome before evaluate()'s loop is reached.
    3. Derived z-score non-finite handling:
       - If an underlying mathematical step or mock produces a non-finite z-score at index k,
         the single-pass loop breaks immediately without processing subsequent elements k..N-1,
         preventing unnecessary float conversions and returning a clean fail-closed error.
    """
    sensor = TokenSurprisalSensor()

    # Raw non-finite logprobs fail upfront during compute_z_scores
    res_nan = sensor.evaluate([-0.5, float("nan"), -0.2])
    assert res_nan["passed"] is False
    assert res_nan["reason"] == "MALFORMED_NON_FINITE_LOGPROBS"

    # Synthetic non-finite in derived z-scores breaks early
    class TrackingFloat:
        def __init__(self, val: float):
            self.val = val
            self.conversions = 0

        def __float__(self) -> float:
            self.conversions += 1
            return float(self.val)

    tokens = [TrackingFloat(-0.5), TrackingFloat(-0.2), TrackingFloat(-0.3)]
    mock_sensor = TokenSurprisalSensor()
    # Mock compute_z_scores to simulate a non-finite z-score at index 1
    mock_sensor.compute_z_scores = lambda lp: [1.0, float("nan"), 2.0]

    res_mock = mock_sensor.evaluate(tokens)
    assert res_mock["passed"] is False
    assert res_mock["reason"] == "MALFORMED_NON_FINITE_LOGPROBS"
    # Token 0 was inspected and converted in evaluate loop; Tokens 1 and 2 were not converted
    assert tokens[0].conversions == 1
    assert tokens[1].conversions == 0
    assert tokens[2].conversions == 0
