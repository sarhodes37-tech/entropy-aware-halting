"""
Unit test suite for epistemicos.audit module.
Validates cryptographic log chain integrity, receipt generation, 
and hardware/OS fallback mechanisms.
"""

import os
import json
import hmac
import hashlib
import importlib
import pytest
from unittest.mock import patch
from epistemicos.audit import (
    TamperEvidentAuditTrail,
    AuditLogLevel,
    ReceiptGenerator,
    AuditEvent
)


@pytest.fixture
def temp_audit_file(tmp_path):
    """Provides an isolated temporary path for audit log generation."""
    return str(tmp_path / "test_audit.jsonl")


# =====================================================================
# CHAIN INTEGRITY & TAMPER DETECTION
# =====================================================================

def test_verify_chain_integrity_json_error(temp_audit_file):
    """Validates chain verification handles malformed JSON gracefully (Line 166)."""
    with open(temp_audit_file, "w") as f:
        f.write('{"event_id": "1", "invalid_json": }\n')
        
    audit = TamperEvidentAuditTrail(temp_audit_file)
    is_valid, count, msg = audit.verify_chain_integrity()
    
    assert is_valid is False
    assert "Malformed JSON" in msg


def test_verify_chain_integrity_broken_link(temp_audit_file):
    """Validates chain verification flags mismatched previous hashes (Line 175)."""
    audit = TamperEvidentAuditTrail(temp_audit_file)
    audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate", "reason", "model", "snippet"))
    
    # Manually append an entry with a fabricated prev_hash to break the chain
    bad_entry = {
        "event_id": "2",
        "timestamp": "2026-08-02T00:00:00Z",
        "event_type": "INFO",
        "gate_name": "gate",
        "reason": "reason",
        "model_id": "model",
        "latency_ms": 0.0,
        "payload_hash": "hash",
        "payload_snippet": "snippet",
        "metadata": {},
        "prev_hash": "INVALID_PREV_HASH"
    }
    # Compute an otherwise valid entry_hash so it passes the self-hash check, but fails the chain check
    bad_entry["entry_hash"] = audit._compute_hash("INVALID_PREV_HASH", bad_entry)
    
    with open(temp_audit_file, "a") as f:
        f.write(json.dumps(bad_entry) + "\n")
        
    is_valid, count, msg = audit.verify_chain_integrity()
    
    assert is_valid is False
    assert "Broken chain link" in msg


def test_verify_chain_integrity_tampered_entry(temp_audit_file):
    """Validates chain verification detects modified payload data (Lines 179-180, 186)."""
    audit = TamperEvidentAuditTrail(temp_audit_file)
    audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate", "reason", "model", "snippet"))
    
    # Read the file and maliciously alter the data without updating the cryptographic hash
    with open(temp_audit_file, "r") as f:
        data = json.loads(f.read().strip())
    
    data["reason"] = "tampered_reason_inserted_by_attacker"
    
    with open(temp_audit_file, "w") as f:
        f.write(json.dumps(data) + "\n")
        
    is_valid, count, msg = audit.verify_chain_integrity()
    
    assert is_valid is False
    assert "Tampered entry detected" in msg


# =====================================================================
# RECEIPT GENERATION & TRANSACTION ROLLBACKS
# =====================================================================

def test_receipt_generator_log_event():
    """Validates direct logging of events in the ReceiptGenerator."""
    rg = ReceiptGenerator()
    rg.log_event("CustomEvent", {"key": "value"})

    assert len(rg.events) == 1
    event = rg.events[0]
    assert "idx" in event
    assert event["idx"] == 0
    assert event["type"] == "CustomEvent"
    assert event["details"] == {"key": "value"}
    assert rg._seq_idx == 1


def test_receipt_generator_lifecycle():
    """Validates atomic transaction logging, minting, and stack-based rollbacks (Lines 196-242)."""
    rg = ReceiptGenerator()
    
    # 1. Test pushing actions (Lines 210-211)
    rg.push_action({"action": "StageVectors"}, {"rollback": "PurgeVectors"})
    rg.push_action({"action": "CommitToLedger"}, {"rollback": "DropBlock"})
    
    # 2. Test minting receipt (Lines 215-220, 223-224, 227-229)
    receipt = rg.mint_receipt("tx_001", False, {"confidence": 0.82})
    
    assert receipt["transaction_id"] == "tx_001"
    assert receipt["status"] == "ROLLED_BACK"
    assert "signature" in receipt
    assert len(receipt["event_log"]) == 2
    
    # 3. Test LIFO rollback execution (Lines 230-235, 238-242)
    rollbacks = rg.rollback()
    
    assert len(rollbacks) == 2
    # Verify strict Last-In-First-Out (LIFO) order for state reconstruction
    assert rollbacks[0] == {"rollback": "DropBlock"}
    assert rollbacks[1] == {"rollback": "PurgeVectors"}


# =====================================================================
# OS/HARDWARE FALLBACKS
# =====================================================================

def test_audit_no_fcntl_fallback(tmp_path):
    """Simulates an OS environment without fcntl (e.g. Windows) to test lock bypassing (Lines 21-22, 122)."""
    test_file = str(tmp_path / "temp_no_fcntl.jsonl")
    
    # Force ImportError on fcntl and reload the module
    with patch.dict('sys.modules', {'fcntl': None}):
        import epistemicos.audit
        importlib.reload(epistemicos.audit)
        
        assert epistemicos.audit.HAS_FCNTL is False
        
        # Test fallback on record_event (bypassing fcntl.flock entirely)
        audit = epistemicos.audit.TamperEvidentAuditTrail(test_file)
        audit.record_event(epistemicos.audit.AuditEvent(epistemicos.audit.AuditLogLevel.INFO, "gate", "reason", "m", "s"))
        
        assert os.path.exists(test_file)
        
    # Restore normal state for subsequent test modules
    import epistemicos.audit
    importlib.reload(epistemicos.audit)


def test_record_event_payload_too_large(temp_audit_file):
    """Validates that payload snippets larger than 1MB are rejected to prevent DoS."""
    audit = TamperEvidentAuditTrail(temp_audit_file)
    large_snippet = "a" * (1048576 + 1)
    event = AuditEvent(AuditLogLevel.INFO, "gate", "reason", "model", large_snippet)
    with pytest.raises(ValueError, match="Payload snippet exceeds"):
        audit.record_event(event)


def test_tamper_evident_audit_trail_hmac_key_validation(temp_audit_file):
    """Verifies fail-closed validation of hmac_key in TamperEvidentAuditTrail."""
    # Retain empty-key and invalid-type rejection tests
    with pytest.raises(ValueError, match="hmac_key cannot be empty"):
        TamperEvidentAuditTrail(temp_audit_file, hmac_key=b"")

    with pytest.raises(ValueError, match="hmac_key cannot be empty"):
        TamperEvidentAuditTrail(temp_audit_file, hmac_key=bytearray())

    for invalid_key in ("secret_str", 12345, ["key"], {"k": "v"}):
        with pytest.raises(TypeError, match="hmac_key must be bytes or bytearray"):
            TamperEvidentAuditTrail(temp_audit_file, hmac_key=invalid_key)

    payload = {"k": "v", "num": 42}
    prev_hash = "0" * 64
    combined = f"{prev_hash}:{json.dumps(payload, sort_keys=True)}".encode("utf-8")
    unkeyed_expected = hashlib.sha256(combined).hexdigest()

    # Verify hmac_key=None preserves unkeyed SHA-256
    audit_none = TamperEvidentAuditTrail(temp_audit_file, hmac_key=None)
    assert audit_none._compute_hash(prev_hash, payload) == unkeyed_expected

    # Verify valid bytes key computes exact HMAC-SHA256 and differs from unkeyed SHA-256
    bytes_key = b"valid_audit_secret_bytes"
    audit_bytes = TamperEvidentAuditTrail(temp_audit_file, hmac_key=bytes_key)
    expected_bytes_hash = hmac.new(bytes_key, combined, hashlib.sha256).hexdigest()
    computed_bytes_hash = audit_bytes._compute_hash(prev_hash, payload)
    assert computed_bytes_hash == expected_bytes_hash
    assert computed_bytes_hash != unkeyed_expected

    # Verify valid bytearray key computes exact HMAC-SHA256 and differs from unkeyed SHA-256
    ba_key = bytearray(b"valid_audit_secret_bytearray")
    audit_ba = TamperEvidentAuditTrail(temp_audit_file, hmac_key=ba_key)
    assert isinstance(audit_ba.hmac_key, bytes)
    expected_ba_hash = hmac.new(ba_key, combined, hashlib.sha256).hexdigest()
    computed_ba_hash = audit_ba._compute_hash(prev_hash, payload)
    assert computed_ba_hash == expected_ba_hash
    assert computed_ba_hash != unkeyed_expected

    # Mutate the original bytearray and verify the stored snapshot remains unaffected
    ba_key[0] = ord(b"X")
    assert audit_ba._compute_hash(prev_hash, payload) == expected_ba_hash
    assert isinstance(audit_ba.hmac_key, bytes)


def test_receipt_empty_and_invalid_signing_keys():
    """Validates that empty keys and invalid key types are rejected by minting and verification."""
    rg = ReceiptGenerator()

    # 1. Verification rejects empty bytes and empty bytearray
    valid_hmac_receipt = ReceiptGenerator(signing_key=b"secret_key").mint_receipt(
        "tx_hmac", True, {"g": 1.0}
    )
    assert ReceiptGenerator.verify_receipt(valid_hmac_receipt, signing_key=b"") is False
    assert ReceiptGenerator.verify_receipt(valid_hmac_receipt, signing_key=bytearray()) is False

    # 2. Verification rejects invalid key types without uncaught TypeError
    for invalid_key in ("secret_str", 12345, ["secret"], {"key": "val"}, object()):
        assert ReceiptGenerator.verify_receipt(valid_hmac_receipt, signing_key=invalid_key) is False

    # 3. Minting rejects empty bytes and empty bytearray
    with pytest.raises(ValueError, match="signing_key cannot be empty"):
        rg.mint_receipt("tx1", True, {"g": 1.0}, signing_key=b"")
    with pytest.raises(ValueError, match="signing_key cannot be empty"):
        rg.mint_receipt("tx1", True, {"g": 1.0}, signing_key=bytearray())
    with pytest.raises(ValueError, match="signing_key cannot be empty"):
        ReceiptGenerator(signing_key=b"").mint_receipt("tx1", True, {"g": 1.0})

    # 4. Minting rejects invalid key types
    for invalid_key in ("secret_str", 12345, ["secret"], {"key": "val"}, object()):
        with pytest.raises(TypeError, match="signing_key must be bytes or bytearray"):
            rg.mint_receipt("tx1", True, {"g": 1.0}, signing_key=invalid_key)
        with pytest.raises(TypeError, match="signing_key must be bytes or bytearray"):
            ReceiptGenerator(signing_key=invalid_key).mint_receipt("tx1", True, {"g": 1.0})


def test_receipt_forged_hmac_with_sha256_rejected():
    """
    Validates that a forged receipt declaring 'HMAC-SHA256' but signed with
    plain SHA-256 digest is rejected across all key attempts (including b'', bytearray(), and None).
    """
    import json
    import hashlib

    # Craft forged receipt declaring HMAC-SHA256 with a plain SHA-256 signature
    forged_receipt = {
        "transaction_id": "tx-forged-hmac",
        "status": "COMMITTED",
        "gate_version": "1.0.0",
        "config": {},
        "confidence_matrix": {},
        "event_log": [],
        "signature_algorithm": "HMAC-SHA256"
    }
    check_bytes = json.dumps(forged_receipt, sort_keys=True).encode("utf-8")
    forged_receipt["signature"] = hashlib.sha256(check_bytes).hexdigest()

    # Must be rejected when verified with empty bytes or empty bytearray
    assert ReceiptGenerator.verify_receipt(forged_receipt, signing_key=b"") is False
    assert ReceiptGenerator.verify_receipt(forged_receipt, signing_key=bytearray()) is False

    # Must be rejected when verified without key (None) due to algorithm mismatch
    assert ReceiptGenerator.verify_receipt(forged_receipt, signing_key=None) is False

    # Must be rejected when verified with any actual secret key
    assert ReceiptGenerator.verify_receipt(forged_receipt, signing_key=b"legit_secret") is False


def test_receipt_valid_bytearray_and_unsigned_roundtrip():
    """Validates that bytearray keys and unsigned receipts roundtrip correctly."""
    key_ba = bytearray(b"bytearray_secret_key")
    rg_ba = ReceiptGenerator(signing_key=key_ba)
    rec_ba = rg_ba.mint_receipt("tx_ba", True, {"confidence": 0.95})
    assert rec_ba["signature_algorithm"] == "HMAC-SHA256"
    assert ReceiptGenerator.verify_receipt(rec_ba, signing_key=key_ba) is True
    assert ReceiptGenerator.verify_receipt(rec_ba, signing_key=bytes(key_ba)) is True

    # Unsigned roundtrip
    rg_none = ReceiptGenerator(signing_key=None)
    rec_none = rg_none.mint_receipt("tx_none", False, {"confidence": 0.0})
    assert rec_none["signature_algorithm"] == "SHA256"
    assert ReceiptGenerator.verify_receipt(rec_none, signing_key=None) is True
    # Algorithm metadata mismatch fails closed
    assert ReceiptGenerator.verify_receipt(rec_none, signing_key=b"secret") is False


# =====================================================================
# AUDIT TRAIL ERROR PATHS & FALLBACKS
# =====================================================================

def test_audit_fsync_oserror_fallback_handling(temp_audit_file):
    """
    Validates that TamperEvidentAuditTrail gracefully catches OSError on os.fsync during record_event.

    Durability Contract Note:
    TamperEvidentAuditTrail implements best-effort physical durability on local filesystems.
    In environments where fsync is not supported or fails with OSError (e.g. certain network mounts,
    virtualized file descriptors, or restricted container runtimes), record_event flushes in-memory
    buffers (f.flush()) and swallows the OSError so audit logging does not abort execution.
    The caller receives the formatted entry_data confirming buffer write, but hardware sync is best-effort.
    """
    audit = TamperEvidentAuditTrail(temp_audit_file)
    event = AuditEvent(
        event_type=AuditLogLevel.INFO,
        gate_name="fsync_gate",
        reason="test_fsync_error_handling",
        model_id="test_model",
        payload_snippet="payload_for_fsync_fallback"
    )

    with patch("os.fsync", side_effect=OSError("Sync to storage device not supported")) as mock_fsync:
        recorded = audit.record_event(event)

    # Explicitly assert that os.fsync was invoked exactly once and the OSError path was executed
    mock_fsync.assert_called_once()
    assert recorded is not None
    assert recorded["gate_name"] == "fsync_gate"
    assert recorded["reason"] == "test_fsync_error_handling"
    assert os.path.exists(temp_audit_file)

    # Verify chain integrity after write with fsync fallback
    is_valid, count, err = audit.verify_chain_integrity()
    assert is_valid is True
    assert count == 1
    assert err is None


def test_audit_get_last_hash_reload_and_uncached_fallback(temp_audit_file):
    """Validates TamperEvidentAuditTrail._get_last_hash with force_reload=True, cache handling, and corrupted log fallback."""
    audit = TamperEvidentAuditTrail(temp_audit_file)

    # When log file does not exist or is empty, returns genesis hash
    audit.last_hash = None
    initial_hash = audit._get_last_hash(force_reload=False)
    assert initial_hash == audit.genesis_hash
    assert audit.last_hash == audit.genesis_hash

    # Cached hit branch (force_reload=False and last_hash is not None)
    audit.last_hash = "pre_cached_entry_hash"
    assert audit._get_last_hash(force_reload=False) == "pre_cached_entry_hash"

    # Record first event
    e1 = audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate1", "reason1", "model1", "snippet1"))
    expected_hash_1 = e1["entry_hash"]

    # Invalidate cached last_hash and verify fallback recalculation
    audit.last_hash = None
    recovered_hash = audit._get_last_hash(force_reload=False)
    assert recovered_hash == expected_hash_1
    assert audit.last_hash == expected_hash_1

    # Force reload even when cached
    audit.last_hash = "stale_hash_value"
    reloaded_hash = audit._get_last_hash(force_reload=True)
    assert reloaded_hash == expected_hash_1
    assert audit.last_hash == expected_hash_1

    # Simulate log corruption (malformed trailing JSON)
    with open(temp_audit_file, "a", encoding="utf-8") as f:
        f.write('{"event_id": "malformed_trailing_entry", "incomplete": \n')

    # Verify behavior of inspect_log_health and _get_last_hash on corrupted log
    is_healthy, last_valid_h, err_msg = audit.inspect_log_health()
    assert is_healthy is False
    assert last_valid_h == expected_hash_1
    assert "Malformed JSON" in err_msg

    audit.last_hash = None
    recovered_on_corrupt = audit._get_last_hash(force_reload=False)
    assert recovered_on_corrupt == expected_hash_1
    assert audit.last_hash == expected_hash_1

    # Verify that record_event refuses to append to corrupted log and fails closed
    with pytest.raises(RuntimeError, match="Cannot write to audit trail: Log corruption detected"):
        audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate2", "reason2", "model2", "snippet2"))


def test_audit_sanitize_string_value_bearer_and_email_branches():
    """Validates fast-path string value sanitization for Bearer tokens, emails, and UUID-shaped string preservation."""
    from epistemicos.audit import _sanitize_string_value

    # Bearer pattern branch
    bearer_raw = "Authorization: Bearer secret_token_xyz"
    sanitized_bearer = _sanitize_string_value(bearer_raw)
    assert "secret_token_xyz" not in sanitized_bearer
    assert "Bearer [REDACTED]" in sanitized_bearer

    # Email pattern branch
    email_raw = "User email is admin@example.corp."
    sanitized_email = _sanitize_string_value(email_raw)
    assert "admin@example.corp" not in sanitized_email
    assert "[REDACTED_EMAIL]" in sanitized_email

    # Combined with trigger character check
    combined_raw = "Contact: support@acme.org with token Bearer token_999 and api_key=value123"
    sanitized_combined = _sanitize_string_value(combined_raw)
    assert "support@acme.org" not in sanitized_combined
    assert "[REDACTED_EMAIL]" in sanitized_combined
    assert "token_999" not in sanitized_combined
    assert "Bearer [REDACTED]" in sanitized_combined
    assert "api_key=[REDACTED]" in sanitized_combined

    # Fast-path length 36 UUID-shaped string preservation (Line 56):
    # Verifies that strings matching standard 8-4-4-4-12 hexadecimal UUID shape are preserved intact
    # to maintain correlation IDs without being altered by phone/SSN digit redactions.
    uuid_shaped_string = "12345678-1234-5678-1234-567812345678"
    assert len(uuid_shaped_string) == 36
    assert _sanitize_string_value(uuid_shaped_string) == uuid_shaped_string


def test_f8_tamper_evident_audit_trail_hmac_keying(temp_audit_file):
    """F8 Regression: Verifies that configuring TamperEvidentAuditTrail with hmac_key uses HMAC-SHA256 for chain integrity."""
    secret_key = b"audit_trail_secret_key"
    audit = TamperEvidentAuditTrail(temp_audit_file, hmac_key=secret_key)

    event = AuditEvent(AuditLogLevel.INFO, "gate_hmac", "reason_hmac", "model1", "snippet_hmac")
    rec = audit.record_event(event)
    assert "entry_hash" in rec

    is_valid, count, msg = audit.verify_chain_integrity()
    assert is_valid is True
    assert count == 1

    # Unkeyed instance fails integrity check on keyed file
    unkeyed_audit = TamperEvidentAuditTrail(temp_audit_file)
    unkeyed_valid, _, _ = unkeyed_audit.verify_chain_integrity()
    assert unkeyed_valid is False


def test_audit_event_cpr_telemetry_belief_snapshots(temp_audit_file):
    """Validates audit event logging with CPR, telemetry, and belief state snapshots."""
    from epistemicos.models import CanonicalProblemRepresentation, BeliefObject, PopperianContract
    from epistemicos.telemetry import HardwareTelemetry

    audit = TamperEvidentAuditTrail(temp_audit_file)
    cpr = CanonicalProblemRepresentation(policy_id="P1", fleet_data={"count": 1})
    telemetry = HardwareTelemetry(
        wall_clock_ms=12.34, cuda_time_ms=0.0, vram_allocated_mb=0.0,
        vram_reserved_mb=0.0, vram_peak_mb=0.0, fragmentation_index=0.0,
        tokens_processed=10, ms_per_token=1.23
    )
    popper = PopperianContract(
        claim_id="claim_001", target_metric="loss_ratio",
        falsification_threshold=0.1, comparison_operator=">", observation_window_days=30
    )
    belief = BeliefObject(
        belief_id="b1", cpr_frame_id="f1", assertion="claim",
        prior_probability=0.5, current_posterior=0.9, popp_contract=popper
    )

    event = AuditEvent(
        event_type=AuditLogLevel.INFO,
        gate_name="SnapGate",
        reason="Testing snapshots",
        model_id="M1",
        payload_snippet="snippet",
        cpr_snapshot=cpr,
        telemetry=telemetry,
        belief_snapshot=belief
    )

    rec = audit.record_event(event)
    assert rec["latency_ms"] == 12.34
    assert "cpr_state" in rec["metadata"]
    assert "hardware_telemetry" in rec["metadata"]
    assert "belief_state" in rec["metadata"]


def test_verify_receipt_type_and_format_edge_cases():
    """Validates verify_receipt type and format error handling branches."""
    # Line 420: Non-dict receipt
    assert ReceiptGenerator.verify_receipt("not_a_dict") is False

    rg = ReceiptGenerator()
    valid_receipt = rg.mint_receipt("tx_edge", True, {"g": 1.0})

    # Line 444: signature_algorithm non-string
    rec_algo = dict(valid_receipt)
    rec_algo["signature_algorithm"] = 123
    assert ReceiptGenerator.verify_receipt(rec_algo) is False

    # Line 451-452: Non-hex signature of length 64
    rec_sig_hex = dict(valid_receipt)
    rec_sig_hex["signature"] = "Z" * 64
    assert ReceiptGenerator.verify_receipt(rec_sig_hex) is False

    # Line 458: Invalid length input_hash
    rec_ih_len = dict(valid_receipt)
    rec_ih_len["input_hash"] = "short"
    assert ReceiptGenerator.verify_receipt(rec_ih_len) is False

    # Line 461-462: Non-hex input_hash of length 64
    rec_ih_hex = dict(valid_receipt)
    rec_ih_hex["input_hash"] = "G" * 64
    assert ReceiptGenerator.verify_receipt(rec_ih_hex) is False

    # Line 465: decision_details not dict
    rec_dec = dict(valid_receipt)
    rec_dec["decision_details"] = "string_desc"
    assert ReceiptGenerator.verify_receipt(rec_dec) is False

    # Line 468: execution_outcome not dict
    rec_out = dict(valid_receipt)
    rec_out["execution_outcome"] = [1, 2, 3]
    assert ReceiptGenerator.verify_receipt(rec_out) is False


# =====================================================================
# ADVANCED AUDIT SECURITY & TAMPER TESTS
# =====================================================================

def test_audit_duplicate_event_id_detection(temp_audit_file):
    """Validates that replayed or duplicate event IDs are detected."""
    audit = TamperEvidentAuditTrail(temp_audit_file)
    e1 = audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate1", "reason1", "model1", "snippet1"))
    e2 = audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate2", "reason2", "model2", "snippet2"))

    # Read and duplicate entry 2 with duplicate event_id
    with open(temp_audit_file, "r") as f:
        lines = f.readlines()

    dup_entry = json.loads(lines[1])
    lines.append(json.dumps(dup_entry) + "\n")

    with open(temp_audit_file, "w") as f:
        f.writelines(lines)

    is_valid, count, msg = audit.verify_chain_integrity()
    assert is_valid is False
    assert "Duplicate event_id" in msg


def test_audit_reordering_detection(temp_audit_file):
    """Validates that swapping event sequence order breaks chain integrity."""
    audit = TamperEvidentAuditTrail(temp_audit_file)
    audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate1", "reason1", "model1", "snippet1"))
    audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate2", "reason2", "model2", "snippet2"))

    with open(temp_audit_file, "r") as f:
        lines = f.readlines()

    # Reorder lines
    swapped = [lines[1], lines[0]]
    with open(temp_audit_file, "w") as f:
        f.writelines(swapped)

    is_valid, count, msg = audit.verify_chain_integrity()
    assert is_valid is False
    assert "Broken chain link" in msg


def test_audit_truncation_detection(temp_audit_file):
    """Validates head, middle, and tail truncation behaviors."""
    audit = TamperEvidentAuditTrail(temp_audit_file)
    audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate1", "r1", "m1", "s1"))
    audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate2", "r2", "m2", "s2"))
    audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate3", "r3", "m3", "s3"))

    with open(temp_audit_file, "r") as f:
        lines = f.readlines()

    # 1. Head truncation (delete line 1)
    with open(temp_audit_file, "w") as f:
        f.writelines(lines[1:])

    is_valid, count, msg = audit.verify_chain_integrity()
    assert is_valid is False
    assert "Broken chain link" in msg

    # 2. Middle truncation (delete line 2)
    with open(temp_audit_file, "w") as f:
        f.writelines([lines[0], lines[2]])

    is_valid, count, msg = audit.verify_chain_integrity()
    assert is_valid is False
    assert "Broken chain link" in msg

    # 3. Tail truncation (delete line 3): Internal hash chain alone cannot detect tail truncation
    with open(temp_audit_file, "w") as f:
        f.writelines(lines[:2])

    is_valid, count, msg = audit.verify_chain_integrity()
    assert is_valid is True
    assert count == 2


def test_audit_partial_write_detection(temp_audit_file):
    """Validates that partial line writes (corrupted JSON) are flagged."""
    audit = TamperEvidentAuditTrail(temp_audit_file)
    audit.record_event(AuditEvent(AuditLogLevel.INFO, "gate1", "r1", "m1", "s1"))

    # Append corrupted JSON line representing a crash during write
    with open(temp_audit_file, "a") as f:
        f.write('{"event_id": "partial_write_123", "event_type": "INF')

    is_valid, count, msg = audit.verify_chain_integrity()
    assert is_valid is False
    assert "Malformed JSON" in msg


def test_audit_sensitive_data_redaction(temp_audit_file):
    """Validates that sensitive credentials and PII are redacted from metadata and receipts."""
    audit = TamperEvidentAuditTrail(temp_audit_file)
    sensitive_metadata = {
        "api_key": "sk-secret-12345",
        "ssn": "000-00-0000",
        "nested": {"password": "SuperSecretPassword123"}
    }
    audit.record_event(AuditEvent(
        AuditLogLevel.INFO, "gate", "reason", "model", "snippet",
        metadata=sensitive_metadata
    ))

    with open(temp_audit_file, "r") as f:
        line = f.readline()
    entry = json.loads(line)

    metadata = entry["metadata"]
    assert metadata["api_key"] == "[REDACTED]"
    assert metadata["ssn"] == "[REDACTED]"
    assert metadata["nested"]["password"] == "[REDACTED]"

    # Test ReceiptGenerator sensitive data redaction
    rg = ReceiptGenerator()
    rg.log_event("ToolOutput", {"token": "bearer-token-abc", "safe_field": "public"})
    rg.push_action(
        {"op": "query", "secret": "shh"},
        {"rollback": "purge", "private_key": "0x123"}
    )
    receipt = rg.mint_receipt("tx_sens", True, {"conf": 0.99})

    assert receipt["event_log"][0]["details"]["token"] == "[REDACTED]"
    assert receipt["event_log"][0]["details"]["safe_field"] == "public"
    assert receipt["event_log"][1]["details"]["action"]["secret"] == "[REDACTED]"


def test_receipt_exact_binding_and_verification():
    """Validates receipt binding to input, config, gate_version, decision, outcome and independent verifier validation."""
    key = b"secret_signing_key_32bytes_long!"
    config = {"threshold": 0.95, "api_key": "should_be_masked"}
    input_payload = {"user_prompt": "run_analysis", "password": "user_pass"}
    decision = {"gate": "PermissionGate", "action": "ALLOW"}
    outcome = {"vectors_revoked": 0}

    rg = ReceiptGenerator(signing_key=key, gate_version="2.1.0", config=config)
    rg.log_event("GateEvaluation", {"result": "PASSED"})

    receipt = rg.mint_receipt(
        transaction_id="tx_bound_001",
        success=True,
        confidence_matrix={"model": 0.98},
        input_data=input_payload,
        decision_details=decision,
        execution_outcome=outcome
    )

    assert receipt["gate_version"] == "2.1.0"
    assert receipt["config"]["api_key"] == "[REDACTED]"
    assert "input_hash" in receipt
    assert receipt["decision_details"] == decision
    assert receipt["execution_outcome"] == outcome

    # Verify signature independently with ReceiptGenerator.verify_receipt
    assert ReceiptGenerator.verify_receipt(receipt, signing_key=key) is True

    # Verify that altering any field invalidates signature
    tampered_receipt = dict(receipt)
    tampered_receipt["status"] = "ROLLED_BACK"
    assert ReceiptGenerator.verify_receipt(tampered_receipt, signing_key=key) is False

    # Verify wrong signing key fails
    assert ReceiptGenerator.verify_receipt(receipt, signing_key=b"wrong_key") is False


def test_audit_trail_concurrency_force_reload(temp_audit_file):
    """Validates that two audit instances maintain chain link integrity via force_reload."""
    audit1 = TamperEvidentAuditTrail(temp_audit_file)
    audit2 = TamperEvidentAuditTrail(temp_audit_file)

    audit1.record_event(AuditEvent(AuditLogLevel.INFO, "g1", "r1", "m1", "s1"))
    audit2.record_event(AuditEvent(AuditLogLevel.INFO, "g2", "r2", "m2", "s2"))
    audit1.record_event(AuditEvent(AuditLogLevel.INFO, "g3", "r3", "m3", "s3"))

    is_valid, count, msg = audit1.verify_chain_integrity()
    assert is_valid is True
    assert count == 3


def _multiprocess_writer_worker(file_path: str, worker_id: int, count: int):
    """Helper target for multiprocessing concurrency tests."""
    audit = TamperEvidentAuditTrail(file_path)
    for i in range(count):
        audit.record_event(AuditEvent(
            AuditLogLevel.INFO,
            f"worker_{worker_id}",
            f"step_{i}",
            "model_mp",
            f"snippet_worker_{worker_id}_{i}"
        ))


def test_audit_multiprocess_concurrency(temp_audit_file):
    """Validates concurrent log appends from independent OS processes maintain chain integrity."""
    import multiprocessing

    processes = []
    num_workers = 4
    events_per_worker = 5

    for w_id in range(num_workers):
        p = multiprocessing.Process(
            target=_multiprocess_writer_worker,
            args=(temp_audit_file, w_id, events_per_worker)
        )
        processes.append(p)
        p.start()

    for p in processes:
        p.join(timeout=10)

    audit_verifier = TamperEvidentAuditTrail(temp_audit_file)
    is_valid, count, msg = audit_verifier.verify_chain_integrity()
    assert is_valid is True
    assert count == num_workers * events_per_worker


def test_audit_crash_recovery_last_hash(temp_audit_file):
    """Validates crash recovery, explicit corruption reporting, and repair workflow."""
    audit = TamperEvidentAuditTrail(temp_audit_file)
    e1 = audit.record_event(AuditEvent(AuditLogLevel.INFO, "g1", "r1", "m1", "s1"))
    e2 = audit.record_event(AuditEvent(AuditLogLevel.INFO, "g2", "r2", "m2", "s2"))
    e3 = audit.record_event(AuditEvent(AuditLogLevel.INFO, "g3", "r3", "m3", "s3"))

    # Simulate crash mid-write by writing partial trailing JSON fragment
    with open(temp_audit_file, "a") as f:
        f.write('{"event_id": "crashed_mid_write_123", "event_type": "INF')

    audit_after_crash = TamperEvidentAuditTrail(temp_audit_file)
    is_healthy, last_valid_h, err = audit_after_crash.inspect_log_health()

    # 1. Inspecting health flags corruption and identifies last valid hash
    assert is_healthy is False
    assert last_valid_h == e3["entry_hash"]
    assert "Malformed JSON" in err

    # 2. Attempting to record_event on a corrupted log MUST raise RuntimeError
    with pytest.raises(RuntimeError, match="Log corruption detected"):
        audit_after_crash.record_event(AuditEvent(AuditLogLevel.INFO, "g4", "r4", "m4", "s4"))

    # 3. Explicit repair policy: truncate unparseable trailing bytes
    with open(temp_audit_file, "r") as f:
        lines = f.readlines()
    clean_lines = [l for l in lines if not l.startswith('{"event_id": "crashed_mid_write_123"')]
    with open(temp_audit_file, "w") as f:
        f.writelines(clean_lines)

    # 4. After repair, health is restored and new event appends properly
    audit_repaired = TamperEvidentAuditTrail(temp_audit_file)
    is_healthy_now, _, _ = audit_repaired.inspect_log_health()
    assert is_healthy_now is True

    e4 = audit_repaired.record_event(AuditEvent(AuditLogLevel.INFO, "g4", "r4", "m4", "s4"))
    assert e4["prev_hash"] == e3["entry_hash"]

    is_valid, count, msg = audit_repaired.verify_chain_integrity()
    assert is_valid is True
    assert count == 4


def test_audit_unlinked_record_rejection(temp_audit_file):
    """Validates that appending after a complete but unlinked record is rejected."""
    audit = TamperEvidentAuditTrail(temp_audit_file)
    e1 = audit.record_event(AuditEvent(AuditLogLevel.INFO, "g1", "r1", "m1", "s1"))

    # Append an unlinked record with invalid prev_hash
    unlinked_entry = {
        "event_id": "unlinked_999",
        "timestamp": "2026-08-02T00:00:00Z",
        "event_type": "INFO",
        "gate_name": "g_bad",
        "reason": "bad_link",
        "model_id": "m1",
        "latency_ms": 0.0,
        "payload_hash": "hash",
        "payload_snippet": "s",
        "metadata": {},
        "prev_hash": "INVALID_PREV_HASH"
    }
    unlinked_entry["entry_hash"] = audit._compute_hash("INVALID_PREV_HASH", unlinked_entry)

    with open(temp_audit_file, "a") as f:
        f.write(json.dumps(unlinked_entry) + "\n")

    is_healthy, last_h, err = audit.inspect_log_health()
    assert is_healthy is False
    assert "Broken chain link" in err

    with pytest.raises(RuntimeError, match="Log corruption detected"):
        audit.record_event(AuditEvent(AuditLogLevel.INFO, "g2", "r2", "m2", "s2"))


def test_receipt_schema_enforcement_and_fail_closed():
    """Validates strict schema enforcement, missing required fields, insertion of unknown fields, nulls, and malformed sigs."""
    key = b"signing_key_12345"
    rg = ReceiptGenerator(signing_key=key)
    valid_receipt = rg.mint_receipt("tx_schema_001", True, {"g": 1.0})

    assert ReceiptGenerator.verify_receipt(valid_receipt, signing_key=key) is True

    # 1. Missing required field
    for req_field in ["transaction_id", "status", "gate_version", "config", "confidence_matrix", "event_log", "signature_algorithm"]:
        incomplete = dict(valid_receipt)
        del incomplete[req_field]
        assert ReceiptGenerator.verify_receipt(incomplete, signing_key=key) is False, f"Failed to reject missing field: {req_field}"

    # 2. Unknown extra field
    unknown_field_receipt = dict(valid_receipt)
    unknown_field_receipt["unauthorized_key"] = "malicious_injection"
    assert ReceiptGenerator.verify_receipt(unknown_field_receipt, signing_key=key) is False

    # 3. Null substitution for required fields
    for req_field in ["transaction_id", "status", "gate_version", "config", "confidence_matrix", "event_log"]:
        null_receipt = dict(valid_receipt)
        null_receipt[req_field] = None
        assert ReceiptGenerator.verify_receipt(null_receipt, signing_key=key) is False

    # 4. Invalid field types
    invalid_type_receipt = dict(valid_receipt)
    invalid_type_receipt["transaction_id"] = 12345
    assert ReceiptGenerator.verify_receipt(invalid_type_receipt, signing_key=key) is False

    invalid_status_receipt = dict(valid_receipt)
    invalid_status_receipt["status"] = "PENDING"
    assert ReceiptGenerator.verify_receipt(invalid_status_receipt, signing_key=key) is False

    # 5. Malformed signature
    malformed_sig_receipt = dict(valid_receipt)
    malformed_sig_receipt["signature"] = "not_a_valid_64_char_hex_string"
    assert ReceiptGenerator.verify_receipt(malformed_sig_receipt, signing_key=key) is False

    # 6. Unknown signature algorithm
    unknown_algo_receipt = dict(valid_receipt)
    unknown_algo_receipt["signature_algorithm"] = "MD5"
    assert ReceiptGenerator.verify_receipt(unknown_algo_receipt, signing_key=key) is False


def test_receipt_set_canonicalization_determinism():
    """Validates that sets and frozensets containing strings, mixed primitive types, and nested dicts are deterministically canonicalized, and unsupported un-serializable values fail explicitly."""
    from epistemicos.audit import _sanitize_sensitive_data

    rg = ReceiptGenerator()
    rg.log_event("SetEvent", {"tags": {"tag_z", "tag_a", "tag_m"}})
    receipt = rg.mint_receipt("tx_set_001", True, {"g": 1.0})

    tags = receipt["event_log"][0]["details"]["tags"]
    assert isinstance(tags, list)
    assert tags == ["tag_a", "tag_m", "tag_z"]
    assert ReceiptGenerator.verify_receipt(receipt) is True

    # Test mixed primitive types in set
    mixed_set = {10, "apple", True, None}
    canonical_mixed = _sanitize_sensitive_data(mixed_set)
    assert isinstance(canonical_mixed, list)
    assert canonical_mixed == [10, "apple", True, None] or len(canonical_mixed) == 4

    # Test that equivalent sets with mixed types yield identical canonical JSON bytes
    set1 = {"b", 1, None}
    set2 = {None, 1, "b"}
    assert json.dumps(_sanitize_sensitive_data(set1)) == json.dumps(_sanitize_sensitive_data(set2))

    # Test unsupported un-serializable value raises TypeError explicitly
    unsupported_set = {lambda x: x}
    with pytest.raises(TypeError):
        _sanitize_sensitive_data(unsupported_set)


def test_receipt_field_by_field_tampering():
    """Validates that altering any individual field in a receipt invalidates its signature."""
    key = b"signing_secret_key_123"
    rg = ReceiptGenerator(signing_key=key, gate_version="1.0.0", config={"setting": 1})
    rg.log_event("EventA", {"detail": "ok"})

    receipt = rg.mint_receipt(
        transaction_id="tx_test_tamper",
        success=True,
        confidence_matrix={"gate": 0.9},
        input_data={"prompt": "test"},
        decision_details={"action": "ALLOW"},
        execution_outcome={"revoked": 0}
    )

    assert ReceiptGenerator.verify_receipt(receipt, signing_key=key) is True

    # Test independent field modifications
    tamper_scenarios = [
        ("transaction_id", "tx_test_tamper_MODIFIED"),
        ("status", "ROLLED_BACK"),
        ("gate_version", "1.0.1"),
        ("config", {"setting": 2}),
        ("confidence_matrix", {"gate": 0.5}),
        ("event_log", []),
        ("input_hash", "0000000000000000000000000000000000000000000000000000000000000000"),
        ("decision_details", {"action": "HALT"}),
        ("execution_outcome", {"revoked": 1}),
        ("signature_algorithm", "SHA256")
    ]

    for key_to_tamper, tampered_val in tamper_scenarios:
        t_receipt = dict(receipt)
        t_receipt[key_to_tamper] = tampered_val
        assert ReceiptGenerator.verify_receipt(t_receipt, signing_key=key) is False, f"Failed to reject tampered key: {key_to_tamper}"


def test_receipt_algorithm_downgrade_prevention():
    """Validates protection against algorithm downgrade and key mismatch attacks."""
    key = b"secret_key"
    rg_hmac = ReceiptGenerator(signing_key=key)
    receipt_hmac = rg_hmac.mint_receipt("tx_hmac", True, {"m": 1.0})

    # HMAC receipt verified with key must pass
    assert ReceiptGenerator.verify_receipt(receipt_hmac, signing_key=key) is True

    # Verifying HMAC receipt without passing signing key must fail
    assert ReceiptGenerator.verify_receipt(receipt_hmac, signing_key=None) is False

    # Forging receipt: setting algorithm to SHA256 while keeping HMAC signature must fail
    forged_downgrade = dict(receipt_hmac)
    forged_downgrade["signature_algorithm"] = "SHA256"
    assert ReceiptGenerator.verify_receipt(forged_downgrade, signing_key=None) is False
    assert ReceiptGenerator.verify_receipt(forged_downgrade, signing_key=key) is False

    # Plain SHA256 receipt
    rg_sha = ReceiptGenerator(signing_key=None)
    receipt_sha = rg_sha.mint_receipt("tx_sha", True, {"m": 1.0})
    assert ReceiptGenerator.verify_receipt(receipt_sha, signing_key=None) is True

    # Verifying plain SHA256 receipt when expecting HMAC (key provided) must fail
    assert ReceiptGenerator.verify_receipt(receipt_sha, signing_key=key) is False


def test_sanitize_sensitive_data_deep_structures_and_text():
    """Validates redaction across sets, frozensets, unusual keys, and free-text token patterns."""
    from epistemicos.audit import _sanitize_sensitive_data

    raw_data = {
        "x-api-key": "sk-123456789012345678901234",
        "github_token": "github_pat_11AAAAAAA0123456789abcdef_ghijklmnopqrstuvwxyz0123456789abcdef0123456789abcdef012",
        "headers": {
            "Authorization": "Bearer my_secret_bearer_token_123",
            "Credential_Token": "secret_pass_123"
        },
        "tags_set": {"normal_tag", "password=my_raw_password"},
        "config_tuple": ("clean_val", "api_key=sk-999999999999999999999999")
    }

    sanitized = _sanitize_sensitive_data(raw_data)

    assert sanitized["x-api-key"] == "[REDACTED]"
    assert sanitized["github_token"] == "[REDACTED]"
    assert sanitized["headers"]["Authorization"] == "[REDACTED]"
    assert sanitized["headers"]["Credential_Token"] == "[REDACTED]"
    assert "password=[REDACTED]" in sanitized["tags_set"]
    assert "api_key=[REDACTED]" in sanitized["config_tuple"][1]


def test_github_and_gitlab_token_redaction_comprehensive_cases():
    """Validates GitHub and GitLab token redaction across variable lengths, punctuation boundaries, multiple tokens, and near-miss inputs."""
    from epistemicos.audit import _sanitize_sensitive_data

    fine_grained_pat = "github_pat_11AAAAAAA0123456789abcdef_ghijklmnopqrstuvwxyz0123456789abcdef0123456789abcdef012"
    classic_ghp_36 = "ghp_123456789012345678901234567890123456"
    classic_ghp_40 = "ghp_1234567890123456789012345678901234567890"
    gitlab_pat = "glpat-12345678901234567890"
    gho_tok = "gho_123456789012345678901234567890123456"
    ghu_tok = "ghu_123456789012345678901234567890123456"
    ghs_tok = "ghs_123456789012345678901234567890123456"
    ghr_tok = "ghr_123456789012345678901234567890123456"
    hf_tok = "hf_1234567890123456789012345678901234"
    anthropic_key = "sk-ant-api03-abcdef1234567890abcdef1234567890abcdef1234567890-abcdef1234567890"
    anthropic_admin_key = "sk-ant-admin01-abcdef1234567890abcdef1234567890abcdef1234567890-abcdef1234567890"

    # Punctuation boundaries & multiple tokens
    ghp_underscore = "ghp_12345678901234567890_abcdef1234567890"
    ghs_jwt_installation = "ghs_987654_eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2MDAwMDAwMDB9.abcdefghijklmnopqrstuvwxyz_0123456789-ABCDEF"
    text = f"Tokens: ({fine_grained_pat}); [{classic_ghp_36}], {classic_ghp_40}, {gitlab_pat}, {gho_tok}, {ghu_tok}, {ghs_tok}, {ghr_tok}, {ghp_underscore}, {ghs_jwt_installation}, {anthropic_key}, {anthropic_admin_key}, and {hf_tok}."
    sanitized_text = _sanitize_sensitive_data(text)
    assert fine_grained_pat not in sanitized_text
    assert classic_ghp_36 not in sanitized_text
    assert classic_ghp_40 not in sanitized_text
    assert gitlab_pat not in sanitized_text
    assert gho_tok not in sanitized_text
    assert ghu_tok not in sanitized_text
    assert ghs_tok not in sanitized_text
    assert ghr_tok not in sanitized_text
    assert ghp_underscore not in sanitized_text
    assert ghs_jwt_installation not in sanitized_text
    assert anthropic_key not in sanitized_text
    assert anthropic_admin_key not in sanitized_text
    assert "sk-sk-[REDACTED]" not in sanitized_text
    assert hf_tok not in sanitized_text
    assert sanitized_text == "Tokens: (sk-[REDACTED]); [sk-[REDACTED]], sk-[REDACTED], sk-[REDACTED], sk-[REDACTED], sk-[REDACTED], sk-[REDACTED], sk-[REDACTED], sk-[REDACTED], sk-[REDACTED], sk-[REDACTED], sk-[REDACTED], and sk-[REDACTED]."

    # Near-miss inputs (should NOT be redacted)
    short_pat = "github_pat_short123456"
    short_ghp = "ghp_short123"
    short_glpat = "glpat-short123"
    short_gho = "gho_short123"
    short_ghs = "ghs_short123"
    short_hf = "hf_short12345678"
    short_ant_api = "sk-ant-api03-short"
    missing_prefix_ant = "ant-api03-short123"
    arbitrary_ghs = "ghs_notajwt_singlepart"
    two_part_ghs = "ghs_notajwt.twoparts"
    near_miss_text = f"Benign strings: {short_pat}, {short_ghp}, {short_glpat}, {short_gho}, {short_ghs}, {short_hf}, {short_ant_api}, {missing_prefix_ant}, {arbitrary_ghs}, and {two_part_ghs}"
    sanitized_near_miss = _sanitize_sensitive_data(near_miss_text)
    assert short_pat in sanitized_near_miss
    assert short_ghp in sanitized_near_miss
    assert short_glpat in sanitized_near_miss
    assert short_gho in sanitized_near_miss
    assert short_ghs in sanitized_near_miss
    assert short_hf in sanitized_near_miss
    assert short_ant_api in sanitized_near_miss
    assert missing_prefix_ant in sanitized_near_miss
    assert arbitrary_ghs in sanitized_near_miss
    assert two_part_ghs in sanitized_near_miss


def test_record_event_payload_too_large_multibyte(temp_audit_file):
    """Validates that payload snippets larger than 1MB in bytes (even if fewer chars) are rejected."""
    audit = TamperEvidentAuditTrail(temp_audit_file)
    # The character '🌍' (Earth globe) is 4 bytes in UTF-8.
    # 262144 characters * 4 bytes = 1048576 bytes.
    # We add 1 character so it exceeds 1MB in bytes, but is only 262,145 characters long.
    large_snippet = "🌍" * (262144 + 1)
    event = AuditEvent(AuditLogLevel.INFO, "gate", "reason", "model", large_snippet)
    with pytest.raises(ValueError, match="Payload snippet exceeds"):
        audit.record_event(event)
