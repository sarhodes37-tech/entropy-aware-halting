"""
EpistemicOS Control Plane Observatory - Data Adapters.

Extracts, aggregates, and validates data from EpistemicOS audit trails,
provenance stores, reconciliation reports, and benchmark result artifacts.
Enforces fail-closed error handling and explicit unavailable/unverified states.
"""

import json
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

from epistemicos.audit import TamperEvidentAuditTrail
from epistemicos.authorization import AuthorizationAuthority
from epistemicos.provenance import (
    LocalProvenanceStore,
    ProvenanceEvent,
    ProvenanceReconciler,
    ReconciliationReport
)


class ObservatoryDataAdapter:
    """
    Adapter reading raw EpistemicOS audit logs, provenance stores,
    and benchmark result JSON files to produce structured dashboard views.
    """

    def __init__(
        self,
        audit_log_path: str = "logs/epistemic_audit.jsonl",
        provenance_log_path: str = "logs/provenance_audit.jsonl",
        ablation_table_path: str = "results/ablation_table.json",
        per_case_results_path: str = "results/per_case_results.json",
        authority: Optional[AuthorizationAuthority] = None,
        allow_unverified_legacy: Optional[bool] = None
    ):
        self.audit_log_path = Path(audit_log_path)
        self.provenance_log_path = Path(provenance_log_path)
        self.ablation_table_path = Path(ablation_table_path)
        self.per_case_results_path = Path(per_case_results_path)
        self.authority = authority
        # Default allow_unverified_legacy=False unconditionally
        self.allow_unverified_legacy = False if allow_unverified_legacy is None else allow_unverified_legacy

    # -------------------------------------------------------------------------
    # Overview View Adapter
    # -------------------------------------------------------------------------
    def get_overview(self) -> Dict[str, Any]:
        """
        Derives overview metrics from actual audit and provenance stores.
        Uses explicit unavailable/unverified states when logs do not exist or are empty.
        """
        audit_integrity = self._verify_audit_integrity()
        provenance_integrity = self._verify_provenance_integrity()

        provenance_events, parse_errors = self._read_raw_provenance_events()
        audit_events, audit_parse_errors = self._read_raw_audit_events()

        # Metric derivations
        correlations = set()
        denials = 0
        halts = 0
        failures = 0

        for pe in provenance_events:
            corr = pe.get("correlation_id")
            if corr:
                correlations.add(corr)

            event_type = pe.get("event_type")
            if event_type == "AUTHORIZATION_DENIED":
                denials += 1
            elif event_type == "EGRESS_BLOCKED":
                halts += 1
            elif event_type in ("EXECUTION_FAILED", "EXECUTION_INTERRUPTED"):
                failures += 1

        for ae in audit_events:
            event_type = ae.get("event_type")
            if event_type == "DETERMINISTIC_HALT":
                halts += 1

        has_provenance_data = self.provenance_log_path.exists() and self.provenance_log_path.stat().st_size > 0
        has_audit_data = self.audit_log_path.exists() and self.audit_log_path.stat().st_size > 0

        return {
            "metrics": {
                "total_executions": len(correlations) if has_provenance_data else None,
                "authorization_denials": denials if has_provenance_data else None,
                "halts": halts if (has_provenance_data or has_audit_data) else None,
                "execution_failures": failures if has_provenance_data else None,
                "parse_error_count": parse_errors + audit_parse_errors
            },
            "status_flags": {
                "provenance_data_available": has_provenance_data,
                "audit_data_available": has_audit_data
            },
            "audit_integrity": audit_integrity,
            "provenance_integrity": provenance_integrity
        }

    # -------------------------------------------------------------------------
    # Execution Trace Explorer Adapter
    # -------------------------------------------------------------------------
    def get_execution_traces(self) -> List[Dict[str, Any]]:
        """
        Aggregates provenance and audit events by correlation_id into execution traces.
        """
        provenance_events, _ = self._read_raw_provenance_events()
        audit_events, _ = self._read_raw_audit_events()

        # Group provenance events by correlation_id
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        for pe in provenance_events:
            corr = pe.get("correlation_id") or "UNKNOWN_CORRELATION"
            grouped.setdefault(corr, []).append(pe)

        reconciler = ProvenanceReconciler(
            authority=self.authority,
            allow_unverified_legacy=self.allow_unverified_legacy
        )
        traces = []

        for corr_id, pe_list in grouped.items():
            # Convert raw dicts to ProvenanceEvent dataclasses for reconciler
            typed_events: List[ProvenanceEvent] = []
            for pe in pe_list:
                try:
                    filtered_pe = {
                        k: v for k, v in pe.items()
                        if k in ProvenanceEvent.__dataclass_fields__
                    }
                    typed_events.append(ProvenanceEvent(**filtered_pe))
                except Exception:
                    continue

            # Reconcile correlation
            reconciliation = reconciler.reconcile_correlation(corr_id, typed_events)

            # Determine lifecycle execution status
            status = self._determine_execution_status(pe_list, reconciliation=reconciliation)

            # Collect gate decisions and evidence
            gate_decisions = []
            auth_evidence = None
            action_name = "UNKNOWN"
            target = "UNKNOWN"
            request_id = "UNKNOWN"
            start_time = None
            end_time = None

            for pe in pe_list:
                if pe.get("action_name") and pe.get("action_name") != "UNKNOWN":
                    action_name = pe.get("action_name")
                if pe.get("target") and pe.get("target") != "UNKNOWN":
                    target = pe.get("target")
                if pe.get("request_id") and pe.get("request_id") != "UNKNOWN":
                    request_id = pe.get("request_id")

                ts = pe.get("timestamp")
                if ts:
                    if start_time is None or ts < start_time:
                        start_time = ts
                    if end_time is None or ts > end_time:
                        end_time = ts

                if pe.get("event_type") in ("AUTHORIZATION_GRANTED", "AUTHORIZATION_DENIED"):
                    gate_decisions.append({
                        "source": pe.get("provenance_source"),
                        "decision": pe.get("decision") or pe.get("event_type"),
                        "timestamp": pe.get("timestamp"),
                        "policy_version": pe.get("policy_version")
                    })
                    auth_evidence = {
                        "authorization_token_id": pe.get("authorization_token_id"),
                        "canonical_request_digest": pe.get("canonical_request_digest"),
                        "policy_version": pe.get("policy_version"),
                        "granted": pe.get("event_type") == "AUTHORIZATION_GRANTED"
                    }

            # Collect matching audit events for this correlation / request if available
            for ae in audit_events:
                meta = ae.get("metadata") or {}
                if meta.get("correlation_id") == corr_id or ae.get("event_id") == corr_id:
                    gate_decisions.append({
                        "source": ae.get("gate_name"),
                        "decision": ae.get("event_type"),
                        "timestamp": ae.get("timestamp"),
                        "reason": ae.get("reason")
                    })

            traces.append({
                "correlation_id": corr_id,
                "request_id": request_id,
                "action_name": action_name,
                "target": target,
                "status": status,
                "start_time": start_time or "UNKNOWN",
                "end_time": end_time or "UNKNOWN",
                "event_count": len(pe_list),
                "gate_decisions": gate_decisions,
                "authorization_evidence": auth_evidence or {
                    "authorization_token_id": None,
                    "canonical_request_digest": None,
                    "policy_version": None,
                    "granted": None
                },
                "reconciliation": reconciliation.to_dict(),
                "provenance_events": pe_list
            })

        # Sort by correlation_id descending or timestamp
        traces.sort(key=lambda t: t.get("start_time", ""), reverse=True)
        return traces

    def get_execution_trace_by_id(self, correlation_id: str) -> Optional[Dict[str, Any]]:
        """Retrieves a single execution trace by correlation_id."""
        traces = self.get_execution_traces()
        for trace in traces:
            if trace.get("correlation_id") == correlation_id:
                return trace
        return None

    # -------------------------------------------------------------------------
    # Provenance Explorer Adapter
    # -------------------------------------------------------------------------
    def get_provenance_explorer_data(self) -> Dict[str, Any]:
        """
        Returns all provenance events, 4-panel verification status summaries,
        actionable findings, hash chain integrity status, and explicit disclaimers.
        """
        events, parse_errors = self._read_raw_provenance_events()
        integrity = self._verify_provenance_integrity()

        file_exists = self.provenance_log_path.exists()
        file_size = self.provenance_log_path.stat().st_size if file_exists else 0

        # 1. Availability Status Panel
        if not file_exists:
            avail_status = "UNAVAILABLE"
            avail_msg = "Provenance log file does not exist on disk."
        elif len(events) == 0 and parse_errors == 0:
            avail_status = "EMPTY"
            avail_msg = "Provenance log file exists but contains zero records."
        elif parse_errors > 0 and len(events) == 0:
            avail_status = "UNREADABLE"
            avail_msg = f"Provenance log file exists but all lines failed to parse ({parse_errors} unparseable line(s))."
        elif parse_errors > 0 and len(events) > 0:
            avail_status = "PARTIAL"
            avail_msg = f"Log file partially readable ({len(events)} valid records, {parse_errors} unparseable line(s))."
        else:
            avail_status = "AVAILABLE"
            avail_msg = f"Log file fully accessible ({len(events)} valid records, 0 parse errors)."

        # 2. Coverage & Completeness Panel
        # Assess if executions have missing terminal events or reconciliation violations
        traces = self.get_execution_traces() if events else []
        incomplete_traces = [
            t for t in traces
            if (not t.get("reconciliation", {}).get("valid", True) or t.get("status") in ("OUTCOME_UNKNOWN", "MISMATCH"))
            and t.get("reconciliation", {}).get("status") != "UNVERIFIED_LEGACY_EVIDENCE"
        ]

        if not file_exists or len(events) == 0:
            coverage_status = "UNAVAILABLE"
            coverage_msg = "No provenance records available to assess event coverage."
        elif integrity.get("status") == "CORRUPTED":
            coverage_status = "UNVERIFIED"
            coverage_msg = "Cryptographic sequence chaining corruption positively detected; log continuity and trace completeness cannot be established."
        elif integrity.get("status") != "VERIFIED":
            coverage_status = "UNVERIFIED"
            coverage_msg = "Cryptographic sequence chaining integrity unverified; log continuity and trace completeness cannot be established."
        elif incomplete_traces:
            coverage_status = "INCOMPLETE"
            coverage_msg = f"{len(incomplete_traces)} of {len(traces)} execution trace(s) have missing terminal outcome events or reconciliation violations."
        else:
            coverage_status = "UNVERIFIED"
            coverage_msg = "Valid local cryptographic sequence chaining verifies log continuity, but cannot establish whether unrecorded external actions occurred."

        # 3. Source Authenticity Panel
        authenticity_status = "NOT ESTABLISHED"
        authenticity_msg = (
            "Local process log storage lacks independent hardware enclave attestations or "
            "asymmetric cryptographic signatures to prove external source authenticity."
        )

        # 4. Actionable Verification Findings List
        findings = []

        if not file_exists:
            findings.append({
                "severity": "WARNING",
                "code": "LOG_FILE_MISSING",
                "title": "Provenance Log File Missing",
                "description": f"Log file at path '{self.provenance_log_path}' was not found."
            })

        if parse_errors > 0:
            findings.append({
                "severity": "HIGH",
                "code": "PARSE_ERRORS_DETECTED",
                "title": f"Malformed Log Entries ({parse_errors})",
                "description": f"Detected {parse_errors} unparseable line(s) in provenance log file."
            })

        if integrity.get("status") == "CORRUPTED":
            findings.append({
                "severity": "CRITICAL",
                "code": "HASH_CHAIN_CORRUPTED",
                "title": "Cryptographic Hash Chain Broken",
                "description": integrity.get("message", "Sequence number or prev_hash mismatch detected in local store.")
            })
        elif integrity.get("status") == "UNVERIFIED":
            findings.append({
                "severity": "WARNING",
                "code": "INTEGRITY_UNVERIFIED",
                "title": "Cryptographic Integrity Unverified",
                "description": integrity.get("message", "Integrity check failed to execute to completion.")
            })

        if incomplete_traces:
            findings.append({
                "severity": "HIGH",
                "code": "INCOMPLETE_EXECUTION_TRACES",
                "title": f"Incomplete Trace Evidence ({len(incomplete_traces)})",
                "description": f"{len(incomplete_traces)} trace(s) lack matching terminal events or exhibit reconciliation violations."
            })

        findings.append({
            "severity": "INFO",
            "code": "AUTHENTICITY_LIMITATION",
            "title": "Source Authenticity Unestablished",
            "description": "Local process logs do not provide non-repudiable cryptographic source identity."
        })

        findings.append({
            "severity": "INFO",
            "code": "COMPLETENESS_LIMITATION",
            "title": "Trace Completeness Unverified",
            "description": "Valid append-only hash chains establish sequence order, not proof that all relevant actions were logged."
        })

        summary_panels = {
            "availability": {
                "status": avail_status,
                "file_exists": file_exists,
                "file_size_bytes": file_size,
                "record_count": len(events),
                "parse_error_count": parse_errors,
                "message": avail_msg,
                "scope": "Evaluates physical presence and readable JSON line formatting of the local append-only provenance log file."
            },
            "integrity": {
                "status": integrity.get("status", "UNAVAILABLE"),
                "valid": integrity.get("valid"),
                "records_verified": integrity.get("records_verified", 0),
                "last_hash": integrity.get("last_hash"),
                "message": integrity.get("message", "Integrity status unavailable."),
                "scope": "Evaluates SHA-256 hash chain continuity across sequence_number and prev_hash links within the local store."
            },
            "coverage": {
                "status": coverage_status,
                "message": coverage_msg,
                "scope": "Assesses whether all expected lifecycle events are recorded for observed executions. Valid local hash chaining alone does NOT prove event completeness."
            },
            "authenticity": {
                "status": authenticity_status,
                "message": authenticity_msg,
                "scope": "Assesses cryptographic origin and non-repudiation of event sources. Local process logs do not constitute an independent hardware trust boundary."
            }
        }

        return {
            "disclaimer": (
                "DISCLAIMER: Valid cryptographic hash chain integrity verifies local "
                "append-only sequence chaining, but does NOT prove external source authenticity, "
                "non-repudiation, or trace completeness."
            ),
            "summary_panels": summary_panels,
            "findings": findings,
            "integrity": integrity,
            "parse_error_count": parse_errors,
            "events": events
        }

    # -------------------------------------------------------------------------
    # Benchmark Workbench Adapter
    # -------------------------------------------------------------------------
    def get_benchmark_data(self) -> Dict[str, Any]:
        """
        Loads measured benchmark results from results/ablation_table.json
        and results/per_case_results.json.
        Returns structured status fields ('AVAILABLE', 'EMPTY', 'MALFORMED', 'UNAVAILABLE')
        alongside backward-compatible available, data, and error fields.
        """
        ablation_table = None
        ablation_error = None
        ablation_status = "UNAVAILABLE"

        per_case_results = None
        per_case_error = None
        per_case_status = "UNAVAILABLE"

        if self.ablation_table_path.exists():
            if self.ablation_table_path.stat().st_size == 0:
                ablation_status = "EMPTY"
                ablation_error = "File is empty: results/ablation_table.json"
            else:
                try:
                    with open(self.ablation_table_path, "r", encoding="utf-8") as f:
                        loaded = json.load(f)
                        if isinstance(loaded, dict):
                            ablation_table = loaded
                            if not loaded or not loaded.get("baselines"):
                                ablation_status = "EMPTY"
                                ablation_error = ablation_error or "Artifact contains zero baselines: results/ablation_table.json"
                            else:
                                ablation_status = "AVAILABLE"
                        else:
                            ablation_status = "MALFORMED"
                            ablation_error = f"Unexpected JSON structure in ablation table: expected object, got {type(loaded).__name__}"
                except Exception as e:
                    ablation_status = "MALFORMED"
                    ablation_error = f"Malformed JSON in ablation table: {str(e)}"
        else:
            ablation_status = "UNAVAILABLE"
            ablation_error = "File not found: results/ablation_table.json"

        if self.per_case_results_path.exists():
            if self.per_case_results_path.stat().st_size == 0:
                per_case_status = "EMPTY"
                per_case_error = "File is empty: results/per_case_results.json"
            else:
                try:
                    with open(self.per_case_results_path, "r", encoding="utf-8") as f:
                        loaded = json.load(f)
                        if isinstance(loaded, list):
                            per_case_results = loaded
                            if len(loaded) == 0:
                                per_case_status = "EMPTY"
                                per_case_error = per_case_error or "Artifact contains zero per-case results: results/per_case_results.json"
                            else:
                                per_case_status = "AVAILABLE"
                        else:
                            per_case_status = "MALFORMED"
                            per_case_error = f"Unexpected JSON structure in per-case results: expected list, got {type(loaded).__name__}"
                except Exception as e:
                    per_case_status = "MALFORMED"
                    per_case_error = f"Malformed JSON in per-case results: {str(e)}"
        else:
            per_case_status = "UNAVAILABLE"
            per_case_error = "File not found: results/per_case_results.json"

        return {
            "ablation_table": {
                "status": ablation_status,
                "available": ablation_table is not None,
                "data": ablation_table,
                "error": ablation_error
            },
            "per_case_results": {
                "status": per_case_status,
                "available": per_case_results is not None,
                "data": per_case_results,
                "error": per_case_error
            }
        }

    # -------------------------------------------------------------------------
    # Private Helper Methods
    # -------------------------------------------------------------------------
    def _read_raw_provenance_events(self) -> Tuple[List[Dict[str, Any]], int]:
        events = []
        parse_errors = 0
        if not self.provenance_log_path.exists():
            return events, parse_errors

        with open(self.provenance_log_path, "r", encoding="utf-8") as f:
            for line in f:
                line_str = line.strip()
                if not line_str:
                    continue
                try:
                    data = json.loads(line_str)
                    if isinstance(data, dict):
                        events.append(data)
                    else:
                        parse_errors += 1
                except Exception:
                    parse_errors += 1
        return events, parse_errors

    def _read_raw_audit_events(self) -> Tuple[List[Dict[str, Any]], int]:
        events = []
        parse_errors = 0
        if not self.audit_log_path.exists():
            return events, parse_errors

        with open(self.audit_log_path, "r", encoding="utf-8") as f:
            for line in f:
                line_str = line.strip()
                if not line_str:
                    continue
                try:
                    data = json.loads(line_str)
                    if isinstance(data, dict):
                        events.append(data)
                    else:
                        parse_errors += 1
                except Exception:
                    parse_errors += 1
        return events, parse_errors

    def _verify_audit_integrity(self) -> Dict[str, Any]:
        if not self.audit_log_path.exists():
            return {
                "status": "UNAVAILABLE",
                "valid": None,
                "records_verified": 0,
                "message": "Audit log file does not exist"
            }
        try:
            trail = TamperEvidentAuditTrail(log_file_path=str(self.audit_log_path))
            valid, count, err = trail.verify_chain_integrity()
            return {
                "status": "VERIFIED" if valid else "CORRUPTED",
                "valid": valid,
                "records_verified": count,
                "message": err or ("Integrity verified successfully" if valid else "Chain corruption detected")
            }
        except Exception as e:
            return {
                "status": "UNVERIFIED",
                "valid": None,
                "records_verified": 0,
                "message": f"Verification execution failed: {str(e)}"
            }

    def _verify_provenance_integrity(self) -> Dict[str, Any]:
        if not self.provenance_log_path.exists():
            return {
                "status": "UNAVAILABLE",
                "valid": None,
                "records_verified": 0,
                "message": "Provenance log file does not exist"
            }
        try:
            store = LocalProvenanceStore(log_path=str(self.provenance_log_path))
            healthy, last_hash, count, _ = store._inspect_health()
            return {
                "status": "VERIFIED" if healthy else "CORRUPTED",
                "valid": healthy,
                "last_hash": last_hash,
                "records_verified": count,
                "message": "Integrity verified successfully" if healthy else "Chain corruption detected"
            }
        except Exception as e:
            return {
                "status": "UNVERIFIED",
                "valid": None,
                "records_verified": 0,
                "message": f"Verification execution failed: {str(e)}"
            }

    def _determine_execution_status(
        self,
        events: List[Dict[str, Any]],
        reconciliation: Optional[ReconciliationReport] = None
    ) -> str:
        """
        Determines execution outcome state:
        DENIED, HALTED, COMPLETED, FAILED, UNVERIFIED, MISMATCH, or OUTCOME_UNKNOWN.
        Never masks evidence mismatches as executor FAILED.
        """
        event_types = [e.get("event_type") for e in events]

        # Explicit priority: Governance decisions (denials and halts)
        if "AUTHORIZATION_DENIED" in event_types:
            return "DENIED"
        if "EGRESS_BLOCKED" in event_types:
            return "HALTED"

        # Gate 1: Evidence reconciliation mismatch or forgery maps to MISMATCH
        # (Evidence-integrity failures must remain distinguishable from verified executor failures)
        if reconciliation is not None:
            if reconciliation.status == "RECONCILIATION_MISMATCH":
                # If execution started but terminal outcome is missing, map to OUTCOME_UNKNOWN
                if "EXECUTION_STARTED" in event_types and not any(t in event_types for t in ("EXECUTION_SUCCEEDED", "EXECUTION_FAILED", "EXECUTION_INTERRUPTED")):
                    return "OUTCOME_UNKNOWN"
                return "MISMATCH"

        # Authenticated executor failure -> FAILED (as long as there is no evidence mismatch)
        if "EXECUTION_FAILED" in event_types or "EXECUTION_INTERRUPTED" in event_types:
            return "FAILED"

        # Gate 2: COMPLETED requires verified reconciliation AND genuine EXECUTION_SUCCEEDED
        if "EXECUTION_SUCCEEDED" in event_types:
            if reconciliation is not None and reconciliation.status == "RECONCILED" and reconciliation.valid:
                return "COMPLETED"
            elif reconciliation is not None and reconciliation.status == "UNVERIFIED_LEGACY_EVIDENCE":
                return "UNVERIFIED"
            elif reconciliation is not None and reconciliation.status == "INCOMPLETE_EVIDENCE":
                return "UNVERIFIED"
            elif reconciliation is not None and not reconciliation.valid:
                return "MISMATCH"
            return "UNVERIFIED"

        if "EXECUTION_STARTED" in event_types:
            return "OUTCOME_UNKNOWN"

        return "OUTCOME_UNKNOWN"
