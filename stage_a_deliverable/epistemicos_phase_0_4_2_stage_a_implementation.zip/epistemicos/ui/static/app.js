/**
 * EpistemicOS Control Plane Observatory - Client Application.
 *
 * Implements read-only client dashboard interface for:
 * 1. System Overview Metrics & Integrity Status
 * 2. Execution Trace Explorer & Evidence Inspector
 * 3. Provenance Chain Explorer
 * 4. Benchmark Workbench
 *
 * Security Directive: All dynamic data rendering strictly uses textContent
 * and standard DOM element creation to eliminate XSS risks from untrusted event payloads.
 */

document.addEventListener('DOMContentLoaded', () => {
  const ObservatoryApp = {
    state: {
      currentTab: 'overview',
      overviewData: null,
      tracesData: [],
      selectedTraceId: null,
      selectedEventSeq: null,
      mobileTraceLevel: 'list', // 'list', 'detail', or 'event'
      provenanceData: null,
      selectedRecordId: null,
      benchmarkData: null,
      traceFilterStatus: 'ALL',
      traceSearchQuery: '',
      provenanceFilterType: 'ALL',
      provenanceSearchQuery: '',
      selectedCaseIndex: null,
      caseSearchQuery: '',
      caseBaselineFilter: 'ALL',
      caseFamilyFilter: 'ALL',
      caseOutcomeFilter: 'ALL'
    },

    init() {
      this.bindEvents();
      this.loadOverview();
    },

    bindEvents() {
      // Primary Tab Navigation
      const tabs = Array.from(document.querySelectorAll('.nav-tab'));
      tabs.forEach((tabBtn, index) => {
        tabBtn.addEventListener('click', (e) => {
          const tabName = e.currentTarget.getAttribute('data-tab');
          this.switchTab(tabName);
        });

        tabBtn.addEventListener('keydown', (e) => {
          let targetIndex = null;
          if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
            targetIndex = (index + 1) % tabs.length;
          } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
            targetIndex = (index - 1 + tabs.length) % tabs.length;
          } else if (e.key === 'Home') {
            targetIndex = 0;
          } else if (e.key === 'End') {
            targetIndex = tabs.length - 1;
          }

          if (targetIndex !== null) {
            e.preventDefault();
            const targetTab = tabs[targetIndex];
            const tabName = targetTab.getAttribute('data-tab');
            this.switchTab(tabName);
            targetTab.focus();
          }
        });
      });

      // Quick Entry / Investigative Shortcuts Navigation
      document.querySelectorAll('[data-jump-tab]').forEach(btn => {
        btn.addEventListener('click', (e) => {
          const targetTab = e.currentTarget.getAttribute('data-jump-tab');
          const filter = e.currentTarget.getAttribute('data-filter');

          if (filter && targetTab === 'traces') {
            this.state.traceFilterStatus = filter;
            const filterSelect = document.getElementById('trace-status-filter');
            if (filterSelect) filterSelect.value = filter;
          }
          this.switchTab(targetTab);
          if (filter && targetTab === 'traces') {
            this.announce(`Navigated to Execution Trace Explorer (Filtered: ${filter})`);
            const targetFocusEl = document.getElementById('trace-status-filter') || document.getElementById('trace-search');
            if (targetFocusEl) targetFocusEl.focus();
          }
        });
      });

      // Overview Refresh
      const btnRefreshOverview = document.getElementById('btn-refresh-overview');
      if (btnRefreshOverview) {
        btnRefreshOverview.addEventListener('click', () => this.loadOverview());
      }

      // Execution Trace Search & Filters
      const searchInput = document.getElementById('trace-search');
      if (searchInput) {
        searchInput.addEventListener('input', (e) => {
          const prevQuery = this.state.traceSearchQuery;
          this.state.traceSearchQuery = e.target.value.toLowerCase().trim();
          if (prevQuery && !this.state.traceSearchQuery) {
            this.announce('Trace search cleared.');
          }
          this.renderTracesList();
        });
        searchInput.addEventListener('keydown', (e) => {
          if (e.key === 'Escape') {
            if (searchInput.value) {
              searchInput.value = '';
              this.state.traceSearchQuery = '';
              this.announce('Trace search cleared.');
              this.renderTracesList();
            } else {
              searchInput.blur();
            }
          }
        });
      }

      const statusFilter = document.getElementById('trace-status-filter');
      if (statusFilter) {
        statusFilter.addEventListener('change', (e) => {
          this.state.traceFilterStatus = e.target.value;
          const msg = e.target.value === 'ALL'
            ? 'Trace status filter reset: showing all statuses.'
            : `Trace status filter applied: ${e.target.value}.`;
          this.announce(msg);
          this.renderTracesList();
        });
      }

      // Mobile Drill-In Back Button Handlers
      const btnBackToList = document.getElementById('btn-trace-back-to-list');
      if (btnBackToList) {
        btnBackToList.addEventListener('click', () => {
          this.updateMobileTraceView('list');
          this.announce('Returned to execution trace list.');
          // Return focus to selected trace item if possible
          if (this.state.selectedTraceId) {
            const selectedItem = document.querySelector('#trace-list .trace-item.active');
            if (selectedItem) selectedItem.focus();
          }
        });
      }

      const btnBackToDetail = document.getElementById('btn-trace-back-to-detail');
      if (btnBackToDetail) {
        btnBackToDetail.addEventListener('click', () => {
          this.updateMobileTraceView('detail');
          this.announce('Returned to trace lifecycle overview.');
          // Return focus to selected stage card if possible
          if (this.state.selectedEventSeq !== null && this.state.selectedEventSeq !== undefined) {
            const selectedStage = document.querySelector('.lifecycle-stage.selected .lifecycle-stage-card');
            if (selectedStage) selectedStage.focus();
          }
        });
      }

      // Provenance Search & Filter Controls
      const provSearchInput = document.getElementById('provenance-search');
      if (provSearchInput) {
        provSearchInput.addEventListener('input', (e) => {
          const prevQuery = this.state.provenanceSearchQuery;
          this.state.provenanceSearchQuery = e.target.value.toLowerCase().trim();
          if (prevQuery && !this.state.provenanceSearchQuery) {
            this.announce('Provenance search cleared.');
          }
          this.renderProvenanceRecordList();
        });
        provSearchInput.addEventListener('keydown', (e) => {
          if (e.key === 'Escape') {
            if (provSearchInput.value) {
              provSearchInput.value = '';
              this.state.provenanceSearchQuery = '';
              this.announce('Provenance search cleared.');
              this.renderProvenanceRecordList();
            } else {
              provSearchInput.blur();
            }
          }
        });
      }

      const provTypeFilter = document.getElementById('provenance-type-filter');
      if (provTypeFilter) {
        provTypeFilter.addEventListener('change', (e) => {
          this.state.provenanceFilterType = e.target.value;
          const msg = e.target.value === 'ALL'
            ? 'Provenance event type filter reset: showing all event types.'
            : `Provenance event type filter applied: ${e.target.value}.`;
          this.announce(msg);
          this.renderProvenanceRecordList();
        });
      }

      // Benchmark Workbench Filter Controls
      const caseSearchInput = document.getElementById('benchmark-case-search');
      if (caseSearchInput) {
        caseSearchInput.addEventListener('input', (e) => {
          const prevQuery = this.state.caseSearchQuery;
          this.state.caseSearchQuery = e.target.value.toLowerCase().trim();
          if (prevQuery && !this.state.caseSearchQuery) {
            this.announce('Benchmark case search cleared.');
          }
          this.renderBenchmarkCasesList();
        });
        caseSearchInput.addEventListener('keydown', (e) => {
          if (e.key === 'Escape') {
            if (caseSearchInput.value) {
              caseSearchInput.value = '';
              this.state.caseSearchQuery = '';
              this.announce('Benchmark case search cleared.');
              this.renderBenchmarkCasesList();
            } else {
              caseSearchInput.blur();
            }
          }
        });
      }

      const caseBaseFilterSelect = document.getElementById('benchmark-case-baseline-filter');
      if (caseBaseFilterSelect) {
        caseBaseFilterSelect.addEventListener('change', (e) => {
          this.state.caseBaselineFilter = e.target.value;
          const msg = e.target.value === 'ALL'
            ? 'Benchmark baseline filter reset: showing all baselines.'
            : `Benchmark baseline filter applied: ${e.target.value}.`;
          this.announce(msg);
          this.renderBenchmarkCasesList();
        });
      }

      const caseFamilyFilterSelect = document.getElementById('benchmark-case-family-filter');
      if (caseFamilyFilterSelect) {
        caseFamilyFilterSelect.addEventListener('change', (e) => {
          this.state.caseFamilyFilter = e.target.value;
          const msg = e.target.value === 'ALL'
            ? 'Benchmark scenario family filter reset: showing all families.'
            : `Benchmark scenario family filter applied: ${e.target.value}.`;
          this.announce(msg);
          this.renderBenchmarkCasesList();
        });
      }

      const caseOutcomeFilterSelect = document.getElementById('benchmark-case-outcome-filter');
      if (caseOutcomeFilterSelect) {
        caseOutcomeFilterSelect.addEventListener('change', (e) => {
          this.state.caseOutcomeFilter = e.target.value;
          const msg = e.target.value === 'ALL'
            ? 'Benchmark outcome filter reset: showing all outcomes.'
            : `Benchmark outcome filter applied: ${e.target.value}.`;
          this.announce(msg);
          this.renderBenchmarkCasesList();
        });
      }

      // Global Keyboard Shortcut: '/' to focus active tab search input
      document.addEventListener('keydown', (e) => {
        if (e.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) {
          let searchInput = null;
          if (this.state.currentTab === 'traces') searchInput = document.getElementById('trace-search');
          else if (this.state.currentTab === 'provenance') searchInput = document.getElementById('provenance-search');
          else if (this.state.currentTab === 'benchmarks') searchInput = document.getElementById('benchmark-case-search');

          if (searchInput) {
            e.preventDefault();
            searchInput.focus();
            searchInput.select();
          }
        }
      });
    },

    announce(message) {
      const announcer = document.getElementById('a11y-status-announcer');
      if (announcer) {
        announcer.textContent = '';
        setTimeout(() => {
          announcer.textContent = message;
        }, 50);
      }
    },

    switchTab(tabName) {
      this.state.currentTab = tabName;
      document.querySelectorAll('.nav-tab').forEach(btn => {
        const isActive = btn.getAttribute('data-tab') === tabName;
        btn.classList.toggle('active', isActive);
        btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
        btn.setAttribute('tabindex', isActive ? '0' : '-1');

        if (isActive && typeof btn.scrollIntoView === 'function') {
          const prefersReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
          const scrollBehavior = prefersReducedMotion ? 'auto' : 'smooth';
          btn.scrollIntoView({ behavior: scrollBehavior, block: 'nearest', inline: 'nearest' });
        }
      });

      const tabTitles = {
        overview: 'System Executive Overview',
        traces: 'Execution Trace Explorer',
        provenance: 'Provenance Explorer',
        benchmarks: 'Benchmark Workbench'
      };
      const mobileTitleEl = document.getElementById('mobile-current-title');
      if (mobileTitleEl) {
        mobileTitleEl.textContent = tabTitles[tabName] || tabName;
      }

      document.querySelectorAll('.view-panel').forEach(panel => {
        panel.classList.toggle('active', panel.id === `view-${tabName}`);
      });

      this.announce(`Navigated to ${tabTitles[tabName] || tabName}`);

      if (tabName === 'overview') this.loadOverview();
      else if (tabName === 'traces') {
        this.loadTraces();
        const hasSelectedEvent = this.state.selectedEventSeq !== null && this.state.selectedEventSeq !== undefined;
        this.updateMobileTraceView(this.state.selectedTraceId ? (hasSelectedEvent ? 'event' : 'detail') : 'list');
      }
      else if (tabName === 'provenance') this.loadProvenance();
      else if (tabName === 'benchmarks') this.loadBenchmarks();
    },

    updateMobileTraceView(level) {
      this.state.mobileTraceLevel = level; // 'list', 'detail', or 'event'
      const traceLayout = document.getElementById('trace-layout');
      const traceNavBar = document.getElementById('trace-nav-bar');
      const btnBackToList = document.getElementById('btn-trace-back-to-list');
      const btnBackToDetail = document.getElementById('btn-trace-back-to-detail');
      const breadcrumbEl = document.getElementById('trace-breadcrumb');

      if (traceLayout) {
        traceLayout.classList.remove('mobile-view-list', 'mobile-view-detail', 'mobile-view-event');
        traceLayout.classList.add(`mobile-view-${level}`);
      }

      if (!traceNavBar) return;

      if (level === 'list' || !this.state.selectedTraceId) {
        traceNavBar.classList.add('hidden');
        if (btnBackToList) btnBackToList.classList.add('hidden');
        if (btnBackToDetail) btnBackToDetail.classList.add('hidden');
        if (breadcrumbEl) breadcrumbEl.replaceChildren();
      } else if (level === 'detail') {
        traceNavBar.classList.remove('hidden');
        if (btnBackToList) btnBackToList.classList.remove('hidden');
        if (btnBackToDetail) btnBackToDetail.classList.add('hidden');
        if (breadcrumbEl) {
          breadcrumbEl.replaceChildren();
          breadcrumbEl.appendChild(document.createTextNode('Trace: '));
          const strong = document.createElement('strong');
          strong.textContent = this.state.selectedTraceId;
          breadcrumbEl.appendChild(strong);
        }
      } else if (level === 'event') {
        traceNavBar.classList.remove('hidden');
        if (btnBackToList) btnBackToList.classList.add('hidden');
        if (btnBackToDetail) btnBackToDetail.classList.remove('hidden');
        if (breadcrumbEl) {
          breadcrumbEl.replaceChildren();
          breadcrumbEl.appendChild(document.createTextNode('Trace: '));
          const strong = document.createElement('strong');
          strong.textContent = this.state.selectedTraceId;
          breadcrumbEl.appendChild(strong);
          if (this.state.selectedEventSeq !== null && this.state.selectedEventSeq !== undefined) {
            breadcrumbEl.appendChild(document.createTextNode(` / Event #${this.state.selectedEventSeq}`));
          }
        }
      }
    },

    // -------------------------------------------------------------------------
    // Helper: Async Action Execution with Accessible Loading State
    // -------------------------------------------------------------------------
    async executeWithRetryFeedback(btn, loadingText, actionFn) {
      if (!btn || btn.disabled) return;
      const origDisabled = btn.disabled;
      const origAriaBusy = btn.getAttribute('aria-busy');
      const origTitle = btn.getAttribute('title');
      const origText = btn.textContent;
      btn.disabled = true;
      btn.setAttribute('aria-busy', 'true');
      btn.textContent = loadingText;
      btn.setAttribute('title', loadingText);
      try {
        this.announce(loadingText);
        await actionFn();
      } finally {
        if (btn && btn.isConnected) {
          btn.disabled = origDisabled;
          if (origAriaBusy !== null) btn.setAttribute('aria-busy', origAriaBusy);
          else btn.removeAttribute('aria-busy');
          if (origTitle !== null) btn.setAttribute('title', origTitle);
          else btn.removeAttribute('title');
          btn.textContent = origText;
        }
      }
    },

    // -------------------------------------------------------------------------
    // Helper: Clipboard Copy Action
    // -------------------------------------------------------------------------
    copyToClipboard(text, btnElement) {
      if (!text) return;
      const origAriaLabel = btnElement ? btnElement.getAttribute('aria-label') : null;
      const origTitle = btnElement ? btnElement.getAttribute('title') : null;

      const restoreState = (origText) => {
        if (!btnElement) return;
        btnElement.textContent = origText;
        if (origAriaLabel !== null) {
          btnElement.setAttribute('aria-label', origAriaLabel);
        } else {
          btnElement.removeAttribute('aria-label');
        }
        if (origTitle !== null) {
          btnElement.setAttribute('title', origTitle);
        } else {
          btnElement.removeAttribute('title');
        }
      };

      if (!navigator.clipboard || !navigator.clipboard.writeText) {
        this.announce('Copy to clipboard unavailable.');
        if (btnElement) {
          const origText = btnElement.textContent;
          btnElement.textContent = 'Copy Unavailable';
          btnElement.setAttribute('aria-label', 'Copy unavailable');
          btnElement.setAttribute('title', 'Copy unavailable in this browser context');
          btnElement.style.borderColor = 'var(--status-failed-border)';
          setTimeout(() => {
            restoreState(origText);
            btnElement.style.borderColor = '';
          }, 2000);
        }
        return;
      }

      navigator.clipboard.writeText(text).then(() => {
        this.announce('Copied to clipboard.');
        if (btnElement) {
          const origText = btnElement.textContent;
          btnElement.textContent = '✓ Copied!';
          btnElement.setAttribute('aria-label', 'Copied to clipboard!');
          btnElement.setAttribute('title', 'Copied to clipboard!');
          btnElement.classList.add('copied');
          setTimeout(() => {
            restoreState(origText);
            btnElement.classList.remove('copied');
          }, 1500);
        }
      }).catch(err => {
        console.error('Copy failed:', err);
        this.announce('Failed to copy to clipboard.');
        if (btnElement) {
          const origText = btnElement.textContent;
          btnElement.textContent = 'Copy Failed';
          btnElement.setAttribute('aria-label', 'Copy failed');
          btnElement.setAttribute('title', 'Copy action failed');
          btnElement.style.borderColor = 'var(--status-failed-border)';
          setTimeout(() => {
            restoreState(origText);
            btnElement.style.borderColor = '';
          }, 2000);
        }
      });
    },

    // Pure status decision helper for aggregate benchmark evidence status
    deriveCombinedBenchmarkStatus(ablStatus, pcStatus) {
      const s1 = (ablStatus || 'UNAVAILABLE').toUpperCase();
      const s2 = (pcStatus || 'UNAVAILABLE').toUpperCase();

      // Rule 1: Both usable -> AVAILABLE
      if (s1 === 'AVAILABLE' && s2 === 'AVAILABLE') {
        return 'AVAILABLE';
      }

      // Rule 2: Exactly one usable -> PARTIAL (usable data exists, but evidence set is degraded/incomplete)
      if (s1 === 'AVAILABLE' || s2 === 'AVAILABLE') {
        return 'PARTIAL';
      }

      // Rule 3: Zero usable data (neither is AVAILABLE)
      // Prioritize error visibility: MALFORMED > EMPTY > UNAVAILABLE
      if (s1 === 'MALFORMED' || s2 === 'MALFORMED') {
        return 'MALFORMED';
      }
      if (s1 === 'EMPTY' || s2 === 'EMPTY') {
        return 'EMPTY';
      }
      return 'UNAVAILABLE';
    },

    // -------------------------------------------------------------------------
    // Pure Telemetry Validation & State Derivation Functions
    // -------------------------------------------------------------------------
    /**
     * Normalizes a metric value.
     * Rejects booleans, NaN, Infinity, negative numbers, objects, arrays, and malformed strings.
     * Returns: { status: 'VALID' | 'UNAVAILABLE' | 'INVALID', value: number | null }
     */
    normalizeMetricValue(rawVal) {
      if (rawVal === null || rawVal === undefined) {
        return { status: 'UNAVAILABLE', value: null };
      }
      if (typeof rawVal === 'boolean') {
        return { status: 'INVALID', value: null };
      }
      if (typeof rawVal === 'number') {
        if (!Number.isFinite(rawVal) || rawVal < 0 || !Number.isInteger(rawVal)) {
          return { status: 'INVALID', value: null };
        }
        return { status: 'VALID', value: rawVal };
      }
      if (typeof rawVal === 'string') {
        const trimmed = rawVal.trim();
        if (trimmed === '' || !/^\d+$/.test(trimmed)) {
          return { status: 'INVALID', value: null };
        }
        const num = Number(trimmed);
        if (!Number.isSafeInteger(num) || num < 0) {
          return { status: 'INVALID', value: null };
        }
        return { status: 'VALID', value: num };
      }
      return { status: 'INVALID', value: null };
    },

    /**
     * Normalizes a boolean status flag strictly.
     * Only genuine boolean true is accepted as true.
     * Strings like "false", numbers, null, undefined, or other objects are rejected as false.
     */
    normalizeBooleanFlag(val) {
      return typeof val === 'boolean' ? val : false;
    },

    /**
     * Calculates cumulative exception telemetry with completeness verification.
     *
     * Invariants:
     * - A partial sum CANNOT be presented as a complete cumulative total.
     * - If all required counters are VALID, returns status: 'COMPLETE' and total sum.
     * - If all counters are UNAVAILABLE, returns status: 'UNAVAILABLE'.
     * - If some counters are valid and some are unavailable, returns status: 'PARTIAL'
     *   and exposes which inputs are missing.
     * - If any counter is INVALID, returns status: 'MALFORMED' and exposes which inputs are invalid.
     * - Does NOT silently treat missing values as zero.
     *
     * @param {object} metrics
     * @returns { status: 'COMPLETE'|'PARTIAL'|'UNAVAILABLE'|'MALFORMED', total: number|null, missing: string[], invalid: string[], details: object }
     */
    calculateCumulativeExceptions(metrics) {
      const m = metrics || {};
      const requiredCounters = [
        { key: 'authorization_denials', label: 'Auth Denials', val: m.authorization_denials },
        { key: 'halts', label: 'Policy Halts', val: m.halts },
        { key: 'execution_failures', label: 'Execution Failures', val: m.execution_failures },
        { key: 'parse_error_count', label: 'Parse Errors', val: m.parse_error_count }
      ];

      const missing = [];
      const invalid = [];
      let total = 0;

      requiredCounters.forEach(c => {
        const norm = this.normalizeMetricValue(c.val);
        if (norm.status === 'INVALID') {
          invalid.push(c.label);
        } else if (norm.status === 'UNAVAILABLE') {
          missing.push(c.label);
        } else {
          total += norm.value;
        }
      });

      if (invalid.length > 0) {
        return {
          status: 'MALFORMED',
          total: null,
          missing,
          invalid,
          reason: `Malformed counter data detected in: ${invalid.join(', ')}`
        };
      }

      if (missing.length === requiredCounters.length) {
        return {
          status: 'UNAVAILABLE',
          total: null,
          missing,
          invalid: [],
          reason: 'All cumulative exception counters unavailable'
        };
      }

      if (missing.length > 0) {
        return {
          status: 'PARTIAL',
          total: null,
          partialSum: total,
          missing,
          invalid: [],
          reason: `Partial exception telemetry: missing ${missing.join(', ')}`
        };
      }

      return {
        status: 'COMPLETE',
        total,
        missing: [],
        invalid: [],
        reason: `Complete cumulative exceptions: ${total}`
      };
    },

    /**
     * Derives aggregate system operational state from overview telemetry.
     *
     * Epistemic Separation of Dimensions:
     * A. Cryptographic Integrity: Are observed audit & provenance records cryptographically consistent?
     * B. Historical Activity: Cumulative records of past executions, denials, halts, and failures.
     *    Cumulative historical counters DO NOT constitute proof of current runtime blockage, halt, or degradation.
     * C. Current Operational Health: Requires an authoritative live runtime health signal or active incident feed.
     *    Trust Boundary & Verification Contract:
     *    Asserting READY is strictly forbidden based solely on caller-controlled source strings,
     *    arbitrary status objects like { status: 'HEALTHY' }, or unauthenticated inputs.
     *    In this architecture, live operational health requires:
     *    1. Trusted supervisory source identity.
     *    2. Observation timestamp and freshness verification (monotonic, bounded staleness).
     *    3. Cryptographic attestation verified against a trusted authority with replay protection.
     *    Because no authoritative live-health attestation infrastructure exists in the backend adapter,
     *    any supplied unverified or unauthenticated live health signal must be rejected.
     *    Therefore, when cryptographic integrity is verified, operational readiness strictly remains NOT ESTABLISHED.
     * D. Evidence Completeness: Can the system establish that all relevant actions were captured?
     *
     * State Evaluation Rules:
     * 1. BLOCKED: Positive cryptographic integrity failure (CORRUPTED) detected in either required store.
     * 2. UNVERIFIED: Required integrity evidence is missing, unreadable, or incomplete.
     * 3. NOT ESTABLISHED: Cryptographic integrity is verified, but authoritative live runtime health attestation
     *    is not established. (READY is strictly prevented in the absence of verified attestation infrastructure).
     *
     * Returns: { state: string, reason: string, details: object }
     */
    deriveSystemState(data) {
      if (!data || typeof data !== 'object') {
        return {
          state: 'UNVERIFIED',
          reason: 'Overview telemetry payload unavailable or malformed',
          details: { auditStatus: 'UNAVAILABLE', provStatus: 'UNAVAILABLE' }
        };
      }

      const sf = data.status_flags || {};
      const ai = data.audit_integrity || {};
      const pi = data.provenance_integrity || {};
      const liveHealth = data.live_runtime_health;

      const auditStatus = (ai.status || 'UNAVAILABLE').toUpperCase();
      const provStatus = (pi.status || 'UNAVAILABLE').toUpperCase();

      // Strict boolean validation: string "false", numbers, null, etc. must NOT be interpreted as available
      const auditAvail = this.normalizeBooleanFlag(sf.audit_data_available);
      const provAvail = this.normalizeBooleanFlag(sf.provenance_data_available);

      // Dimension A: Positive Cryptographic Integrity Failure -> BLOCKED
      if (auditStatus === 'CORRUPTED' || provStatus === 'CORRUPTED') {
        const corruptedSources = [];
        if (auditStatus === 'CORRUPTED') corruptedSources.push('Audit Trail');
        if (provStatus === 'CORRUPTED') corruptedSources.push('Provenance Store');
        return {
          state: 'BLOCKED',
          reason: `Cryptographic integrity failure positively detected in ${corruptedSources.join(' and ')}`,
          details: { auditStatus, provStatus }
        };
      }

      // Check integrity availability & verification status
      const unverifiedSources = [];
      if (!auditAvail || auditStatus === 'UNAVAILABLE') {
        unverifiedSources.push('Audit Trail unavailable');
      } else if (auditStatus === 'UNVERIFIED') {
        unverifiedSources.push('Audit Trail unverified');
      } else if (auditStatus !== 'VERIFIED') {
        unverifiedSources.push(`Audit Trail status ${auditStatus}`);
      }

      if (!provAvail || provStatus === 'UNAVAILABLE') {
        unverifiedSources.push('Provenance Store unavailable');
      } else if (provStatus === 'UNVERIFIED') {
        unverifiedSources.push('Provenance Store unverified');
      } else if (provStatus !== 'VERIFIED') {
        unverifiedSources.push(`Provenance Store status ${provStatus}`);
      }

      if (unverifiedSources.length > 0) {
        return {
          state: 'UNVERIFIED',
          reason: `Required integrity evidence incomplete: ${unverifiedSources.join('; ')}`,
          details: { auditStatus, provStatus, unverifiedSources }
        };
      }

      // Dimension C: Current Operational Health Evaluation
      // Both integrity sources are VERIFIED.
      // Strict Trust Boundary:
      // The current backend adapter does not provide an authenticated live-health attestation infrastructure.
      // A caller-controlled source string, unverified timestamp, or unsigned/mock object is NOT proof
      // of supervisory authority and cannot establish READY.
      // In the absence of an authenticated live-health attestation authority, reject the signal and retain NOT ESTABLISHED.
      let liveHealthDetail = 'NOT_CONFIGURED';
      if (liveHealth !== undefined && liveHealth !== null) {
        liveHealthDetail = 'UNAUTHENTICATED_SIGNAL_REJECTED';
      }

      return {
        state: 'NOT ESTABLISHED',
        reason: 'Cryptographic integrity verified, but authoritative live runtime operational health attestation is not established',
        details: { auditStatus, provStatus, liveHealth: liveHealthDetail }
      };
    },

    // Helper: Semantic Badge Creator
    getStateMetadata(stateName) {
      const states = {
        'READY': {
          label: 'READY',
          established: true,
          glyph: '✓',
          statusClass: 'status-badge-verified',
          establishmentClass: 'established-ready',
          badgeClass: 'badge-verified',
          meaning: 'Authoritative live runtime health evidence affirmative and attested; system ready for execution.'
        },
        'AUTHORIZED': {
          label: 'AUTHORIZED',
          established: true,
          glyph: '◈',
          statusClass: 'status-badge-authorized',
          establishmentClass: 'established-authorized',
          badgeClass: 'badge-authorized',
          meaning: 'Pre-execution task contract and capability tokens validated. Does not imply execution outcome or runtime READY.'
        },
        'BLOCKED': {
          label: 'BLOCKED',
          established: true,
          glyph: '⛔',
          statusClass: 'status-badge-failed',
          establishmentClass: 'established-blocked',
          badgeClass: 'badge-failed',
          meaning: 'Positively detected system-level blocking condition (e.g. cryptographic chain corruption, fence breach). Request-level policy denials do not establish system BLOCKED.'
        },
        'FAILED': {
          label: 'FAILED',
          established: true,
          glyph: '✗',
          statusClass: 'status-badge-failed',
          establishmentClass: 'established-failed',
          badgeClass: 'badge-failed',
          meaning: 'Execution failure or protected boundary violation recorded on a specific trajectory.'
        },
        'HALTED': {
          label: 'HALTED',
          established: true,
          glyph: '✋',
          statusClass: 'status-badge-halted',
          establishmentClass: 'established-halted',
          badgeClass: 'badge-halted',
          meaning: 'Containment guardrail or policy boundary halt triggered on a specific execution.'
        },
        'DEGRADED': {
          label: 'DEGRADED',
          established: true,
          glyph: '⚠️',
          statusClass: 'status-badge-partial',
          establishmentClass: 'established-degraded',
          badgeClass: 'badge-warning',
          meaning: 'Positively confirmed operational impairment or subsystem failure, not merely historical retrospective failures.'
        },
        'UNVERIFIED': {
          label: 'UNVERIFIED',
          established: false,
          glyph: '⊘',
          statusClass: 'status-badge-unknown',
          establishmentClass: 'not-established',
          badgeClass: 'badge-neutral',
          meaning: 'Required evidence is missing, unavailable, unreadable, or insufficient to evaluate.'
        },
        'NOT ESTABLISHED': {
          label: 'NOT ESTABLISHED',
          established: false,
          glyph: '⊘',
          statusClass: 'status-badge-unknown',
          establishmentClass: 'not-established',
          badgeClass: 'badge-neutral',
          meaning: 'Required operational condition has not been affirmatively established by trusted live attestation.'
        }
      };

      const s = String(stateName || '').trim().toUpperCase();
      if (states[s]) {
        return states[s];
      }
      return {
        label: s || 'UNKNOWN',
        established: false,
        glyph: '?',
        statusClass: 'status-badge-unknown',
        establishmentClass: 'not-established',
        badgeClass: 'badge-neutral',
        meaning: 'Unrecognized system state.'
      };
    },

    createStatusBadge(statusText) {
      const span = document.createElement('span');
      const st = (statusText || 'UNKNOWN').toUpperCase();

      if (st === 'AVAILABLE') {
        span.className = 'status-badge status-badge-available';
        span.textContent = '● AVAILABLE';
      } else if (st === 'VERIFIED') {
        span.className = 'status-badge status-badge-verified';
        span.textContent = '✓ VERIFIED';
      } else if (st === 'READY') {
        span.className = 'status-badge status-badge-verified';
        span.textContent = '● READY';
      } else if (st === 'AUTHORIZED') {
        span.className = 'status-badge status-badge-verified';
        span.textContent = '✓ AUTHORIZED';
      } else if (st === 'RECORDED') {
        span.className = 'status-badge status-badge-not-established';
        span.textContent = '• RECORDED';
      } else if (st === 'FAILED' || st === 'FAIL') {
        span.className = 'status-badge status-badge-failed';
        span.textContent = '✗ FAILED';
      } else if (st === 'BLOCKED') {
        span.className = 'status-badge status-badge-failed';
        span.textContent = '⛔ BLOCKED';
      } else if (st === 'HALTED') {
        span.className = 'status-badge status-badge-halted';
        span.textContent = '🛑 HALTED';
      } else if (st === 'DEGRADED') {
        span.className = 'status-badge status-badge-halted';
        span.textContent = '⚠ DEGRADED';
      } else if (st === 'PENDING') {
        span.className = 'status-badge status-badge-pending';
        span.textContent = '⏳ PENDING';
      } else if (st === 'UNAVAILABLE') {
        span.className = 'status-badge status-badge-unavailable';
        span.textContent = '⊘ UNAVAILABLE';
      } else if (st === 'EMPTY') {
        span.className = 'status-badge status-badge-partial';
        span.textContent = '░ EMPTY';
      } else if (st === 'MALFORMED') {
        span.className = 'status-badge status-badge-unreadable';
        span.textContent = '⊘ MALFORMED';
      } else if (st === 'PARTIAL') {
        span.className = 'status-badge status-badge-partial';
        span.textContent = '⚠ PARTIAL';
      } else if (st === 'UNREADABLE') {
        span.className = 'status-badge status-badge-unreadable';
        span.textContent = '⊘ UNREADABLE';
      } else if (st === 'UNVERIFIED') {
        span.className = 'status-badge status-badge-unknown';
        span.textContent = '? UNVERIFIED';
      } else if (st === 'NOT ESTABLISHED') {
        span.className = 'status-badge status-badge-not-established';
        span.textContent = '░ NOT ESTABLISHED';
      } else {
        span.className = 'status-badge status-badge-unknown';
        span.textContent = `? ${st}`;
      }
      return span;
    },

    // -------------------------------------------------------------------------
    // View 1: Overview
    // -------------------------------------------------------------------------
    async loadOverview() {
      const btnRefresh = document.getElementById('btn-refresh-overview');
      const refreshIcon = btnRefresh ? btnRefresh.querySelector('.refresh-icon') : null;

      if (btnRefresh) {
        btnRefresh.disabled = true;
        btnRefresh.setAttribute('aria-busy', 'true');
        btnRefresh.setAttribute('title', 'Refreshing overview metrics...');
        this.announce('Refreshing overview metrics...');
      }
      if (refreshIcon) {
        refreshIcon.classList.add('spin');
      }

      try {
        const [overviewRes, tracesRes] = await Promise.all([
          fetch('/api/overview'),
          fetch('/api/traces').catch(() => null)
        ]);

        if (!overviewRes.ok) throw new Error(`HTTP error ${overviewRes.status}`);
        const data = await overviewRes.json();
        this.state.overviewData = data;

        if (tracesRes && tracesRes.ok) {
          this.state.tracesData = await tracesRes.json();
        }

        this.renderOverview();
      } catch (err) {
        console.error('Failed to load overview:', err);
        this.renderOverviewError(err.message);
      } finally {
        if (btnRefresh) {
          btnRefresh.disabled = false;
          btnRefresh.removeAttribute('aria-busy');
          btnRefresh.setAttribute('title', 'Refresh overview metrics');
        }
        if (refreshIcon) {
          refreshIcon.classList.remove('spin');
        }
      }
    },

    renderOverview() {
      const data = this.state.overviewData;
      if (!data) return;

      const updatedEl = document.getElementById('overview-last-updated');
      if (updatedEl) {
        const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        updatedEl.textContent = `Updated at ${timeStr}`;
      }

      const m = data.metrics || {};
      const sf = data.status_flags || {};
      const ai = data.audit_integrity || {};
      const pi = data.provenance_integrity || {};

      this.setText('metric-total-executions', (m.total_executions !== null && m.total_executions !== undefined) ? m.total_executions : 'UNAVAILABLE');
      this.setText('metric-denials', (m.authorization_denials !== null && m.authorization_denials !== undefined) ? m.authorization_denials : 'UNAVAILABLE');
      this.setText('metric-halts', (m.halts !== null && m.halts !== undefined) ? m.halts : 'UNAVAILABLE');
      this.setText('metric-failures', (m.execution_failures !== null && m.execution_failures !== undefined) ? m.execution_failures : 'UNAVAILABLE');
      this.setText('metric-parse-errors', (m.parse_error_count !== null && m.parse_error_count !== undefined) ? m.parse_error_count : 'UNAVAILABLE');

      // Calculate Normalized Cumulative Exceptions with completeness verification
      const exceptionResult = this.calculateCumulativeExceptions(m);
      const incidentEl = document.getElementById('overview-incident-count');
      if (incidentEl) {
        incidentEl.title = exceptionResult.reason;
        if (exceptionResult.status === 'MALFORMED') {
          incidentEl.textContent = 'MALFORMED';
          incidentEl.className = 'ops-indicator-val font-mono text-danger';
        } else if (exceptionResult.status === 'UNAVAILABLE') {
          incidentEl.textContent = 'UNAVAILABLE';
          incidentEl.className = 'ops-indicator-val font-mono text-dim';
        } else if (exceptionResult.status === 'PARTIAL') {
          incidentEl.textContent = 'PARTIAL';
          incidentEl.className = 'ops-indicator-val font-mono text-warning';
        } else {
          // COMPLETE
          incidentEl.textContent = String(exceptionResult.total);
          incidentEl.className = exceptionResult.total > 0 ? 'ops-indicator-val font-mono text-warning' : 'ops-indicator-val font-mono text-success';
        }
      }

      // Determine Operational System State using pure derivation function
      const stateResult = this.deriveSystemState(data);
      const sysStateEl = document.getElementById('overview-system-state');
      if (sysStateEl) {
        const badge = this.createStatusBadge(stateResult.state);
        badge.title = stateResult.reason;
        sysStateEl.replaceWith(badge);
        badge.id = 'overview-system-state';
      }

      // Update State-First Primary State Card
      const primaryStateCard = document.getElementById('overview-primary-state-card');
      const primaryStateText = document.getElementById('overview-system-state-text');
      const primaryEstablishment = document.getElementById('overview-state-establishment');
      const primaryRationale = document.getElementById('overview-state-rationale');
      const metaCumulativeExceptions = document.getElementById('overview-cumulative-exceptions-count');
      const metaEvidenceAnchor = document.getElementById('overview-evidence-anchor');

      const meta = this.getStateMetadata(stateResult.state);

      if (metaEvidenceAnchor) {
        if (ai.status === 'CORRUPTED' || pi.status === 'CORRUPTED') {
          metaEvidenceAnchor.textContent = 'INTEGRITY FAILED';
        } else if (ai.status === 'VERIFIED' && pi.status === 'VERIFIED') {
          metaEvidenceAnchor.textContent = 'LOCAL SHA-256 HASH-CHAIN (VERIFIED)';
        } else if (ai.status === 'UNAVAILABLE' && pi.status === 'UNAVAILABLE') {
          metaEvidenceAnchor.textContent = 'UNAVAILABLE';
        } else {
          metaEvidenceAnchor.textContent = 'LOCAL SHA-256 HASH-CHAIN';
        }
      }

      if (primaryStateCard) {
        primaryStateCard.setAttribute('data-state', stateResult.state);
      }
      if (primaryStateText) {
        primaryStateText.textContent = `${meta.glyph} ${meta.label}`;
      }
      if (primaryEstablishment) {
        primaryEstablishment.className = `ops-establishment-badge ${meta.establishmentClass}`;
        primaryEstablishment.textContent = meta.established ? 'ESTABLISHED' : 'NOT ESTABLISHED';
      }
      if (primaryRationale) {
        primaryRationale.textContent = stateResult.reason;
      }
      if (metaCumulativeExceptions) {
        const excCountText = exceptionResult.status === 'COMPLETE' ? String(exceptionResult.total) : exceptionResult.status;
        metaCumulativeExceptions.textContent = excCountText;
      }

      // Update Dimension 1: Cryptographic Integrity
      const dimIntegrityBadge = document.getElementById('dim-integrity-badge');
      const dimIntegrityContent = document.getElementById('dim-integrity-content');
      if (dimIntegrityBadge && dimIntegrityContent) {
        const auditStatus = (ai.status || 'UNAVAILABLE').toUpperCase();
        const provStatus = (pi.status || 'UNAVAILABLE').toUpperCase();
        if (auditStatus === 'CORRUPTED' || provStatus === 'CORRUPTED' || auditStatus === 'CORRUPT' || provStatus === 'CORRUPT') {
          dimIntegrityBadge.className = 'ops-dimension-badge badge-failed';
          dimIntegrityBadge.textContent = '⛔ BLOCKED';
          dimIntegrityContent.textContent = 'Hash chain corruption detected in local append log. Tamper-evident continuity broken.';
        } else if (auditStatus === 'VERIFIED' && provStatus === 'VERIFIED') {
          dimIntegrityBadge.className = 'ops-dimension-badge badge-verified';
          dimIntegrityBadge.textContent = '✓ VERIFIED';
          dimIntegrityContent.textContent = `All entries verified. Audit: ${ai.records_verified ?? 0} entries, Provenance: ${pi.records_verified ?? 0} records.`;
        } else if (auditStatus === 'VERIFIED' || provStatus === 'VERIFIED') {
          dimIntegrityBadge.className = 'ops-dimension-badge badge-warning';
          dimIntegrityBadge.textContent = '⚠️ PARTIAL';
          dimIntegrityContent.textContent = `Partial verification: Audit is ${auditStatus}, Provenance is ${provStatus}.`;
        } else {
          dimIntegrityBadge.className = 'ops-dimension-badge badge-neutral';
          dimIntegrityBadge.textContent = '⊘ UNVERIFIED';
          dimIntegrityContent.textContent = `Audit Trail: ${auditStatus} (${ai.records_verified ?? 0} entries) • Provenance: ${provStatus} (${pi.records_verified ?? 0} records). Scope: SHA-256 sequence hash-chain continuity. Positive corruption halts to BLOCKED.`;
        }
      }

      // Update Dimension 2: Historical Activity
      const dimActivityBadge = document.getElementById('dim-activity-badge');
      const dimActivityContent = document.getElementById('dim-activity-content');
      if (dimActivityBadge && dimActivityContent) {
        dimActivityBadge.className = 'ops-dimension-badge badge-neutral';
        dimActivityBadge.textContent = '• RECORDED';
        const execs = m.total_executions ?? 0;
        const denials = m.authorization_denials ?? 0;
        const halts = m.halts ?? 0;
        const fails = m.execution_failures ?? 0;
        const excSummary = exceptionResult.status === 'COMPLETE' ?
          `Cumulative exceptions: ${exceptionResult.total}.` :
          `Partial exception telemetry: missing values detected.`;
        dimActivityContent.textContent = `Cumulative: ${execs} executions, ${denials} denials, ${halts} halts, ${fails} fails (${excSummary})`;
      }

      // Update Dimension 3: Operational Health
      const dimHealthBadge = document.getElementById('dim-health-badge');
      const dimHealthContent = document.getElementById('dim-health-content');
      if (dimHealthBadge && dimHealthContent) {
        if (stateResult.state === 'READY') {
          dimHealthBadge.className = 'ops-dimension-badge badge-verified';
          dimHealthBadge.textContent = '✓ ATTESTED';
          dimHealthContent.textContent = 'Authoritative supervisory live-health attestation established and valid.';
        } else {
          dimHealthBadge.className = 'ops-dimension-badge badge-neutral';
          dimHealthBadge.textContent = '⊘ NOT ESTABLISHED';
          dimHealthContent.textContent = 'No authoritative supervisory live runtime attestation authority configured. Operational health readiness remains NOT ESTABLISHED.';
        }
      }

      // Update Dimension 4: Evidence Availability
      const dimCompBadge = document.getElementById('dim-completeness-badge');
      const dimCompContent = document.getElementById('dim-completeness-content');
      if (dimCompBadge && dimCompContent) {
        const auditAvail = this.normalizeBooleanFlag(sf.audit_data_available);
        const provAvail = this.normalizeBooleanFlag(sf.provenance_data_available);
        if (auditAvail && provAvail) {
          dimCompBadge.className = 'ops-dimension-badge badge-available';
          dimCompBadge.textContent = '✓ AVAILABLE';
          dimCompContent.textContent = 'Physical local log files present and accessible for both Audit Trail and Provenance Store. (Note: presence does not prove source completeness or authenticity).';
        } else if (auditAvail || provAvail) {
          dimCompBadge.className = 'ops-dimension-badge badge-warning';
          dimCompBadge.textContent = '⚠️ PARTIAL';
          dimCompContent.textContent = `Partial physical log availability: Audit is ${auditAvail ? 'AVAILABLE' : 'UNAVAILABLE'}, Provenance is ${provAvail ? 'AVAILABLE' : 'UNAVAILABLE'}.`;
        } else {
          dimCompBadge.className = 'ops-dimension-badge badge-neutral';
          dimCompBadge.textContent = '⊘ UNAVAILABLE';
          dimCompContent.textContent = 'Physical logs unavailable: Audit is UNAVAILABLE, Provenance is UNAVAILABLE. Local files missing or unreadable.';
        }
      }

      // Audit Data Availability Badge
      const auditAvailEl = document.getElementById('audit-data-availability');
      if (auditAvailEl) {
        const isAvail = this.normalizeBooleanFlag(sf.audit_data_available);
        auditAvailEl.className = isAvail ? 'status-badge status-badge-verified' : 'status-badge status-badge-unavailable';
        auditAvailEl.textContent = isAvail ? '✓ DATA AVAILABLE' : '⊘ DATA UNAVAILABLE';
      }

      // Audit Integrity Block
      const auditContainer = document.getElementById('audit-integrity-status');
      if (auditContainer) {
        auditContainer.innerHTML = '';

        const headerDiv = document.createElement('div');
        headerDiv.className = 'ops-status-row';

        const labelSpan = document.createElement('span');
        labelSpan.className = 'ops-status-subheading';
        labelSpan.textContent = 'Integrity Verification';

        const badge = this.createStatusBadge(ai.status || 'UNAVAILABLE');
        headerDiv.appendChild(labelSpan);
        headerDiv.appendChild(badge);

        const msgDiv = document.createElement('div');
        msgDiv.className = 'text-muted ops-status-msg';
        msgDiv.textContent = ai.message || 'No audit records verified.';

        const countDiv = document.createElement('div');
        countDiv.className = 'text-muted font-mono ops-status-meta';
        countDiv.textContent = `Verified Entries: ${ai.records_verified ?? 0}`;

        auditContainer.appendChild(headerDiv);
        auditContainer.appendChild(msgDiv);
        auditContainer.appendChild(countDiv);
      }

      // Provenance Data Availability Badge
      const provAvailEl = document.getElementById('provenance-data-availability');
      if (provAvailEl) {
        const isAvail = this.normalizeBooleanFlag(sf.provenance_data_available);
        provAvailEl.className = isAvail ? 'status-badge status-badge-verified' : 'status-badge status-badge-unavailable';
        provAvailEl.textContent = isAvail ? '✓ DATA AVAILABLE' : '⊘ DATA UNAVAILABLE';
      }

      // Provenance Integrity Block
      const provContainer = document.getElementById('provenance-integrity-status');
      if (provContainer) {
        provContainer.innerHTML = '';

        const headerDiv = document.createElement('div');
        headerDiv.className = 'ops-status-row';

        const labelSpan = document.createElement('span');
        labelSpan.className = 'ops-status-subheading';
        labelSpan.textContent = 'Integrity Verification';

        const badge = this.createStatusBadge(pi.status || 'UNAVAILABLE');
        headerDiv.appendChild(labelSpan);
        headerDiv.appendChild(badge);

        const msgDiv = document.createElement('div');
        msgDiv.className = 'text-muted ops-status-msg';
        msgDiv.textContent = pi.message || 'No provenance events found.';

        const countDiv = document.createElement('div');
        countDiv.className = 'text-muted font-mono ops-status-meta';
        countDiv.textContent = `Verified Records: ${pi.records_verified ?? 0}`;

        provContainer.appendChild(headerDiv);
        provContainer.appendChild(msgDiv);
        provContainer.appendChild(countDiv);

        if (pi.last_hash) {
          const hashDiv = document.createElement('div');
          hashDiv.className = 'font-mono text-dim ops-tail-hash';
          const shortTail = pi.last_hash.length > 24 ? pi.last_hash.substring(0, 22) + '…' : pi.last_hash;
          hashDiv.textContent = `Tail: ${shortTail}`;
          hashDiv.title = pi.last_hash;
          provContainer.appendChild(hashDiv);
        }
      }

      // Render Overview Recent Traces
      this.renderOverviewRecentTraces();

      this.announce('Overview metrics updated.');
    },

    renderOverviewRecentTraces() {
      const tbody = document.getElementById('overview-recent-traces');
      if (!tbody) return;

      tbody.innerHTML = '';
      const traces = this.state.tracesData || [];

      if (traces.length === 0) {
        const tr = document.createElement('tr');
        const td = document.createElement('td');
        td.colSpan = 5;
        td.className = 'text-center text-muted';
        td.textContent = 'No recent execution traces recorded.';
        tr.appendChild(td);
        tbody.appendChild(tr);
        return;
      }

      // Show top 5 recent execution traces
      const recent = traces.slice(0, 5);

      recent.forEach(trace => {
        const tr = document.createElement('tr');
        tr.className = 'clickable';
        tr.setAttribute('tabindex', '0');
        tr.setAttribute('role', 'button');
        tr.setAttribute('aria-label', `Inspect execution trace ${trace.correlation_id || 'UNKNOWN'}`);

        const handleActivate = async () => {
          this.state.selectedTraceId = trace.correlation_id;
          this.switchTab('traces');
          await this.selectTrace(trace.correlation_id);
          const activeItem = document.querySelector('#trace-list .trace-item.active');
          if (activeItem) {
            activeItem.focus();
          }
        };

        tr.addEventListener('click', handleActivate);
        tr.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleActivate();
          }
        });

        const tdCorr = document.createElement('td');
        tdCorr.className = 'font-mono ops-cell-corr';
        tdCorr.textContent = (trace.correlation_id || '').length > 20 ? (trace.correlation_id || '').substring(0, 18) + '…' : (trace.correlation_id || 'UNKNOWN');
        tdCorr.title = trace.correlation_id;

        const tdAction = document.createElement('td');
        tdAction.className = 'ops-cell-action';
        tdAction.textContent = trace.action_name || 'N/A';

        const tdTarget = document.createElement('td');
        tdTarget.className = 'font-mono ops-cell-target';
        tdTarget.textContent = trace.target || 'N/A';
        tdTarget.title = trace.target;

        const tdStatus = document.createElement('td');
        tdStatus.className = 'ops-cell-status';
        const badge = document.createElement('span');
        badge.className = `badge badge-${trace.status || 'OUTCOME_UNKNOWN'}`;
        badge.textContent = trace.status || 'UNKNOWN';
        tdStatus.appendChild(badge);

        const tdTime = document.createElement('td');
        tdTime.className = 'font-mono ops-cell-time';
        tdTime.textContent = trace.start_time || trace.timestamp || 'N/A';

        tr.appendChild(tdCorr);
        tr.appendChild(tdAction);
        tr.appendChild(tdTarget);
        tr.appendChild(tdStatus);
        tr.appendChild(tdTime);

        tbody.appendChild(tr);
      });
    },

    renderOverviewError(msg) {
      this.setText('metric-total-executions', 'ERROR');
      this.setText('metric-denials', 'ERROR');
      this.setText('metric-halts', 'ERROR');
      this.setText('metric-failures', 'ERROR');

      const updatedEl = document.getElementById('overview-last-updated');
      if (updatedEl) {
        updatedEl.textContent = 'Update failed';
      }

      this.announce('Failed to update overview metrics.');
    },

    // -------------------------------------------------------------------------
    // View 2: Execution Trace Explorer
    // -------------------------------------------------------------------------
    async loadTraces() {
      const traceListUl = document.getElementById('trace-list');
      if (traceListUl && this.state.tracesData.length === 0) {
        traceListUl.innerHTML = '<li class="text-muted text-center" style="padding: 1.5rem;">Loading execution traces...</li>';
      }

      try {
        const res = await fetch('/api/traces');
        if (!res.ok) throw new Error(`HTTP error ${res.status}`);
        const data = await res.json();
        this.state.tracesData = Array.isArray(data) ? data : [];
        this.renderTracesList();
      } catch (err) {
        console.error('Failed to load traces:', err);
        this.renderTracesLoadError(err.message);
      }
    },

    renderTracesLoadError(errorMsg) {
      const traceListUl = document.getElementById('trace-list');
      if (!traceListUl) return;
      traceListUl.innerHTML = '';

      const errLi = document.createElement('li');
      errLi.className = 'text-danger text-center';
      errLi.setAttribute('role', 'option');
      errLi.setAttribute('aria-selected', 'false');
      errLi.style.padding = '1.5rem 1rem';

      const msgSpan = document.createElement('span');
      msgSpan.style.display = 'block';
      msgSpan.style.marginBottom = '0.5rem';
      msgSpan.style.fontWeight = '600';
      msgSpan.textContent = 'Failed to load execution traces.';

      const detailSpan = document.createElement('span');
      detailSpan.className = 'text-muted font-mono';
      detailSpan.style.fontSize = '0.75rem';
      detailSpan.style.display = 'block';
      detailSpan.style.marginBottom = '0.75rem';
      detailSpan.textContent = `Server API Error: ${errorMsg}`;

      const retryBtn = document.createElement('button');
      retryBtn.type = 'button';
      retryBtn.className = 'btn-refresh';
      retryBtn.textContent = 'Retry Loading Traces';
      retryBtn.setAttribute('aria-label', 'Retry loading execution traces');
      retryBtn.setAttribute('title', 'Retry loading execution traces');
      retryBtn.addEventListener('click', () => this.executeWithRetryFeedback(retryBtn, 'Retrying Traces...', () => this.loadTraces()));

      errLi.appendChild(msgSpan);
      errLi.appendChild(detailSpan);
      errLi.appendChild(retryBtn);
      traceListUl.appendChild(errLi);

      const countBadge = document.getElementById('trace-count');
      if (countBadge) {
        countBadge.textContent = 'ERROR';
      }
    },

    renderTracesList() {
      const traceListUl = document.getElementById('trace-list');
      if (!traceListUl) return;
      const areaTraceList = document.getElementById('area-trace-list');
      traceListUl.innerHTML = '';

      let filtered = this.state.tracesData.filter(t => {
        if (this.state.traceFilterStatus !== 'ALL' && t.status !== this.state.traceFilterStatus) {
          return false;
        }
        if (this.state.traceSearchQuery) {
          const q = this.state.traceSearchQuery;
          const corr = (t.correlation_id || '').toLowerCase();
          const req = (t.request_id || '').toLowerCase();
          const act = (t.action_name || '').toLowerCase();
          const tgt = (t.target || '').toLowerCase();
          return corr.includes(q) || req.includes(q) || act.includes(q) || tgt.includes(q);
        }
        return true;
      });

      const countBadge = document.getElementById('trace-count');
      if (countBadge) {
        const total = this.state.tracesData.length;
        const visible = filtered.length;
        countBadge.textContent = total === visible ? `${total}` : `${visible} of ${total}`;
        countBadge.setAttribute('aria-label', total === visible ? `${total} traces` : `${visible} of ${total} traces shown`);
      }

      // Clean up any previously attached clear-action bar
      const existingTraceClear = areaTraceList?.querySelector('.stream-clear-action-bar');
      if (existingTraceClear) existingTraceClear.remove();

      if (filtered.length === 0) {
        const emptyLi = document.createElement('li');
        emptyLi.className = 'text-muted text-center';
        emptyLi.setAttribute('role', 'option');
        emptyLi.setAttribute('aria-selected', 'false');
        emptyLi.style.padding = '1.5rem 1rem';

        const hasFilters = this.state.traceSearchQuery || this.state.traceFilterStatus !== 'ALL';
        if (hasFilters) {
          emptyLi.textContent = 'No execution traces match active filter query.';

          const clearBar = document.createElement('div');
          clearBar.className = 'stream-clear-action-bar text-center';
          clearBar.style.padding = '0.5rem 1rem 1rem';

          const clearBtn = document.createElement('button');
          clearBtn.type = 'button';
          clearBtn.className = 'btn-refresh';
          clearBtn.textContent = 'Clear Filters';
          clearBtn.setAttribute('aria-label', 'Clear search query and status filter');
          clearBtn.setAttribute('title', 'Clear active search query and status filter');
          clearBtn.addEventListener('click', () => {
            this.state.traceSearchQuery = '';
            this.state.traceFilterStatus = 'ALL';
            const searchInput = document.getElementById('trace-search');
            if (searchInput) {
              searchInput.value = '';
              searchInput.focus();
            }
            const statusFilter = document.getElementById('trace-status-filter');
            if (statusFilter) statusFilter.value = 'ALL';
            this.announce('Trace filters cleared. Showing all traces.');
            this.renderTracesList();
          });

          clearBar.appendChild(clearBtn);
          areaTraceList?.appendChild(clearBar);
        } else {
          emptyLi.textContent = 'No execution traces recorded in local provenance or audit log.';
        }

        traceListUl.appendChild(emptyLi);
        return;
      }

      filtered.forEach((trace, index) => {
        const isSelected = this.state.selectedTraceId === trace.correlation_id;
        const li = document.createElement('li');
        li.className = `trace-item ${isSelected ? 'active' : ''}`;
        li.setAttribute('role', 'option');
        li.setAttribute('tabindex', '0');
        li.setAttribute('aria-selected', isSelected ? 'true' : 'false');
        li.setAttribute('aria-label', `Execution trace ${trace.correlation_id}, status ${trace.status}`);

        li.addEventListener('click', () => this.selectTrace(trace.correlation_id));
        li.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.selectTrace(trace.correlation_id);
          } else if (e.key === 'ArrowDown') {
            e.preventDefault();
            const items = traceListUl.querySelectorAll('.trace-item');
            if (index + 1 < items.length) {
              items[index + 1].focus();
            }
          } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            const items = traceListUl.querySelectorAll('.trace-item');
            if (index - 1 >= 0) {
              items[index - 1].focus();
            }
          } else if (e.key === 'Home') {
            e.preventDefault();
            const items = traceListUl.querySelectorAll('.trace-item');
            if (items.length > 0) items[0].focus();
          } else if (e.key === 'End') {
            e.preventDefault();
            const items = traceListUl.querySelectorAll('.trace-item');
            if (items.length > 0) items[items.length - 1].focus();
          }
        });

        const headerDiv = document.createElement('div');
        headerDiv.className = 'trace-item-header';

        const idSpan = document.createElement('span');
        idSpan.className = 'trace-id';
        const displayCorr = trace.correlation_id ? (trace.correlation_id.length > 20 ? trace.correlation_id.substring(0, 18) + '...' : trace.correlation_id) : 'UNKNOWN';
        idSpan.textContent = displayCorr;
        idSpan.title = trace.correlation_id;

        const badgeSpan = document.createElement('span');
        badgeSpan.className = `badge badge-${trace.status || 'OUTCOME_UNKNOWN'}`;
        badgeSpan.textContent = trace.status || 'UNKNOWN';

        headerDiv.appendChild(idSpan);
        headerDiv.appendChild(badgeSpan);

        const subDiv = document.createElement('div');
        subDiv.className = 'text-muted';
        subDiv.style.fontSize = '0.75rem';
        subDiv.style.marginTop = '0.2rem';
        subDiv.textContent = `${trace.action_name || 'N/A'} ➔ ${trace.target || 'N/A'}`;

        const timeDiv = document.createElement('div');
        timeDiv.className = 'font-mono text-dim';
        timeDiv.style.fontSize = '0.7rem';
        timeDiv.style.marginTop = '0.15rem';
        timeDiv.textContent = trace.start_time || trace.timestamp || 'Timestamp unavailable';

        li.appendChild(headerDiv);
        li.appendChild(subDiv);
        li.appendChild(timeDiv);
        traceListUl.appendChild(li);
      });
    },

    async selectTrace(correlationId) {
      this.state.selectedTraceId = correlationId;
      this.state.selectedEventSeq = null;
      this.announce(`Selected execution trace ${correlationId}`);
      this.renderTracesList();

      const emptyDiv = document.getElementById('trace-detail-empty');
      const contentDiv = document.getElementById('trace-detail-content');

      if (!correlationId) {
        if (emptyDiv) emptyDiv.classList.remove('hidden');
        if (contentDiv) contentDiv.classList.add('hidden');
        this.updateMobileTraceView('list');
        return;
      }

      this.updateMobileTraceView('detail');

      // Fetch trace detail
      try {
        const res = await fetch(`/api/trace/${encodeURIComponent(correlationId)}`);
        if (!res.ok) throw new Error(`HTTP error ${res.status}`);
        const trace = await res.json();

        if (emptyDiv) emptyDiv.classList.add('hidden');
        if (contentDiv) {
          contentDiv.classList.remove('hidden');
          this.renderTraceDetail(trace, contentDiv);
        }
      } catch (err) {
        console.error('Failed to load trace detail:', err);
        if (contentDiv) {
          contentDiv.classList.remove('hidden');
          this.renderTraceErrorDetail(correlationId, err.message, contentDiv);
        }
      }
    },

    renderTraceErrorDetail(correlationId, errorMsg, container) {
      container.innerHTML = '';

      const errCard = document.createElement('div');
      errCard.className = 'card';

      const errHeader = document.createElement('div');
      errHeader.className = 'card-header text-danger';
      errHeader.textContent = 'Execution Trace Fetch Failure';

      const h3 = document.createElement('h3');
      h3.textContent = `Unable to retrieve records for trace: ${correlationId}`;

      const p = document.createElement('p');
      p.className = 'text-muted font-mono';
      p.style.fontSize = '0.825rem';
      p.textContent = `Server response: ${errorMsg}`;

      const retryBtn = document.createElement('button');
      retryBtn.type = 'button';
      retryBtn.className = 'btn-refresh';
      retryBtn.style.marginTop = '1rem';
      retryBtn.textContent = 'Retry Selection';
      retryBtn.setAttribute('aria-label', `Retry selection for trace ${correlationId}`);
      retryBtn.setAttribute('title', `Retry selection for trace ${correlationId}`);
      retryBtn.addEventListener('click', () => this.executeWithRetryFeedback(retryBtn, 'Retrying Selection...', () => this.selectTrace(correlationId)));

      errCard.appendChild(errHeader);
      errCard.appendChild(h3);
      errCard.appendChild(p);
      errCard.appendChild(retryBtn);
      container.appendChild(errCard);
    },

    renderTraceDetail(trace, container) {
      container.innerHTML = '';

      // Trace Detail Top Header
      const headerBar = document.createElement('div');
      headerBar.style.display = 'flex';
      headerBar.style.justifyContent = 'space-between';
      headerBar.style.alignItems = 'center';
      headerBar.style.marginBottom = '1rem';
      headerBar.style.flexWrap = 'wrap';
      headerBar.style.gap = '0.5rem';

      const titleGroup = document.createElement('div');
      const title = document.createElement('h3');
      title.style.fontSize = '1.05rem';
      title.style.fontWeight = '700';
      title.style.margin = '0';
      title.className = 'font-mono';
      title.textContent = `Trace Correlation: ${trace.correlation_id}`;

      titleGroup.appendChild(title);

      const actionBtnGroup = document.createElement('div');
      actionBtnGroup.style.display = 'flex';
      actionBtnGroup.style.gap = '0.5rem';

      if (trace.correlation_id) {
        const provBtn = document.createElement('button');
        provBtn.type = 'button';
        provBtn.className = 'quick-entry-btn';
        provBtn.style.padding = '0.25rem 0.6rem';
        provBtn.style.fontSize = '0.75rem';
        provBtn.setAttribute('aria-label', `View provenance records for correlation ${trace.correlation_id}`);
        provBtn.setAttribute('title', `View provenance records for correlation ${trace.correlation_id}`);
        provBtn.innerHTML = `<span>View in Provenance</span> <span class="arrow" aria-hidden="true">➔</span>`;
        provBtn.addEventListener('click', () => {
          this.state.provenanceSearchQuery = trace.correlation_id.toLowerCase().trim();
          const provSearchInput = document.getElementById('provenance-search');
          if (provSearchInput) {
            provSearchInput.value = trace.correlation_id;
          }
          this.switchTab('provenance');
          this.renderProvenanceRecordList();
          this.announce(`Navigated to Provenance Explorer (Filtered: ${trace.correlation_id})`);
          if (provSearchInput) {
            provSearchInput.focus();
            provSearchInput.select();
          }
        });
        actionBtnGroup.appendChild(provBtn);
      }

      const copyCorrBtn = document.createElement('button');
      copyCorrBtn.type = 'button';
      copyCorrBtn.className = 'copy-btn';
      copyCorrBtn.textContent = 'Copy Correlation ID';
      copyCorrBtn.setAttribute('aria-label', 'Copy Correlation ID');
      copyCorrBtn.setAttribute('title', 'Copy Correlation ID to clipboard');
      copyCorrBtn.addEventListener('click', () => this.copyToClipboard(trace.correlation_id, copyCorrBtn));
      actionBtnGroup.appendChild(copyCorrBtn);

      headerBar.appendChild(titleGroup);
      headerBar.appendChild(actionBtnGroup);
      container.appendChild(headerBar);

      // Section B1: Derived Interpretation Summary
      const derivedSummaryCard = document.createElement('div');
      derivedSummaryCard.className = 'derived-summary-card mb-1';

      const summaryHeader = document.createElement('div');
      summaryHeader.className = 'derived-summary-header';

      const summaryTitle = document.createElement('span');
      summaryTitle.textContent = 'Derived Summary • Inferred Status & Evidence Correlation';

      const summaryBadge = document.createElement('span');
      summaryBadge.className = 'status-badge status-badge-not-established';
      summaryBadge.textContent = 'DERIVED INTERPRETATION';

      summaryHeader.appendChild(summaryTitle);
      summaryHeader.appendChild(summaryBadge);

      const summaryText = document.createElement('p');
      summaryText.style.fontSize = '0.85rem';
      summaryText.style.color = 'var(--text-primary)';
      summaryText.style.marginBottom = '0.5rem';

      const events = Array.isArray(trace.provenance_events) ? trace.provenance_events : [];
      const eventTypes = new Set(events.map(e => e.event_type));

      if (eventTypes.size === 0) {
        summaryText.textContent = 'Event records unestablished: No provenance events returned for this trace.';
      } else {
        const claims = [];
        if (eventTypes.has('EXECUTION_SUCCEEDED')) {
          claims.push('observed EXECUTION_SUCCEEDED event');
        }
        if (eventTypes.has('AUTHORIZATION_DENIED')) {
          claims.push('observed AUTHORIZATION_DENIED event');
        }
        if (eventTypes.has('EGRESS_BLOCKED')) {
          claims.push('observed EGRESS_BLOCKED event');
        }
        if (eventTypes.has('EXECUTION_FAILED') || eventTypes.has('EXECUTION_INTERRUPTED')) {
          claims.push('observed EXECUTION_FAILED / EXECUTION_INTERRUPTED event');
        }

        if (claims.length > 0) {
          summaryText.textContent = `Event types present in returned trace records: ${claims.join('; ')}.`;
        } else {
          summaryText.textContent = `Terminal outcome unestablished: None of the available ${events.length} event records establish execution completion, rejection, or failure.`;
        }
      }

      const disclaimerBox = document.createElement('div');
      disclaimerBox.className = 'epistemic-disclaimer-box';
      disclaimerBox.textContent = 'EPISTEMIC NOTICE: Displaying available event records establishes recorded activity, but does NOT claim a complete execution history or prove external source non-repudiation.';

      derivedSummaryCard.appendChild(summaryHeader);
      derivedSummaryCard.appendChild(summaryText);
      derivedSummaryCard.appendChild(disclaimerBox);
      container.appendChild(derivedSummaryCard);

      // Section B2: Lifecycle Overview & Authorization Records
      const metaGrid = document.createElement('div');
      metaGrid.className = 'section-grid mb-1';

      // Lifecycle Card
      const metaCard = document.createElement('div');
      metaCard.className = 'card';

      const metaHeader = document.createElement('div');
      metaHeader.className = 'card-header';
      metaHeader.textContent = 'Observed Execution Overview';
      metaCard.appendChild(metaHeader);

      const pStatus = document.createElement('p');
      pStatus.style.marginBottom = '0.4rem';
      pStatus.innerHTML = `<strong>Observed Outcome:</strong> `;
      const statusBadge = document.createElement('span');
      statusBadge.className = `badge badge-${trace.status || 'OUTCOME_UNKNOWN'}`;
      statusBadge.textContent = trace.status || 'OUTCOME_UNKNOWN';
      pStatus.appendChild(statusBadge);

      const pAction = document.createElement('p');
      pAction.style.marginBottom = '0.3rem';
      pAction.style.fontSize = '0.85rem';
      pAction.textContent = `Action Name: ${trace.action_name || 'NOT RECORDED'}`;

      const pTarget = document.createElement('p');
      pTarget.style.marginBottom = '0.3rem';
      pTarget.style.fontSize = '0.85rem';
      pTarget.textContent = `Target Resource: ${trace.target || 'NOT RECORDED'}`;

      const pReq = document.createElement('p');
      pReq.className = 'font-mono';
      pReq.style.fontSize = '0.8rem';
      pReq.style.color = 'var(--text-secondary)';
      pReq.textContent = `Request ID: ${trace.request_id || 'NOT RECORDED'}`;

      const pTimeWindow = document.createElement('p');
      pTimeWindow.className = 'font-mono';
      pTimeWindow.style.fontSize = '0.75rem';
      pTimeWindow.style.color = 'var(--text-muted)';
      pTimeWindow.style.marginTop = '0.3rem';
      pTimeWindow.textContent = `Time Span: ${trace.start_time || 'N/A'} ➔ ${trace.end_time || 'N/A'}`;

      metaCard.appendChild(pStatus);
      metaCard.appendChild(pAction);
      metaCard.appendChild(pTarget);
      metaCard.appendChild(pReq);
      metaCard.appendChild(pTimeWindow);

      // Authorization Evidence Card
      const authCard = document.createElement('div');
      authCard.className = 'card';

      const authHeader = document.createElement('div');
      authHeader.className = 'card-header';
      authHeader.textContent = 'Authorization & Policy Record';
      authCard.appendChild(authHeader);

      const ae = trace.authorization_evidence || {};
      const hasAuthEvidence = ae.authorization_token_id || ae.canonical_request_digest || ae.policy_version;

      if (!hasAuthEvidence) {
        const noAuthP = document.createElement('p');
        noAuthP.className = 'text-muted';
        noAuthP.style.fontSize = '0.825rem';
        noAuthP.textContent = 'No explicit authorization grant or token record found in provenance events for this correlation ID.';
        authCard.appendChild(noAuthP);
      } else {
        const pAuthToken = document.createElement('p');
        pAuthToken.className = 'font-mono';
        pAuthToken.style.fontSize = '0.8rem';
        pAuthToken.style.marginBottom = '0.3rem';
        pAuthToken.textContent = `Capability Token ID: ${ae.authorization_token_id || 'UNISSUED'}`;

        const pDigest = document.createElement('p');
        pDigest.className = 'font-mono';
        pDigest.style.fontSize = '0.8rem';
        pDigest.style.marginBottom = '0.3rem';
        pDigest.style.wordBreak = 'break-all';
        pDigest.textContent = `Payload Digest: ${ae.canonical_request_digest || 'UNRECORDED'}`;

        const pPolicy = document.createElement('p');
        pPolicy.style.fontSize = '0.85rem';
        pPolicy.textContent = `Policy Version: ${ae.policy_version || 'NOT RECORDED'}`;

        authCard.appendChild(pAuthToken);
        authCard.appendChild(pDigest);
        authCard.appendChild(pPolicy);
      }

      metaGrid.appendChild(metaCard);
      metaGrid.appendChild(authCard);
      container.appendChild(metaGrid);

      // Reconciliation Status Card
      const recCard = document.createElement('div');
      recCard.className = 'card mb-1';

      const recHeader = document.createElement('div');
      recHeader.className = 'card-header';
      recHeader.textContent = 'Reconciliation Status Report';
      recCard.appendChild(recHeader);

      const rec = trace.reconciliation || {};
      const recRow = document.createElement('div');
      recRow.style.display = 'flex';
      recRow.style.alignItems = 'center';
      recRow.style.gap = '0.75rem';
      recRow.style.marginBottom = '0.5rem';

      const recLabel = document.createElement('span');
      recLabel.style.fontWeight = '600';
      recLabel.style.fontSize = '0.85rem';
      recLabel.textContent = 'Reconciliation Verification: ';

      const recStatusBadge = this.createStatusBadge(rec.valid ? 'VERIFIED' : (rec.status || 'FAILED'));
      recRow.appendChild(recLabel);
      recRow.appendChild(recStatusBadge);
      recCard.appendChild(recRow);

      if (rec.violations && rec.violations.length > 0) {
        const violTitle = document.createElement('div');
        violTitle.className = 'text-danger';
        violTitle.style.fontWeight = '600';
        violTitle.style.fontSize = '0.85rem';
        violTitle.style.marginTop = '0.5rem';
        violTitle.textContent = 'Reconciliation Violations Detected:';
        recCard.appendChild(violTitle);

        const ulViol = document.createElement('ul');
        ulViol.style.marginLeft = '1.25rem';
        ulViol.style.marginTop = '0.25rem';
        rec.violations.forEach(v => {
          const li = document.createElement('li');
          li.className = 'text-danger font-mono';
          li.style.fontSize = '0.8rem';
          li.textContent = v;
          ulViol.appendChild(li);
        });
        recCard.appendChild(ulViol);
      } else {
        const noViol = document.createElement('div');
        noViol.className = 'text-muted';
        noViol.style.fontSize = '0.8rem';
        noViol.textContent = 'Zero reconciliation violations detected across provenance chain.';
        recCard.appendChild(noViol);
      }
      container.appendChild(recCard);

      // Area C & B: Execution Lifecycle Sequence Visualization & Timeline
      const lifecycleCard = document.createElement('div');
      lifecycleCard.className = 'card';

      const lifecycleHeader = document.createElement('div');
      lifecycleHeader.className = 'card-header';

      const headerTitle = document.createElement('span');
      headerTitle.textContent = 'Recorded Execution Lifecycle Sequence';

      const countBadge = document.createElement('span');
      countBadge.className = 'status-badge status-badge-not-established';
      countBadge.textContent = `${events.length} RECORDED EVENT(S)`;

      lifecycleHeader.appendChild(headerTitle);
      lifecycleHeader.appendChild(countBadge);
      lifecycleCard.appendChild(lifecycleHeader);

      if (events.length === 0) {
        const noEv = document.createElement('p');
        noEv.className = 'text-muted text-center';
        noEv.style.padding = '1rem';
        noEv.textContent = 'No recorded provenance events exist for this execution trace correlation ID.';
        lifecycleCard.appendChild(noEv);
      } else {
        // Completeness / Availability Warning
        const isUnknown = trace.status === 'OUTCOME_UNKNOWN';
        const hasReconciliationViolations = trace.reconciliation && !trace.reconciliation.valid;

        if (isUnknown || hasReconciliationViolations) {
          const compWarning = document.createElement('div');
          compWarning.className = 'epistemic-disclaimer-box mb-1';
          compWarning.style.borderColor = 'var(--status-halted-border)';
          compWarning.style.backgroundColor = 'var(--status-halted-bg)';

          const warnTitle = document.createElement('strong');
          warnTitle.className = 'text-warning';
          warnTitle.textContent = 'LIFECYCLE COMPLETENESS WARNING: ';

          const warnBody = document.createElement('span');
          if (isUnknown && hasReconciliationViolations) {
            warnBody.textContent = 'Trace outcome is OUTCOME_UNKNOWN and exhibits reconciliation violations. Available records do not establish a complete lifecycle.';
          } else if (isUnknown) {
            warnBody.textContent = 'Trace ends without a terminal outcome event (OUTCOME_UNKNOWN). Available records represent a partial execution history.';
          } else {
            warnBody.textContent = 'Trace exhibits reconciliation violations across the recorded sequence. Sequence integrity cannot be verified.';
          }

          compWarning.appendChild(warnTitle);
          compWarning.appendChild(warnBody);
          lifecycleCard.appendChild(compWarning);
        }

        // Timeline Container
        const timeline = document.createElement('div');
        timeline.className = 'lifecycle-timeline';

        events.forEach((ev, idx) => {
          const isSelected = (this.state.selectedEventSeq !== null && this.state.selectedEventSeq !== undefined && ev.sequence_number === this.state.selectedEventSeq) ||
            ((this.state.selectedEventSeq === null || this.state.selectedEventSeq === undefined) && idx === 0 && this.state.mobileTraceLevel === 'event');

          const stage = document.createElement('div');
          let statusClass = 'status-recorded';
          const type = ev.event_type || 'UNKNOWN';

          if (type === 'AUTHORIZATION_DENIED') statusClass = 'status-failed';
          else if (type === 'EGRESS_BLOCKED') statusClass = 'status-halted';
          else if (type === 'EXECUTION_FAILED' || type === 'EXECUTION_INTERRUPTED') statusClass = 'status-failed';
          else if (type === 'EXECUTION_SUCCEEDED') statusClass = 'status-recorded'; // Recorded outcome stage

          stage.className = `lifecycle-stage ${statusClass} ${isSelected ? 'selected' : ''}`;

          const connector = document.createElement('div');
          connector.className = 'lifecycle-stage-connector';

          const node = document.createElement('div');
          node.className = 'lifecycle-stage-node';
          node.textContent = (ev.sequence_number !== null && ev.sequence_number !== undefined) ? ev.sequence_number : (idx + 1);

          const stageCard = document.createElement('div');
          stageCard.className = 'lifecycle-stage-card';
          stageCard.setAttribute('role', 'button');
          stageCard.setAttribute('tabindex', '0');
          stageCard.setAttribute('aria-pressed', isSelected ? 'true' : 'false');
          const seqDisplay = (ev.sequence_number !== null && ev.sequence_number !== undefined) ? ev.sequence_number : (idx + 1);
          stageCard.setAttribute('aria-label', `Select lifecycle stage #${seqDisplay} ${type}`);

          const handleSelectStage = () => {
            this.state.selectedEventSeq = ev.sequence_number;
            this.updateMobileTraceView('event');
            this.renderTraceDetail(trace, container);

            // Shift focus to Evidence Inspector for keyboard users
            const inspectorEl = document.getElementById('area-evidence-inspector');
            if (inspectorEl) {
              inspectorEl.setAttribute('tabindex', '-1');
              inspectorEl.focus();
            }
          };

          stageCard.addEventListener('click', handleSelectStage);
          stageCard.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              handleSelectStage();
            }
          });

          const stageHeader = document.createElement('div');
          stageHeader.className = 'lifecycle-stage-header';

          const stageTitle = document.createElement('span');
          stageTitle.className = 'lifecycle-stage-title';
          stageTitle.textContent = type;

          const stageBadge = this.createStatusBadge(
            type === 'AUTHORIZATION_DENIED' ? 'FAILED' :
            (type === 'EGRESS_BLOCKED' ? 'HALTED' :
            (type === 'EXECUTION_FAILED' || type === 'EXECUTION_INTERRUPTED' ? 'FAILED' : 'RECORDED'))
          );

          stageHeader.appendChild(stageTitle);
          stageHeader.appendChild(stageBadge);

          const stageBody = document.createElement('div');
          stageBody.className = 'lifecycle-stage-body';
          let bodyText = `Source: ${ev.provenance_source || 'Unknown'}`;
          if (ev.action_name) bodyText += ` • Action: ${ev.action_name}`;
          if (ev.target) bodyText += ` ➔ ${ev.target}`;
          stageBody.textContent = bodyText;

          const stageMeta = document.createElement('div');
          stageMeta.className = 'lifecycle-stage-meta';

          const tsSpan = document.createElement('span');
          tsSpan.textContent = ev.timestamp ? `Time: ${ev.timestamp}` : 'Time: UNRECORDED';

          const hashSpan = document.createElement('span');
          const shortHash = ev.entry_hash ? (ev.entry_hash.length > 14 ? ev.entry_hash.substring(0, 12) + '...' : ev.entry_hash) : 'No Hash';
          hashSpan.textContent = `Hash: ${shortHash}`;

          stageMeta.appendChild(tsSpan);
          stageMeta.appendChild(hashSpan);

          stageCard.appendChild(stageHeader);
          stageCard.appendChild(stageBody);
          stageCard.appendChild(stageMeta);

          stage.appendChild(connector);
          stage.appendChild(node);
          stage.appendChild(stageCard);

          timeline.appendChild(stage);
        });

        lifecycleCard.appendChild(timeline);
      }

      container.appendChild(lifecycleCard);

      // Area C: Evidence Inspector Panel for Selected Event
      const selectedEv = events.find(e => e.sequence_number === this.state.selectedEventSeq) || events[0];
      if (selectedEv) {
        const inspectorBox = document.createElement('div');
        inspectorBox.id = 'area-evidence-inspector';
        inspectorBox.style.marginTop = '1.25rem';
        inspectorBox.style.borderTop = '1px solid var(--border-default)';
        inspectorBox.style.paddingTop = '1rem';

        const inspHeader = document.createElement('div');
        inspHeader.style.display = 'flex';
        inspHeader.style.justifyContent = 'space-between';
        inspHeader.style.alignItems = 'center';
        inspHeader.style.marginBottom = '0.75rem';
        inspHeader.style.flexWrap = 'wrap';
        inspHeader.style.gap = '0.5rem';

        const inspTitle = document.createElement('h4');
        inspTitle.style.fontSize = '0.9rem';
        inspTitle.style.fontWeight = '700';
        inspTitle.style.color = 'var(--accent-primary)';
        inspTitle.textContent = `Evidence Inspector: Event #${selectedEv.sequence_number ?? '-'} (${selectedEv.event_type || 'UNKNOWN'})`;

        const inspCopyBtn = document.createElement('button');
        inspCopyBtn.type = 'button';
        inspCopyBtn.className = 'copy-btn';
        inspCopyBtn.textContent = 'Copy Event Payload JSON';
        inspCopyBtn.setAttribute('aria-label', `Copy full JSON payload for event sequence ${selectedEv.sequence_number ?? '-'}`);
        inspCopyBtn.setAttribute('title', `Copy JSON payload for event sequence ${selectedEv.sequence_number ?? '-'}`);
        inspCopyBtn.addEventListener('click', () => {
          this.copyToClipboard(JSON.stringify(selectedEv, null, 2), inspCopyBtn);
        });

        inspHeader.appendChild(inspTitle);
        inspHeader.appendChild(inspCopyBtn);
        inspectorBox.appendChild(inspHeader);

        // Grid Layout for Key Fields & Full Raw JSON Payload
        const inspectorGrid = document.createElement('div');
        inspectorGrid.className = 'evidence-inspector-grid';

        // Field Inspector Breakdown Card
        const fieldsCard = document.createElement('div');
        fieldsCard.className = 'card';
        fieldsCard.style.padding = '0.85rem';

        const fieldsHeader = document.createElement('div');
        fieldsHeader.className = 'card-header';
        fieldsHeader.textContent = 'Structured Event Metadata';
        fieldsCard.appendChild(fieldsHeader);

        const fieldList = [
          { label: 'Event ID', value: selectedEv.event_id, mono: true },
          { label: 'Event Type', value: selectedEv.event_type, bold: true },
          { label: 'Provenance Source', value: selectedEv.provenance_source },
          { label: 'Sequence Number', value: selectedEv.sequence_number, mono: true },
          { label: 'Timestamp', value: selectedEv.timestamp, mono: true },
          { label: 'Correlation ID', value: selectedEv.correlation_id, mono: true, copyable: true },
          { label: 'Request ID', value: selectedEv.request_id, mono: true, copyable: true },
          { label: 'Action Name', value: selectedEv.action_name },
          { label: 'Target Resource', value: selectedEv.target },
          { label: 'Capability Token ID', value: selectedEv.authorization_token_id, mono: true, copyable: true },
          { label: 'Canonical Request Digest', value: selectedEv.canonical_request_digest, mono: true, copyable: true },
          { label: 'Policy Version', value: selectedEv.policy_version, mono: true },
          { label: 'Previous Entry Hash', value: selectedEv.prev_hash, mono: true, copyable: true },
          { label: 'Entry Cryptographic Hash', value: selectedEv.entry_hash, mono: true, copyable: true }
        ];

        fieldList.forEach(item => {
          const row = document.createElement('div');
          row.style.marginBottom = '0.4rem';
          row.style.fontSize = '0.8rem';
          row.style.wordBreak = 'break-all';

          const lbl = document.createElement('span');
          lbl.style.color = 'var(--text-secondary)';
          lbl.style.fontWeight = '600';
          lbl.textContent = `${item.label}: `;
          row.appendChild(lbl);

          const valSpan = document.createElement('span');
          if (item.value !== null && item.value !== undefined && item.value !== '') {
            valSpan.textContent = String(item.value);
            if (item.mono) valSpan.className = 'font-mono';
            if (item.bold) valSpan.style.fontWeight = '700';
            row.appendChild(valSpan);

            if (item.copyable) {
              const btn = document.createElement('button');
              btn.type = 'button';
              btn.className = 'copy-btn';
              btn.style.marginLeft = '0.4rem';
              btn.style.padding = '0.1rem 0.35rem';
              btn.style.fontSize = '0.65rem';
              btn.textContent = 'Copy';
              btn.setAttribute('aria-label', `Copy ${item.label}`);
              btn.setAttribute('title', `Copy ${item.label} to clipboard`);
              btn.addEventListener('click', () => this.copyToClipboard(String(item.value), btn));
              row.appendChild(btn);
            }
          } else {
            valSpan.className = 'text-dim';
            valSpan.textContent = 'UNAVAILABLE / NOT RECORDED';
            row.appendChild(valSpan);
          }

          fieldsCard.appendChild(row);
        });

        // Raw JSON Block Card
        const jsonCard = document.createElement('div');
        jsonCard.className = 'card';
        jsonCard.style.padding = '0.85rem';

        const jsonHeader = document.createElement('div');
        jsonHeader.className = 'card-header';
        jsonHeader.textContent = 'Raw Event JSON Record';
        jsonCard.appendChild(jsonHeader);

        const pre = document.createElement('pre');
        pre.className = 'inspector-block';
        pre.setAttribute('tabindex', '0');
        pre.setAttribute('role', 'region');
        pre.setAttribute('aria-label', 'Raw Event JSON Record');
        pre.textContent = JSON.stringify(selectedEv, null, 2);
        jsonCard.appendChild(pre);

        inspectorGrid.appendChild(fieldsCard);
        inspectorGrid.appendChild(jsonCard);
        inspectorBox.appendChild(inspectorGrid);
        container.appendChild(inspectorBox);
      }
    },

    // -------------------------------------------------------------------------
    // View 3: Provenance Explorer
    // -------------------------------------------------------------------------
    async loadProvenance() {
      const recListUl = document.getElementById('provenance-record-list');
      if (recListUl && (!this.state.provenanceData || !this.state.provenanceData.events)) {
        recListUl.innerHTML = '<li class="text-muted text-center" style="padding: 1.5rem;">Loading provenance records...</li>';
      }

      try {
        const [provRes, tracesRes] = await Promise.all([
          fetch('/api/provenance'),
          fetch('/api/traces').catch(() => null)
        ]);

        if (!provRes.ok) throw new Error(`HTTP error ${provRes.status}`);
        const provData = await provRes.json();
        this.state.provenanceData = provData;

        if (tracesRes && tracesRes.ok) {
          this.state.tracesData = await tracesRes.json();
        }

        this.renderProvenance();
      } catch (err) {
        console.error('Failed to load provenance data:', err);
        this.renderProvenanceError(err.message);
      }
    },

    renderProvenanceError(errorMsg) {
      const recListUl = document.getElementById('provenance-record-list');
      if (recListUl) {
        recListUl.innerHTML = '';
        const errLi = document.createElement('li');
        errLi.className = 'text-danger text-center';
        errLi.setAttribute('role', 'option');
        errLi.setAttribute('aria-selected', 'false');
        errLi.style.padding = '1.5rem 1rem';

        const msgSpan = document.createElement('span');
        msgSpan.style.display = 'block';
        msgSpan.style.marginBottom = '0.5rem';
        msgSpan.style.fontWeight = '600';
        msgSpan.textContent = 'Failed to load provenance data.';

        const detailSpan = document.createElement('span');
        detailSpan.className = 'text-muted font-mono';
        detailSpan.style.fontSize = '0.75rem';
        detailSpan.style.display = 'block';
        detailSpan.style.marginBottom = '0.75rem';
        detailSpan.textContent = `Server API Error: ${errorMsg}`;

        const retryBtn = document.createElement('button');
        retryBtn.type = 'button';
        retryBtn.className = 'btn-refresh';
        retryBtn.textContent = 'Retry Loading Provenance';
        retryBtn.setAttribute('aria-label', 'Retry loading provenance records');
        retryBtn.setAttribute('title', 'Retry loading provenance records');
        retryBtn.addEventListener('click', () => this.executeWithRetryFeedback(retryBtn, 'Retrying Provenance...', () => this.loadProvenance()));

        errLi.appendChild(msgSpan);
        errLi.appendChild(detailSpan);
        errLi.appendChild(retryBtn);
        recListUl.appendChild(errLi);
      }

      const countBadge = document.getElementById('provenance-count');
      if (countBadge) countBadge.textContent = 'ERROR';
    },

    renderProvenance() {
      const data = this.state.provenanceData;
      if (!data) return;

      this.renderProvenanceSummaryPanels(data.summary_panels || {});
      this.renderProvenanceFindings(data.findings || []);
      this.renderProvenanceRecordList();
    },

    renderProvenanceSummaryPanels(panels) {
      // Panel 1: Availability
      const pAvail = panels.availability || {};
      const elAvailBadge = document.getElementById('summary-avail-badge');
      const elAvailMsg = document.getElementById('summary-avail-msg');
      if (elAvailBadge) {
        const badge = this.createStatusBadge(pAvail.status || 'UNAVAILABLE');
        elAvailBadge.replaceWith(badge);
        badge.id = 'summary-avail-badge';
      }
      if (elAvailMsg) {
        elAvailMsg.textContent = pAvail.message || 'Availability unverified.';
      }

      // Panel 2: Integrity
      const pInteg = panels.integrity || {};
      const elIntegBadge = document.getElementById('summary-integrity-badge');
      const elIntegMsg = document.getElementById('summary-integrity-msg');
      if (elIntegBadge) {
        const badge = this.createStatusBadge(pInteg.status || 'UNAVAILABLE');
        elIntegBadge.replaceWith(badge);
        badge.id = 'summary-integrity-badge';
      }
      if (elIntegMsg) {
        let msg = pInteg.message || 'Integrity unverified.';
        if (pInteg.last_hash) {
          const shortHash = pInteg.last_hash.substring(0, 16) + '...';
          msg += ` (Tail Hash: ${shortHash})`;
        }
        elIntegMsg.textContent = msg;
      }

      // Panel 3: Coverage
      const pCov = panels.coverage || {};
      const elCovBadge = document.getElementById('summary-coverage-badge');
      const elCovMsg = document.getElementById('summary-coverage-msg');
      if (elCovBadge) {
        const badge = this.createStatusBadge(pCov.status || 'UNVERIFIED');
        elCovBadge.replaceWith(badge);
        badge.id = 'summary-coverage-badge';
      }
      if (elCovMsg) {
        elCovMsg.textContent = pCov.message || 'Trace coverage unverified.';
      }

      // Panel 4: Authenticity
      const pAuth = panels.authenticity || {};
      const elAuthBadge = document.getElementById('summary-authenticity-badge');
      const elAuthMsg = document.getElementById('summary-authenticity-msg');
      if (elAuthBadge) {
        const badge = this.createStatusBadge(pAuth.status || 'NOT ESTABLISHED');
        elAuthBadge.replaceWith(badge);
        badge.id = 'summary-authenticity-badge';
      }
      if (elAuthMsg) {
        elAuthMsg.textContent = pAuth.message || 'Source authenticity unestablished.';
      }
    },

    renderProvenanceFindings(findings) {
      const container = document.getElementById('provenance-findings-container');
      if (!container) return;
      container.innerHTML = '';

      if (!findings || findings.length === 0) {
        const p = document.createElement('p');
        p.className = 'text-muted text-center';
        p.style.padding = '0.5rem';
        p.textContent = 'Zero verification findings or anomalies reported.';
        container.appendChild(p);
        return;
      }

      const grid = document.createElement('div');
      grid.style.display = 'grid';
      grid.style.gridTemplateColumns = 'repeat(auto-fit, minmax(280px, 1fr))';
      grid.style.gap = '0.75rem';

      findings.forEach(f => {
        const card = document.createElement('div');
        card.className = 'status-block';
        card.style.fontSize = '0.825rem';

        if (f.severity === 'CRITICAL' || f.severity === 'HIGH') {
          card.style.borderColor = 'var(--status-failed-border)';
          card.style.backgroundColor = 'var(--status-failed-bg)';
        } else if (f.severity === 'WARNING') {
          card.style.borderColor = 'var(--status-halted-border)';
          card.style.backgroundColor = 'var(--status-halted-bg)';
        } else {
          card.style.borderColor = 'var(--border-default)';
        }

        const titleRow = document.createElement('div');
        titleRow.style.display = 'flex';
        titleRow.style.justifyContent = 'space-between';
        titleRow.style.alignItems = 'center';
        titleRow.style.marginBottom = '0.35rem';

        const titleSpan = document.createElement('strong');
        titleSpan.textContent = f.title || f.code;

        const sevBadge = document.createElement('span');
        sevBadge.className = 'font-mono text-dim';
        sevBadge.style.fontSize = '0.7rem';
        sevBadge.style.padding = '0.1rem 0.35rem';
        sevBadge.style.borderRadius = '3px';
        sevBadge.style.border = '1px solid var(--border-default)';
        sevBadge.textContent = f.severity || 'INFO';

        titleRow.appendChild(titleSpan);
        titleRow.appendChild(sevBadge);

        const descP = document.createElement('div');
        descP.className = 'text-muted';
        descP.style.fontSize = '0.8rem';
        descP.textContent = f.description;

        card.appendChild(titleRow);
        card.appendChild(descP);
        grid.appendChild(card);
      });

      container.appendChild(grid);
    },

    renderProvenanceRecordList() {
      const listUl = document.getElementById('provenance-record-list');
      if (!listUl) return;
      const areaProvList = document.getElementById('area-provenance-list');
      listUl.innerHTML = '';

      const data = this.state.provenanceData;
      const events = (data && Array.isArray(data.events)) ? data.events : [];

      let filtered = events.filter(ev => {
        if (this.state.provenanceFilterType !== 'ALL' && ev.event_type !== this.state.provenanceFilterType) {
          return false;
        }
        if (this.state.provenanceSearchQuery) {
          const q = this.state.provenanceSearchQuery;
          const id = (ev.event_id || '').toLowerCase();
          const corr = (ev.correlation_id || '').toLowerCase();
          const req = (ev.request_id || '').toLowerCase();
          const src = (ev.provenance_source || '').toLowerCase();
          const act = (ev.action_name || '').toLowerCase();
          const tgt = (ev.target || '').toLowerCase();
          const hash = (ev.entry_hash || '').toLowerCase();
          const prev = (ev.prev_hash || '').toLowerCase();
          return id.includes(q) || corr.includes(q) || req.includes(q) || src.includes(q) || act.includes(q) || tgt.includes(q) || hash.includes(q) || prev.includes(q);
        }
        return true;
      });

      const countBadge = document.getElementById('provenance-count');
      if (countBadge) {
        const total = events.length;
        const visible = filtered.length;
        countBadge.textContent = total === visible ? `${total}` : `${visible} of ${total}`;
        countBadge.setAttribute('aria-label', total === visible ? `${total} records` : `${visible} of ${total} records shown`);
      }

      // Clean up any previously attached clear-action bar
      const existingProvClear = areaProvList?.querySelector('.stream-clear-action-bar');
      if (existingProvClear) existingProvClear.remove();

      if (filtered.length === 0) {
        const emptyLi = document.createElement('li');
        emptyLi.className = 'text-muted text-center';
        emptyLi.setAttribute('role', 'option');
        emptyLi.setAttribute('aria-selected', 'false');
        emptyLi.style.padding = '1.5rem 1rem';

        const hasFilters = this.state.provenanceSearchQuery || this.state.provenanceFilterType !== 'ALL';
        if (hasFilters) {
          emptyLi.textContent = 'No provenance records match active search query or filter.';

          const clearBar = document.createElement('div');
          clearBar.className = 'stream-clear-action-bar text-center';
          clearBar.style.padding = '0.5rem 1rem 1rem';

          const clearBtn = document.createElement('button');
          clearBtn.type = 'button';
          clearBtn.className = 'btn-refresh';
          clearBtn.textContent = 'Clear Filters';
          clearBtn.setAttribute('aria-label', 'Clear search query and event type filter');
          clearBtn.setAttribute('title', 'Clear active search query and event type filter');
          clearBtn.addEventListener('click', () => {
            this.state.provenanceSearchQuery = '';
            this.state.provenanceFilterType = 'ALL';
            const searchInput = document.getElementById('provenance-search');
            if (searchInput) {
              searchInput.value = '';
              searchInput.focus();
            }
            const typeFilter = document.getElementById('provenance-type-filter');
            if (typeFilter) typeFilter.value = 'ALL';
            this.announce('Provenance filters cleared. Showing all records.');
            this.renderProvenanceRecordList();
          });

          clearBar.appendChild(clearBtn);
          areaProvList?.appendChild(clearBar);
        } else {
          emptyLi.textContent = 'No provenance records present in log stream.';
        }

        listUl.appendChild(emptyLi);
        return;
      }

      filtered.forEach((ev, index) => {
        const recId = ev.event_id || `seq_${ev.sequence_number}`;
        const isSelected = this.state.selectedRecordId === recId;

        const li = document.createElement('li');
        li.className = `trace-item ${isSelected ? 'active' : ''}`;
        li.setAttribute('role', 'option');
        li.setAttribute('tabindex', '0');
        li.setAttribute('aria-selected', isSelected ? 'true' : 'false');
        li.setAttribute('aria-label', `Provenance event sequence ${ev.sequence_number}, type ${ev.event_type}`);

        li.addEventListener('click', () => this.selectProvenanceRecord(recId));
        li.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.selectProvenanceRecord(recId);
          } else if (e.key === 'ArrowDown') {
            e.preventDefault();
            const items = listUl.querySelectorAll('.trace-item');
            if (index + 1 < items.length) items[index + 1].focus();
          } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            const items = listUl.querySelectorAll('.trace-item');
            if (index - 1 >= 0) items[index - 1].focus();
          } else if (e.key === 'Home') {
            e.preventDefault();
            const items = listUl.querySelectorAll('.trace-item');
            if (items.length > 0) items[0].focus();
          } else if (e.key === 'End') {
            e.preventDefault();
            const items = listUl.querySelectorAll('.trace-item');
            if (items.length > 0) items[items.length - 1].focus();
          }
        });

        const headerDiv = document.createElement('div');
        headerDiv.className = 'trace-item-header';

        const seqSpan = document.createElement('span');
        seqSpan.className = 'font-mono';
        seqSpan.style.fontWeight = '700';
        seqSpan.style.fontSize = '0.8rem';
        seqSpan.style.color = 'var(--accent-primary)';
        seqSpan.textContent = `#${ev.sequence_number ?? '-'}`;

        const typeSpan = document.createElement('span');
        typeSpan.className = 'trace-id';
        typeSpan.style.fontSize = '0.8rem';
        typeSpan.textContent = ev.event_type || 'UNKNOWN';

        headerDiv.appendChild(seqSpan);
        headerDiv.appendChild(typeSpan);

        const subDiv = document.createElement('div');
        subDiv.className = 'text-muted';
        subDiv.style.fontSize = '0.75rem';
        subDiv.style.marginTop = '0.2rem';
        subDiv.textContent = `Src: ${ev.provenance_source || 'N/A'} • ${ev.action_name || 'N/A'}`;

        const hashDiv = document.createElement('div');
        hashDiv.className = 'font-mono text-dim';
        hashDiv.style.fontSize = '0.7rem';
        hashDiv.style.marginTop = '0.15rem';
        const entryHashShort = (ev.entry_hash || 'N/A').substring(0, 16) + '...';
        hashDiv.textContent = `Hash: ${entryHashShort}`;

        li.appendChild(headerDiv);
        li.appendChild(subDiv);
        li.appendChild(hashDiv);
        listUl.appendChild(li);
      });
    },

    selectProvenanceRecord(recId) {
      this.state.selectedRecordId = recId;
      this.announce(`Selected provenance record ${recId}`);
      this.renderProvenanceRecordList();

      const emptyDiv = document.getElementById('provenance-inspector-empty');
      const contentDiv = document.getElementById('provenance-inspector-content');

      if (!recId) {
        if (emptyDiv) emptyDiv.classList.remove('hidden');
        if (contentDiv) contentDiv.classList.add('hidden');
        return;
      }

      const events = (this.state.provenanceData && Array.isArray(this.state.provenanceData.events)) ? this.state.provenanceData.events : [];
      const record = events.find(e => (e.event_id === recId) || (`seq_${e.sequence_number}` === recId));

      if (!record) {
        if (emptyDiv) emptyDiv.classList.remove('hidden');
        if (contentDiv) contentDiv.classList.add('hidden');
        return;
      }

      if (emptyDiv) emptyDiv.classList.add('hidden');
      if (contentDiv) {
        contentDiv.classList.remove('hidden');
        this.renderProvenanceRecordInspector(record, contentDiv);
      }
    },

    renderProvenanceRecordInspector(record, container) {
      container.innerHTML = '';

      // Header with Copy and Related Trace Jump
      const headerBar = document.createElement('div');
      headerBar.style.display = 'flex';
      headerBar.style.justifyContent = 'space-between';
      headerBar.style.alignItems = 'center';
      headerBar.style.marginBottom = '1rem';
      headerBar.style.flexWrap = 'wrap';
      headerBar.style.gap = '0.5rem';

      const titleGroup = document.createElement('div');
      const title = document.createElement('h3');
      title.style.fontSize = '1.05rem';
      title.style.fontWeight = '700';
      title.style.margin = '0';
      title.className = 'font-mono';
      title.textContent = `Record #${record.sequence_number} • ${record.event_type}`;
      titleGroup.appendChild(title);

      const actionBtnGroup = document.createElement('div');
      actionBtnGroup.style.display = 'flex';
      actionBtnGroup.style.gap = '0.5rem';

      // Related Trace Button
      const corrId = record.correlation_id;
      const matchingTrace = corrId ? this.state.tracesData.find(t => t.correlation_id === corrId) : null;

      if (matchingTrace) {
        const traceBtn = document.createElement('button');
        traceBtn.type = 'button';
        traceBtn.className = 'quick-entry-btn';
        traceBtn.style.padding = '0.25rem 0.6rem';
        traceBtn.style.fontSize = '0.75rem';
        traceBtn.setAttribute('aria-label', `Navigate to related execution trace ${corrId}`);
        traceBtn.setAttribute('title', `Navigate to related execution trace ${corrId}`);
        traceBtn.innerHTML = `<span>View Related Trace</span> <span class="arrow" aria-hidden="true">➔</span>`;
        traceBtn.addEventListener('click', async () => {
          this.state.selectedTraceId = corrId;
          this.switchTab('traces');
          await this.selectTrace(corrId);
          const activeItem = document.querySelector('#trace-list .trace-item.active');
          if (activeItem) {
            activeItem.focus();
          }
        });
        actionBtnGroup.appendChild(traceBtn);
      }

      const copyRecordBtn = document.createElement('button');
      copyRecordBtn.type = 'button';
      copyRecordBtn.className = 'copy-btn';
      copyRecordBtn.textContent = 'Copy Record JSON';
      copyRecordBtn.setAttribute('aria-label', `Copy JSON payload for record sequence ${record.sequence_number}`);
      copyRecordBtn.setAttribute('title', `Copy JSON payload for record sequence ${record.sequence_number}`);
      copyRecordBtn.addEventListener('click', () => this.copyToClipboard(JSON.stringify(record, null, 2), copyRecordBtn));
      actionBtnGroup.appendChild(copyRecordBtn);

      headerBar.appendChild(titleGroup);
      headerBar.appendChild(actionBtnGroup);
      container.appendChild(headerBar);

      // Card 1: Key Metadata Breakdown
      const metaCard = document.createElement('div');
      metaCard.className = 'card mb-1';

      const metaHeader = document.createElement('div');
      metaHeader.className = 'card-header';
      metaHeader.textContent = 'Record Information & Context';
      metaCard.appendChild(metaHeader);

      const fieldList = [
        { label: 'Record Identifier', value: record.event_id, mono: true, copyable: true },
        { label: 'Event Type', value: record.event_type, bold: true },
        { label: 'Provenance Source', value: record.provenance_source },
        { label: 'Sequence Number', value: record.sequence_number, mono: true },
        { label: 'Timestamp', value: record.timestamp || 'TIMESTAMP UNRECORDED', mono: true },
        { label: 'Correlation ID', value: record.correlation_id, mono: true, copyable: true },
        { label: 'Request ID', value: record.request_id, mono: true, copyable: true },
        { label: 'Action Name', value: record.action_name },
        { label: 'Target Resource', value: record.target },
        { label: 'Capability Token ID', value: record.authorization_token_id, mono: true, copyable: true },
        { label: 'Canonical Request Digest', value: record.canonical_request_digest, mono: true, copyable: true },
        { label: 'Policy Version', value: record.policy_version, mono: true }
      ];

      fieldList.forEach(item => {
        const row = document.createElement('div');
        row.style.marginBottom = '0.4rem';
        row.style.fontSize = '0.8rem';
        row.style.wordBreak = 'break-all';

        const lbl = document.createElement('span');
        lbl.style.color = 'var(--text-secondary)';
        lbl.style.fontWeight = '600';
        lbl.textContent = `${item.label}: `;
        row.appendChild(lbl);

        const valSpan = document.createElement('span');
        if (item.value !== null && item.value !== undefined && item.value !== '') {
          valSpan.textContent = String(item.value);
          if (item.mono) valSpan.className = 'font-mono';
          if (item.bold) valSpan.style.fontWeight = '700';
          row.appendChild(valSpan);

          if (item.copyable) {
            const btn = document.createElement('button');
              btn.type = 'button';
            btn.className = 'copy-btn';
            btn.style.marginLeft = '0.4rem';
            btn.style.padding = '0.1rem 0.35rem';
            btn.style.fontSize = '0.65rem';
            btn.textContent = 'Copy';
            btn.setAttribute('aria-label', `Copy ${item.label}`);
              btn.setAttribute('title', `Copy ${item.label} to clipboard`);
            btn.addEventListener('click', () => this.copyToClipboard(String(item.value), btn));
            row.appendChild(btn);
          }
        } else {
          valSpan.className = 'text-dim';
          valSpan.textContent = 'UNAVAILABLE / NOT RECORDED';
          row.appendChild(valSpan);
        }

        metaCard.appendChild(row);
      });

      container.appendChild(metaCard);

      // Card 2: Cryptographic Chain Linkage Inspector
      const chainCard = document.createElement('div');
      chainCard.className = 'card mb-1';

      const chainHeader = document.createElement('div');
      chainHeader.className = 'card-header';
      chainHeader.textContent = 'Cryptographic Sequence Chaining Linkage';
      chainCard.appendChild(chainHeader);

      const prevRow = document.createElement('div');
      prevRow.style.marginBottom = '0.5rem';
      prevRow.style.fontSize = '0.8rem';
      prevRow.style.wordBreak = 'break-all';

      const prevLbl = document.createElement('strong');
      prevLbl.textContent = 'Predecessor Entry Hash (prev_hash): ';

      const prevVal = document.createElement('span');
      prevVal.className = 'font-mono text-dim';
      prevVal.textContent = record.prev_hash || 'GENESIS (No Predecessor)';

      prevRow.appendChild(prevLbl);
      prevRow.appendChild(prevVal);

      if (record.prev_hash) {
        const copyPrevBtn = document.createElement('button');
        copyPrevBtn.type = 'button';
        copyPrevBtn.className = 'copy-btn';
        copyPrevBtn.style.marginLeft = '0.4rem';
        copyPrevBtn.style.padding = '0.1rem 0.35rem';
        copyPrevBtn.style.fontSize = '0.65rem';
        copyPrevBtn.textContent = 'Copy';
        copyPrevBtn.setAttribute('aria-label', 'Copy predecessor entry hash');
        copyPrevBtn.setAttribute('title', 'Copy predecessor entry hash to clipboard');
        copyPrevBtn.addEventListener('click', () => this.copyToClipboard(record.prev_hash, copyPrevBtn));
        prevRow.appendChild(copyPrevBtn);
      }

      const currRow = document.createElement('div');
      currRow.style.marginBottom = '0.5rem';
      currRow.style.fontSize = '0.8rem';
      currRow.style.wordBreak = 'break-all';

      const currLbl = document.createElement('strong');
      currLbl.textContent = 'Current Cryptographic Entry Hash (entry_hash): ';

      const currVal = document.createElement('span');
      currVal.className = 'font-mono';
      currVal.style.color = 'var(--accent-primary)';
      currVal.textContent = record.entry_hash || 'UNAVAILABLE';

      currRow.appendChild(currLbl);
      currRow.appendChild(currVal);

      if (record.entry_hash) {
        const copyCurrBtn = document.createElement('button');
        copyCurrBtn.type = 'button';
        copyCurrBtn.className = 'copy-btn';
        copyCurrBtn.style.marginLeft = '0.4rem';
        copyCurrBtn.style.padding = '0.1rem 0.35rem';
        copyCurrBtn.style.fontSize = '0.65rem';
        copyCurrBtn.textContent = 'Copy';
        copyCurrBtn.setAttribute('aria-label', 'Copy current entry hash');
        copyCurrBtn.setAttribute('title', 'Copy current entry hash to clipboard');
        copyCurrBtn.addEventListener('click', () => this.copyToClipboard(record.entry_hash, copyCurrBtn));
        currRow.appendChild(copyCurrBtn);
      }

      chainCard.appendChild(prevRow);
      chainCard.appendChild(currRow);
      container.appendChild(chainCard);

      // Card 3: Raw JSON Record Payload
      const jsonCard = document.createElement('div');
      jsonCard.className = 'card';

      const jsonHeader = document.createElement('div');
      jsonHeader.className = 'card-header';
      jsonHeader.textContent = 'Original Raw Record JSON Payload';
      jsonCard.appendChild(jsonHeader);

      const pre = document.createElement('pre');
      pre.className = 'inspector-block';
      pre.setAttribute('tabindex', '0');
      pre.setAttribute('role', 'region');
      pre.setAttribute('aria-label', 'Original Raw Record JSON Payload');
      pre.textContent = JSON.stringify(record, null, 2);

      jsonCard.appendChild(pre);
      container.appendChild(jsonCard);
    },

    // -------------------------------------------------------------------------
    // View 4: Benchmark Workbench
    // -------------------------------------------------------------------------
    async loadBenchmarks() {
      const caseListUl = document.getElementById('benchmark-case-list');
      if (caseListUl && (!this.state.benchmarkData)) {
        caseListUl.innerHTML = '<li class="text-muted text-center" style="padding: 1.5rem;">Loading benchmark cases...</li>';
      }

      try {
        const res = await fetch('/api/benchmarks');
        if (!res.ok) throw new Error(`HTTP error ${res.status}`);
        const data = await res.json();
        this.state.benchmarkData = data;
        this.populateBaselineFilterOptions();
        this.populateFamilyFilterOptions();
        this.renderBenchmarks();
      } catch (err) {
        console.error('Failed to load benchmarks:', err);
        this.renderBenchmarkLoadError(err.message);
      }
    },

    renderBenchmarkLoadError(errorMsg) {
      const statusBadge = document.getElementById('benchmark-artifacts-status');
      if (statusBadge) {
        const badge = this.createStatusBadge('UNAVAILABLE');
        statusBadge.replaceWith(badge);
        badge.id = 'benchmark-artifacts-status';
      }

      const caseListUl = document.getElementById('benchmark-case-list');
      if (caseListUl) {
        caseListUl.innerHTML = '';
        const errLi = document.createElement('li');
        errLi.className = 'text-danger text-center';
        errLi.setAttribute('role', 'option');
        errLi.setAttribute('aria-selected', 'false');
        errLi.style.padding = '1.5rem 1rem';

        const msgSpan = document.createElement('span');
        msgSpan.style.display = 'block';
        msgSpan.style.marginBottom = '0.5rem';
        msgSpan.style.fontWeight = '600';
        msgSpan.textContent = 'Failed to load benchmark artifacts.';

        const detailSpan = document.createElement('span');
        detailSpan.className = 'text-muted font-mono';
        detailSpan.style.fontSize = '0.75rem';
        detailSpan.style.display = 'block';
        detailSpan.style.marginBottom = '0.75rem';
        detailSpan.textContent = `Server API Error: ${errorMsg}`;

        const retryBtn = document.createElement('button');
        retryBtn.type = 'button';
        retryBtn.className = 'btn-refresh';
        retryBtn.textContent = 'Retry Loading Benchmarks';
        retryBtn.setAttribute('aria-label', 'Retry loading benchmark artifacts');
        retryBtn.setAttribute('title', 'Retry loading benchmark artifacts');
        retryBtn.addEventListener('click', () => this.executeWithRetryFeedback(retryBtn, 'Retrying Benchmarks...', () => this.loadBenchmarks()));

        errLi.appendChild(msgSpan);
        errLi.appendChild(detailSpan);
        errLi.appendChild(retryBtn);
        caseListUl.appendChild(errLi);
      }

      const countBadge = document.getElementById('benchmark-case-count');
      if (countBadge) countBadge.textContent = 'ERROR';
    },

    populateBaselineFilterOptions() {
      const selectEl = document.getElementById('benchmark-case-baseline-filter');
      if (!selectEl) return;

      const data = this.state.benchmarkData;
      const pc = data?.per_case_results;
      const caseList = (pc?.available && Array.isArray(pc.data)) ? pc.data : [];

      const distinctBaselines = new Set();
      caseList.forEach(c => {
        if (c && c.baseline) distinctBaselines.add(c.baseline);
      });

      // Preserve existing selected value if possible
      const currentVal = selectEl.value || 'ALL';

      selectEl.innerHTML = '';
      const allOpt = document.createElement('option');
      allOpt.value = 'ALL';
      allOpt.textContent = 'All Baselines';
      selectEl.appendChild(allOpt);

      Array.from(distinctBaselines).sort().forEach(baseName => {
        const opt = document.createElement('option');
        opt.value = baseName;
        opt.textContent = baseName;
        selectEl.appendChild(opt);
      });

      selectEl.value = Array.from(distinctBaselines).includes(currentVal) ? currentVal : 'ALL';
      this.state.caseBaselineFilter = selectEl.value;
    },

    populateFamilyFilterOptions() {
      const selectEl = document.getElementById('benchmark-case-family-filter');
      if (!selectEl) return;

      const data = this.state.benchmarkData;
      const pc = data?.per_case_results;
      const caseList = (pc?.available && Array.isArray(pc.data)) ? pc.data : [];

      const distinctFamilies = new Set();
      caseList.forEach(c => {
        const fam = c?.scenario_family || c?.family || c?.category;
        if (fam) distinctFamilies.add(fam);
      });

      const currentVal = selectEl.value || 'ALL';

      selectEl.innerHTML = '';
      const allOpt = document.createElement('option');
      allOpt.value = 'ALL';
      allOpt.textContent = 'All Families';
      selectEl.appendChild(allOpt);

      Array.from(distinctFamilies).sort().forEach(famName => {
        const opt = document.createElement('option');
        opt.value = famName;
        opt.textContent = famName;
        selectEl.appendChild(opt);
      });

      selectEl.value = Array.from(distinctFamilies).includes(currentVal) ? currentVal : 'ALL';
      this.state.caseFamilyFilter = selectEl.value;
    },

    renderBenchmarks() {
      const data = this.state.benchmarkData;
      if (!data) return;

      this.renderRunSummary();
      this.renderConditionComparisons();
      this.renderBenchmarkCasesList();
      this.renderMethodologyAndLimitations();
    },

    // -------------------------------------------------------------------------
    // Workbench Section 1: Run Summary
    // -------------------------------------------------------------------------
    renderRunSummary() {
      const data = this.state.benchmarkData || {};
      const abl = data.ablation_table || {};
      const pc = data.per_case_results || {};

      const ablData = abl.available ? abl.data : null;
      const pcData = (pc.available && Array.isArray(pc.data)) ? pc.data : null;

      // Artifact Status Badge
      const statusBadge = document.getElementById('benchmark-artifacts-status');
      if (statusBadge) {
        const deriveItemStatus = (item) => {
          if (item.status) return item.status;
          if (item.error) {
            if (item.error.toLowerCase().includes('malformed') || item.error.toLowerCase().includes('unexpected json structure')) return 'MALFORMED';
            if (item.error.toLowerCase().includes('empty')) return 'EMPTY';
            return 'UNAVAILABLE';
          }
          return item.available ? 'AVAILABLE' : 'UNAVAILABLE';
        };

        const ablStatus = deriveItemStatus(abl);
        const pcStatus = deriveItemStatus(pc);

        const statusStr = this.deriveCombinedBenchmarkStatus(ablStatus, pcStatus);

        const badge = this.createStatusBadge(statusStr);
        statusBadge.replaceWith(badge);
        badge.id = 'benchmark-artifacts-status';
      }

      // Run Identifier
      const runId = (ablData && ablData.run_id) ? ablData.run_id : ((pcData && pcData.length > 0 && pcData[0].run_id) ? pcData[0].run_id : null);
      this.renderSummaryValue('summary-run-id', runId);

      // Evaluated Sample Count
      const sampleCount = (ablData && ablData.eval_sample_count !== undefined && ablData.eval_sample_count !== null) ? ablData.eval_sample_count : (pcData ? pcData.length : null);
      this.renderSummaryValue('summary-sample-count', sampleCount);

      // Dataset SHA256 Digest
      const datasetDigest = (ablData && ablData.dataset_sha256_digest) ? ablData.dataset_sha256_digest : ((pcData && pcData.length > 0 && pcData[0].dataset_sha256_digest) ? pcData[0].dataset_sha256_digest : null);
      this.renderSummaryDigestValue('summary-dataset-digest', datasetDigest, 'Dataset SHA-256 Digest');

      // Run Records SHA256 Digest
      const recordsDigest = (ablData && ablData.run_records_sha256_digest) ? ablData.run_records_sha256_digest : null;
      this.renderSummaryDigestValue('summary-records-digest', recordsDigest, 'Run Records SHA-256 Digest');

      // Version & Seed
      this.renderSummaryValue('summary-version', ablData ? ablData.version : null);
      this.renderSummaryValue('summary-seed', (ablData && ablData.seed !== undefined && ablData.seed !== null) ? ablData.seed : null);

      // Artifact Error / Warning Alerts Container
      const alertContainer = document.getElementById('benchmark-artifacts-alert-container');
      if (alertContainer) {
        alertContainer.innerHTML = '';

        // Preserve visibility of individual artifact status and errors whenever any artifact is degraded or missing
        const ablItemStatus = (abl.status || (abl.error ? (abl.error.toLowerCase().includes('malformed') ? 'MALFORMED' : (abl.error.toLowerCase().includes('empty') ? 'EMPTY' : 'UNAVAILABLE')) : (abl.available ? 'AVAILABLE' : 'UNAVAILABLE'))).toUpperCase();
        const pcItemStatus = (pc.status || (pc.error ? (pc.error.toLowerCase().includes('malformed') ? 'MALFORMED' : (pc.error.toLowerCase().includes('empty') ? 'EMPTY' : 'UNAVAILABLE')) : (pc.available ? 'AVAILABLE' : 'UNAVAILABLE'))).toUpperCase();

        if (ablItemStatus !== 'AVAILABLE' || pcItemStatus !== 'AVAILABLE') {
          const breakdownCard = document.createElement('div');
          breakdownCard.className = 'status-block';
          breakdownCard.style.fontSize = '0.8rem';
          breakdownCard.style.marginTop = '0.5rem';

          if (ablItemStatus === 'MALFORMED' || pcItemStatus === 'MALFORMED') {
            breakdownCard.style.borderColor = 'var(--status-failed-border)';
            breakdownCard.style.backgroundColor = 'var(--status-failed-bg)';
          } else {
            breakdownCard.style.borderColor = 'var(--border-default)';
          }

          const title = document.createElement('strong');
          title.style.display = 'block';
          title.style.marginBottom = '0.35rem';
          title.textContent = 'Individual Artifact Status Breakdown:';
          breakdownCard.appendChild(title);

          const ul = document.createElement('ul');
          ul.style.marginLeft = '1.2rem';
          ul.style.display = 'flex';
          ul.style.flexDirection = 'column';
          ul.style.gap = '0.25rem';

          const liAbl = document.createElement('li');
          liAbl.textContent = `Ablation Table (ablation_table.json): ${ablItemStatus}${abl.error ? ' — ' + abl.error : ''}`;
          ul.appendChild(liAbl);

          const liPc = document.createElement('li');
          liPc.textContent = `Per-Case Results (per_case_results.json): ${pcItemStatus}${pc.error ? ' — ' + pc.error : ''}`;
          ul.appendChild(liPc);

          breakdownCard.appendChild(ul);
          alertContainer.appendChild(breakdownCard);
        }
      }
    },

    renderSummaryValue(elementId, value) {
      const el = document.getElementById(elementId);
      if (!el) return;
      el.innerHTML = '';

      if (value !== null && value !== undefined && value !== '') {
        el.textContent = String(value);
        el.classList.remove('text-dim');
      } else {
        const span = document.createElement('span');
        span.className = 'text-dim';
        span.textContent = 'UNAVAILABLE';
        el.appendChild(span);
      }
    },

    renderSummaryDigestValue(elementId, digest, label) {
      const el = document.getElementById(elementId);
      if (!el) return;
      el.innerHTML = '';

      if (digest !== null && digest !== undefined && digest !== '') {
        const fullDigest = String(digest);
        const shortDigest = fullDigest.length > 20 ? fullDigest.substring(0, 18) + '...' : fullDigest;

        const textSpan = document.createElement('span');
        textSpan.textContent = shortDigest;
        textSpan.title = fullDigest;

        const displayLabel = label || elementId;
        const copyBtn = document.createElement('button');
        copyBtn.type = 'button';
        copyBtn.className = 'copy-btn';
        copyBtn.style.marginLeft = '0.4rem';
        copyBtn.style.padding = '0.1rem 0.35rem';
        copyBtn.style.fontSize = '0.65rem';
        copyBtn.textContent = 'Copy';
        copyBtn.setAttribute('aria-label', `Copy ${displayLabel}`);
        copyBtn.setAttribute('title', `Copy ${displayLabel} to clipboard`);
        copyBtn.addEventListener('click', () => this.copyToClipboard(fullDigest, copyBtn));

        el.appendChild(textSpan);
        el.appendChild(copyBtn);
      } else {
        const span = document.createElement('span');
        span.className = 'text-dim';
        span.textContent = 'UNAVAILABLE';
        el.appendChild(span);
      }
    },

    // -------------------------------------------------------------------------
    // Workbench Section 2: Condition Comparisons
    // -------------------------------------------------------------------------
    renderConditionComparisons() {
      const data = this.state.benchmarkData || {};
      const abl = data.ablation_table || {};
      const ablData = abl.available ? abl.data : null;

      // 1. Baseline Performance Visualizations & Table
      const baselines = (ablData && ablData.baselines && typeof ablData.baselines === 'object') ? ablData.baselines : null;

      // Render Baseline Performance Chart (Grouped Bars: Precision, Recall, FPR, FNR)
      this.renderBaselinePerformanceChart(baselines, abl);

      // Render Compute Efficiency Chart (Latency ms vs Tokens)
      this.renderEfficiencyChart(baselines, abl);

      const baselinesTbody = document.getElementById('benchmark-baselines-tbody');
      if (baselinesTbody) {
        baselinesTbody.innerHTML = '';
        if (!baselines || Object.keys(baselines).length === 0) {
          const tr = document.createElement('tr');
          const td = document.createElement('td');
          td.colSpan = 10;
          td.className = 'text-center text-muted';
          td.textContent = abl.error || 'Measured baseline evaluation metrics unavailable in ablation table artifact.';
          tr.appendChild(td);
          baselinesTbody.appendChild(tr);
        } else {
          Object.keys(baselines).forEach(bName => {
            const b = baselines[bName] || {};
            const cm = b.confusion_matrix;
            const ci = b.accuracy_95ci;

            const tr = document.createElement('tr');

            // Name (Row header)
            const tdName = document.createElement('th');
            tdName.setAttribute('scope', 'row');
            tdName.style.fontWeight = '600';
            tdName.style.textAlign = 'left';
            tdName.textContent = bName;

            // Samples
            const tdSamples = document.createElement('td');
            tdSamples.className = 'font-mono text-right';
            tdSamples.textContent = (b.sample_count !== undefined && b.sample_count !== null) ? String(b.sample_count) : 'UNAVAILABLE';

            // Confusion Matrix
            const tdCm = document.createElement('td');
            tdCm.className = 'font-mono text-center';
            if (cm && typeof cm === 'object') {
              const tc = cm.TC !== undefined ? cm.TC : 'N/A';
              const fc = cm.FC !== undefined ? cm.FC : 'N/A';
              const trVal = cm.TR !== undefined ? cm.TR : 'N/A';
              const fr = cm.FR !== undefined ? cm.FR : 'N/A';
              tdCm.textContent = `TC:${tc} FC:${fc} TR:${trVal} FR:${fr}`;
            } else {
              tdCm.textContent = 'UNAVAILABLE';
            }

            // Accuracy (95% CI)
            const tdAcc = document.createElement('td');
            tdAcc.className = 'font-mono text-right';
            if (b.accuracy_pct !== undefined && b.accuracy_pct !== null) {
              let accStr = `${b.accuracy_pct}%`;
              if (Array.isArray(ci) && ci.length >= 2) {
                accStr += ` (${ci[0]}% - ${ci[1]}%)`;
              }
              tdAcc.textContent = accStr;
            } else {
              tdAcc.textContent = 'UNAVAILABLE';
            }

            // Recall
            const tdRecall = document.createElement('td');
            tdRecall.className = 'font-mono text-right';
            tdRecall.textContent = (b.recall_pct !== undefined && b.recall_pct !== null) ? `${b.recall_pct}%` : 'UNAVAILABLE';

            // Precision
            const tdPrec = document.createElement('td');
            tdPrec.className = 'font-mono text-right';
            if (b.precision_pct !== undefined && b.precision_pct !== null && b.precision_pct !== 'N/A') {
              tdPrec.textContent = `${b.precision_pct}%`;
            } else if (b.precision_pct === 'N/A') {
              tdPrec.textContent = 'N/A';
            } else {
              tdPrec.textContent = 'UNAVAILABLE';
            }

            // FPR
            const tdFpr = document.createElement('td');
            tdFpr.className = 'font-mono text-right';
            tdFpr.textContent = (b.false_positive_rate_pct !== undefined && b.false_positive_rate_pct !== null) ? `${b.false_positive_rate_pct}%` : 'UNAVAILABLE';

            // FNR
            const tdFnr = document.createElement('td');
            tdFnr.className = 'font-mono text-right';
            tdFnr.textContent = (b.false_negative_rate_pct !== undefined && b.false_negative_rate_pct !== null) ? `${b.false_negative_rate_pct}%` : 'UNAVAILABLE';

            // Avg Latency
            const tdLat = document.createElement('td');
            tdLat.className = 'font-mono text-right';
            tdLat.textContent = (b.avg_latency_ms !== undefined && b.avg_latency_ms !== null) ? `${b.avg_latency_ms} ms` : 'UNAVAILABLE';

            // Total Tokens Spent
            const tdTok = document.createElement('td');
            tdTok.className = 'font-mono text-right';
            tdTok.textContent = (b.total_tokens_spent !== undefined && b.total_tokens_spent !== null) ? String(b.total_tokens_spent) : 'UNAVAILABLE';

            tr.appendChild(tdName);
            tr.appendChild(tdSamples);
            tr.appendChild(tdCm);
            tr.appendChild(tdAcc);
            tr.appendChild(tdRecall);
            tr.appendChild(tdPrec);
            tr.appendChild(tdFpr);
            tr.appendChild(tdFnr);
            tr.appendChild(tdLat);
            tr.appendChild(tdTok);

            baselinesTbody.appendChild(tr);
          });
        }
      }

      // 2. Paired McNemar Inferential Comparisons
      const mcnemarTbody = document.getElementById('benchmark-mcnemar-tbody');
      if (mcnemarTbody) {
        mcnemarTbody.innerHTML = '';
        const comps = ablData?.paired_mcnemar_comparisons;

        if (!comps || typeof comps !== 'object' || Object.keys(comps).length === 0) {
          const tr = document.createElement('tr');
          const td = document.createElement('td');
          td.colSpan = 6;
          td.className = 'text-center text-muted';
          td.textContent = 'Paired McNemar inferential comparisons unavailable in ablation artifact.';
          tr.appendChild(td);
          mcnemarTbody.appendChild(tr);
        } else {
          Object.keys(comps).forEach(cName => {
            const c = comps[cName] || {};
            const tr = document.createElement('tr');

            const tdName = document.createElement('th');
            tdName.setAttribute('scope', 'row');
            tdName.style.fontWeight = '600';
            tdName.style.fontSize = '0.8rem';
            tdName.style.textAlign = 'left';
            tdName.textContent = cName;

            const tdDiscA = document.createElement('td');
            tdDiscA.className = 'font-mono text-right';
            tdDiscA.textContent = (c.discordant_a_correct_b_incorrect !== undefined && c.discordant_a_correct_b_incorrect !== null) ? String(c.discordant_a_correct_b_incorrect) : 'UNAVAILABLE';

            const tdDiscB = document.createElement('td');
            tdDiscB.className = 'font-mono text-right';
            tdDiscB.textContent = (c.discordant_a_incorrect_b_correct !== undefined && c.discordant_a_incorrect_b_correct !== null) ? String(c.discordant_a_incorrect_b_correct) : 'UNAVAILABLE';

            const tdChi2 = document.createElement('td');
            tdChi2.className = 'font-mono text-right';
            tdChi2.textContent = (c.chi2_statistic !== undefined && c.chi2_statistic !== null) ? String(c.chi2_statistic) : 'UNAVAILABLE';

            const tdPval = document.createElement('td');
            tdPval.className = 'font-mono text-right';
            tdPval.textContent = (c.p_value !== undefined && c.p_value !== null) ? String(c.p_value) : 'UNAVAILABLE';

            const tdSig = document.createElement('td');
            tdSig.style.fontWeight = '600';
            if (c.statistically_significant_alpha_005 === true) {
              tdSig.className = 'text-success';
              tdSig.textContent = 'YES (p < 0.05)';
            } else if (c.statistically_significant_alpha_005 === false) {
              tdSig.className = 'text-muted';
              tdSig.textContent = 'NO';
            } else {
              tdSig.textContent = 'UNAVAILABLE';
            }

            tr.appendChild(tdName);
            tr.appendChild(tdDiscA);
            tr.appendChild(tdDiscB);
            tr.appendChild(tdChi2);
            tr.appendChild(tdPval);
            tr.appendChild(tdSig);

            mcnemarTbody.appendChild(tr);
          });
        }
      }

      // 3. Threshold Sensitivity Analysis
      const ta = (ablData && ablData.threshold_ablations && typeof ablData.threshold_ablations === 'object') ? ablData.threshold_ablations : null;

      // Render Threshold Sensitivity Chart (Precision & Recall curves across Z-thresholds)
      this.renderThresholdSensitivityChart(ta, abl);

      const thresholdsTbody = document.getElementById('benchmark-thresholds-tbody');
      if (thresholdsTbody) {
        thresholdsTbody.innerHTML = '';

        if (!ta || typeof ta !== 'object' || Object.keys(ta).length === 0) {
          const tr = document.createElement('tr');
          const td = document.createElement('td');
          td.colSpan = 7;
          td.className = 'text-center text-muted';
          td.textContent = 'Threshold sensitivity ablations unavailable in ablation artifact.';
          tr.appendChild(td);
          thresholdsTbody.appendChild(tr);
        } else {
          Object.keys(ta).forEach(k => {
            const item = ta[k] || {};
            const tr = document.createElement('tr');

            const tdZ = document.createElement('th');
            tdZ.setAttribute('scope', 'row');
            tdZ.className = 'font-mono';
            tdZ.style.fontWeight = '700';
            tdZ.style.textAlign = 'left';
            tdZ.textContent = (item.z_threshold !== undefined && item.z_threshold !== null) ? `Z = ${item.z_threshold}` : k;

            const tdTc = document.createElement('td');
            tdTc.className = 'font-mono text-right';
            tdTc.textContent = item.TC !== undefined ? String(item.TC) : 'UNAVAILABLE';

            const tdFc = document.createElement('td');
            tdFc.className = 'font-mono text-right';
            tdFc.textContent = item.FC !== undefined ? String(item.FC) : 'UNAVAILABLE';

            const tdTr = document.createElement('td');
            tdTr.className = 'font-mono text-right';
            tdTr.textContent = item.TR !== undefined ? String(item.TR) : 'UNAVAILABLE';

            const tdFr = document.createElement('td');
            tdFr.className = 'font-mono text-right';
            tdFr.textContent = item.FR !== undefined ? String(item.FR) : 'UNAVAILABLE';

            const tdPrec = document.createElement('td');
            tdPrec.className = 'font-mono text-right';
            if (item.precision !== undefined && item.precision !== null && item.precision !== 'N/A') {
              tdPrec.textContent = `${item.precision}%`;
            } else if (item.precision === 'N/A') {
              tdPrec.textContent = 'N/A';
            } else {
              tdPrec.textContent = 'UNAVAILABLE';
            }

            const tdRec = document.createElement('td');
            tdRec.className = 'font-mono text-right';
            tdRec.textContent = (item.recall !== undefined && item.recall !== null) ? `${item.recall}%` : 'UNAVAILABLE';

            tr.appendChild(tdZ);
            tr.appendChild(tdTc);
            tr.appendChild(tdFc);
            tr.appendChild(tdTr);
            tr.appendChild(tdFr);
            tr.appendChild(tdPrec);
            tr.appendChild(tdRec);

            thresholdsTbody.appendChild(tr);
          });
        }
      }
    },

    // -------------------------------------------------------------------------
    // Workbench Visualizations (Accessible Native SVG Charts)
    // -------------------------------------------------------------------------
    renderBaselinePerformanceChart(baselines, ablInfo) {
      const container = document.getElementById('benchmark-baselines-chart-viewport');
      const takeawayElem = document.getElementById('benchmark-baselines-chart-takeaway');
      if (!container) return;
      container.innerHTML = '';

      if (!baselines || typeof baselines !== 'object' || Object.keys(baselines).length === 0) {
        const msg = document.createElement('div');
        msg.className = 'chart-empty-msg';
        msg.textContent = (ablInfo && ablInfo.error) ? ablInfo.error : 'Baseline condition metrics unavailable for visualization.';
        container.appendChild(msg);
        if (takeawayElem) {
          takeawayElem.textContent = 'Baseline condition metrics unavailable for comparative evaluation.';
        }
        return;
      }

      const baselineNames = Object.keys(baselines);
      if (baselineNames.length === 0) {
        const msg = document.createElement('div');
        msg.className = 'chart-empty-msg';
        msg.textContent = 'No baseline conditions found in artifact.';
        container.appendChild(msg);
        if (takeawayElem) {
          takeawayElem.textContent = 'No baseline conditions found in artifact.';
        }
        return;
      }

      // Dynamic takeaway text: inspect valid precision measurements
      if (takeawayElem) {
        const precisionEntries = [];
        baselineNames.forEach(bName => {
          const b = baselines[bName] || {};
          const val = b.precision_pct;
          if (typeof val === 'number' && Number.isFinite(val) && val >= 0 && val <= 100) {
            precisionEntries.push({ name: bName, val });
          }
        });

        if (precisionEntries.length > 0) {
          let maxVal = -1;
          precisionEntries.forEach(e => {
            if (e.val > maxVal) maxVal = e.val;
          });
          const topConditions = precisionEntries.filter(e => Math.abs(e.val - maxVal) < 1e-6);
          const topNames = topConditions.map(e => e.name).join(', ');
          takeawayElem.textContent = `Highest recorded precision in evaluated artifact: ${topNames} (${maxVal}%). Compare false-positive vs false-negative trade-offs in the table below.`;
        } else {
          takeawayElem.textContent = 'Compares diagnostic and security performance across baseline conditions. Visual bars represent recorded percentages (0–100%); refer to the table below for sample counts and exact values.';
        }
      }

      // Metric series to compare: Precision, Recall, FPR, FNR
      const seriesDefs = [
        { key: 'precision_pct', label: 'Precision', color: 'var(--accent-interactive, #B69AFF)', stroke: '#B69AFF', pattern: 'solid' },
        { key: 'recall_pct', label: 'Recall', color: 'var(--accent-primary, #64DED9)', stroke: '#64DED9', pattern: 'dashed' },
        { key: 'false_positive_rate_pct', label: 'FPR', color: 'var(--status-halted-border, #E5B567)', stroke: '#E5B567', pattern: 'dotted' },
        { key: 'false_negative_rate_pct', label: 'FNR', color: 'var(--accent-secondary, #FF83B8)', stroke: '#FF83B8', pattern: 'solid' }
      ];

      // Layout geometry for grouped bar chart
      const svgNS = 'http://www.w3.org/2000/svg';
      const labelWidth = 170;
      const rightPadding = 50;
      const chartWidth = 780;
      const plotWidth = chartWidth - labelWidth - rightPadding;

      const groupPadding = 18;
      const barHeight = 11;
      const barGap = 3;
      const groupHeight = (seriesDefs.length * barHeight) + ((seriesDefs.length - 1) * barGap);
      const topPadding = 30;
      const bottomPadding = 35;
      const chartHeight = topPadding + (baselineNames.length * (groupHeight + groupPadding)) + bottomPadding;

      const svg = document.createElementNS(svgNS, 'svg');
      svg.setAttribute('viewBox', `0 0 ${chartWidth} ${chartHeight}`);
      svg.setAttribute('width', '100%');
      svg.setAttribute('height', 'auto');
      svg.setAttribute('role', 'img');
      svg.setAttribute('aria-hidden', 'true');
      svg.style.fontFamily = 'var(--font-mono, monospace)';

      // Background grid lines (0%, 25%, 50%, 75%, 100%)
      const ticks = [0, 25, 50, 75, 100];
      ticks.forEach(tick => {
        const x = labelWidth + (tick / 100) * plotWidth;

        // Grid line
        const gridLine = document.createElementNS(svgNS, 'line');
        gridLine.setAttribute('x1', String(x));
        gridLine.setAttribute('y1', String(topPadding - 5));
        gridLine.setAttribute('x2', String(x));
        gridLine.setAttribute('y2', String(chartHeight - bottomPadding + 5));
        gridLine.setAttribute('stroke', 'rgba(255, 255, 255, 0.08)');
        gridLine.setAttribute('stroke-dasharray', tick === 0 || tick === 100 ? 'none' : '3,3');
        svg.appendChild(gridLine);

        // Axis label
        const axisText = document.createElementNS(svgNS, 'text');
        axisText.setAttribute('x', String(x));
        axisText.setAttribute('y', String(chartHeight - bottomPadding + 20));
        axisText.setAttribute('text-anchor', 'middle');
        axisText.setAttribute('fill', 'var(--text-muted, #9889B8)');
        axisText.setAttribute('font-size', '10');
        axisText.textContent = `${tick}%`;
        svg.appendChild(axisText);
      });

      // Axis title
      const axisTitle = document.createElementNS(svgNS, 'text');
      axisTitle.setAttribute('x', String(labelWidth + plotWidth / 2));
      axisTitle.setAttribute('y', String(chartHeight - 6));
      axisTitle.setAttribute('text-anchor', 'middle');
      axisTitle.setAttribute('fill', 'var(--text-muted, #9889B8)');
      axisTitle.setAttribute('font-size', '10');
      axisTitle.textContent = 'Measured Rate (%)';
      svg.appendChild(axisTitle);

      // Render baseline groups
      baselineNames.forEach((bName, groupIdx) => {
        const b = baselines[bName] || {};
        const groupY = topPadding + groupIdx * (groupHeight + groupPadding);

        // Baseline name label
        const nameText = document.createElementNS(svgNS, 'text');
        nameText.setAttribute('x', String(labelWidth - 10));
        nameText.setAttribute('y', String(groupY + groupHeight / 2 + 4));
        nameText.setAttribute('text-anchor', 'end');
        nameText.setAttribute('fill', 'var(--text-main, #E2DEED)');
        nameText.setAttribute('font-size', '11');
        nameText.setAttribute('font-weight', '600');
        nameText.textContent = bName.length > 22 ? bName.slice(0, 20) + '…' : bName;
        svg.appendChild(nameText);

        // Render each metric bar in the group
        seriesDefs.forEach((series, sIdx) => {
          const barY = groupY + sIdx * (barHeight + barGap);
          const rawVal = b[series.key];

          const isFiniteNum = typeof rawVal === 'number' && Number.isFinite(rawVal);
          const isValidPct = isFiniteNum && rawVal >= 0 && rawVal <= 100;
          const isNA = rawVal === 'N/A';

          if (isValidPct) {
            // Legitimate percentage in 0-100 range.
            // A genuine 0% renders zero width. No artificial 2px minimum width.
            const barW = (rawVal / 100) * plotWidth;

            if (barW > 0) {
              const rect = document.createElementNS(svgNS, 'rect');
              rect.setAttribute('x', String(labelWidth));
              rect.setAttribute('y', String(barY));
              rect.setAttribute('width', String(barW));
              rect.setAttribute('height', String(barHeight));
              rect.setAttribute('fill', series.color);
              rect.setAttribute('rx', '2');
              rect.setAttribute('data-baseline', bName);
              rect.setAttribute('data-metric', series.key);
              rect.setAttribute('data-value', String(rawVal));
              svg.appendChild(rect);
            }

            // Numerical label next to bar (retained even for genuine 0%)
            const valText = document.createElementNS(svgNS, 'text');
            valText.setAttribute('x', String(labelWidth + barW + 5));
            valText.setAttribute('y', String(barY + barHeight - 2));
            valText.setAttribute('fill', 'var(--text-muted, #9889B8)');
            valText.setAttribute('font-size', '9');
            valText.setAttribute('data-baseline', bName);
            valText.setAttribute('data-metric', series.key);
            valText.setAttribute('data-value', String(rawVal));
            valText.textContent = `${rawVal}%`;
            svg.appendChild(valText);
          } else {
            // Values outside [0, 100], non-finite, null, undefined, or 'N/A':
            // Render NO bar and display explicit indicator. Do not clamp or fabricate 0.
            const statusLabel = isNA ? 'N/A' : (isFiniteNum ? 'INVALID' : 'UNAVAILABLE');
            const missingText = document.createElementNS(svgNS, 'text');
            missingText.setAttribute('x', String(labelWidth + 6));
            missingText.setAttribute('y', String(barY + barHeight - 2));
            missingText.setAttribute('fill', 'var(--text-dim, #685A84)');
            missingText.setAttribute('font-size', '9');
            missingText.setAttribute('font-style', 'italic');
            missingText.setAttribute('data-baseline', bName);
            missingText.setAttribute('data-metric', series.key);
            missingText.setAttribute('data-value', String(rawVal));
            missingText.textContent = statusLabel;
            svg.appendChild(missingText);
          }
        });

        // Group separator line (except last)
        if (groupIdx < baselineNames.length - 1) {
          const sep = document.createElementNS(svgNS, 'line');
          sep.setAttribute('x1', String(labelWidth - 30));
          sep.setAttribute('y1', String(groupY + groupHeight + groupPadding / 2));
          sep.setAttribute('x2', String(chartWidth - 20));
          sep.setAttribute('y2', String(groupY + groupHeight + groupPadding / 2));
          sep.setAttribute('stroke', 'rgba(255, 255, 255, 0.05)');
          svg.appendChild(sep);
        }
      });

      container.appendChild(svg);
    },

    renderThresholdSensitivityChart(thresholdAblations, ablInfo) {
      const container = document.getElementById('benchmark-thresholds-chart-viewport');
      const takeawayElem = document.getElementById('benchmark-thresholds-chart-takeaway');
      if (!container) return;
      container.innerHTML = '';

      if (!thresholdAblations || typeof thresholdAblations !== 'object' || Object.keys(thresholdAblations).length === 0) {
        const msg = document.createElement('div');
        msg.className = 'chart-empty-msg';
        msg.textContent = (ablInfo && ablInfo.error) ? ablInfo.error : 'Threshold sensitivity data unavailable for visualization.';
        container.appendChild(msg);
        if (takeawayElem) {
          takeawayElem.textContent = 'Threshold sensitivity data unavailable for visualization.';
        }
        return;
      }

      // Extract and validate threshold items
      const items = [];
      Object.keys(thresholdAblations).forEach(k => {
        const obj = thresholdAblations[k] || {};
        let zVal = null;

        // If explicit 'z_threshold' property exists in the object
        if (Object.prototype.hasOwnProperty.call(obj, 'z_threshold') && obj.z_threshold !== undefined && obj.z_threshold !== null) {
          const rawZ = obj.z_threshold;
          if (typeof rawZ === 'number' && Number.isFinite(rawZ)) {
            zVal = rawZ;
          } else if (typeof rawZ === 'string' && rawZ.trim() !== '' && !Number.isNaN(Number(rawZ.trim()))) {
            zVal = Number(rawZ.trim());
          } else {
            // Explicit but invalid z_threshold; do NOT infer from malformed key!
            return;
          }
        } else {
          // No explicit z_threshold; carefully inspect key for integer, decimal, or negative number
          const trimmedKey = k.trim();
          const match = trimmedKey.match(/[-+]?\d+(?:\.\d+)?/);
          if (match) {
            const parsed = parseFloat(match[0]);
            if (Number.isFinite(parsed)) {
              zVal = parsed;
            }
          }
        }

        if (zVal === null || !Number.isFinite(zVal)) {
          return;
        }

        // Validate precision: must be finite number in [0, 100]
        let prec = null;
        if (typeof obj.precision === 'number' && Number.isFinite(obj.precision) && obj.precision >= 0 && obj.precision <= 100) {
          prec = obj.precision;
        }

        // Validate recall: must be finite number in [0, 100]
        let rec = null;
        if (typeof obj.recall === 'number' && Number.isFinite(obj.recall) && obj.recall >= 0 && obj.recall <= 100) {
          rec = obj.recall;
        }

        items.push({
          key: k,
          z: zVal,
          precision: prec,
          recall: rec,
          rawPrecision: obj.precision,
          rawRecall: obj.recall
        });
      });

      // Strict numerical ascending sort
      items.sort((a, b) => a.z - b.z);

      if (items.length === 0) {
        const msg = document.createElement('div');
        msg.className = 'chart-empty-msg';
        msg.textContent = 'No valid numerical threshold observations recorded.';
        container.appendChild(msg);
        if (takeawayElem) {
          takeawayElem.textContent = 'No valid numerical threshold observations recorded.';
        }
        return;
      }

      // Dynamic takeaway text
      if (takeawayElem) {
        const minZ = items[0].z;
        const maxZ = items[items.length - 1].z;
        const precCount = items.filter(it => it.precision !== null).length;
        const recCount = items.filter(it => it.recall !== null).length;

        if (items.length === 1) {
          takeawayElem.textContent = `Single threshold observation recorded at Z=${minZ}. Multiple threshold observations are required to characterize sensitivity curves.`;
        } else if (precCount === 0 && recCount === 0) {
          takeawayElem.textContent = `Recorded thresholds range from Z=${minZ} to Z=${maxZ}; precision and recall metrics are unavailable in the artifact.`;
        } else {
          takeawayElem.textContent = `Sensitivity evaluated across Z-thresholds from ${minZ} to ${maxZ} (${items.length} observations). Discontinuous segments reflect missing observations.`;
        }
      }

      const svgNS = 'http://www.w3.org/2000/svg';
      const chartWidth = 460;
      const chartHeight = 220;
      const padLeft = 45;
      const padRight = 30;
      const padTop = 20;
      const padBottom = 40;

      const plotWidth = chartWidth - padLeft - padRight;
      const plotHeight = chartHeight - padTop - padBottom;

      const svg = document.createElementNS(svgNS, 'svg');
      svg.setAttribute('viewBox', `0 0 ${chartWidth} ${chartHeight}`);
      svg.setAttribute('width', '100%');
      svg.setAttribute('height', 'auto');
      svg.setAttribute('role', 'img');
      svg.setAttribute('aria-hidden', 'true');
      svg.style.fontFamily = 'var(--font-mono, monospace)';

      // Y-axis grid lines (0%, 25%, 50%, 75%, 100%)
      const yTicks = [0, 25, 50, 75, 100];
      yTicks.forEach(tick => {
        const y = padTop + plotHeight - (tick / 100) * plotHeight;

        const gridLine = document.createElementNS(svgNS, 'line');
        gridLine.setAttribute('x1', String(padLeft));
        gridLine.setAttribute('y1', String(y));
        gridLine.setAttribute('x2', String(chartWidth - padRight));
        gridLine.setAttribute('y2', String(y));
        gridLine.setAttribute('stroke', 'rgba(255, 255, 255, 0.08)');
        gridLine.setAttribute('stroke-dasharray', tick === 0 || tick === 100 ? 'none' : '3,3');
        svg.appendChild(gridLine);

        const text = document.createElementNS(svgNS, 'text');
        text.setAttribute('x', String(padLeft - 6));
        text.setAttribute('y', String(y + 3));
        text.setAttribute('text-anchor', 'end');
        text.setAttribute('fill', 'var(--text-muted, #9889B8)');
        text.setAttribute('font-size', '9');
        text.textContent = `${tick}%`;
        svg.appendChild(text);
      });

      // Horizontal coordinate calculation: linearly proportional to actual numerical z_threshold
      const minZ = items[0].z;
      const maxZ = items[items.length - 1].z;
      const zRange = maxZ - minZ;

      const getX = (z) => {
        if (zRange === 0 || items.length === 1) {
          return padLeft + plotWidth / 2;
        }
        return padLeft + ((z - minZ) / zRange) * plotWidth;
      };

      // X-axis ticks and labels at actual threshold locations
      items.forEach(item => {
        const x = getX(item.z);

        const tickLine = document.createElementNS(svgNS, 'line');
        tickLine.setAttribute('x1', String(x));
        tickLine.setAttribute('y1', String(padTop + plotHeight));
        tickLine.setAttribute('x2', String(x));
        tickLine.setAttribute('y2', String(padTop + plotHeight + 4));
        tickLine.setAttribute('stroke', 'var(--border-default, #44365F)');
        svg.appendChild(tickLine);

        const label = document.createElementNS(svgNS, 'text');
        label.setAttribute('x', String(x));
        label.setAttribute('y', String(padTop + plotHeight + 16));
        label.setAttribute('text-anchor', 'middle');
        label.setAttribute('fill', 'var(--text-main, #E2DEED)');
        label.setAttribute('font-size', '10');
        label.textContent = `Z=${item.z}`;
        svg.appendChild(label);
      });

      // Axis Titles
      const xTitle = document.createElementNS(svgNS, 'text');
      xTitle.setAttribute('x', String(padLeft + plotWidth / 2));
      xTitle.setAttribute('y', String(chartHeight - 6));
      xTitle.setAttribute('text-anchor', 'middle');
      xTitle.setAttribute('fill', 'var(--text-muted, #9889B8)');
      xTitle.setAttribute('font-size', '9');
      xTitle.textContent = 'Ablation Threshold (Z)';
      svg.appendChild(xTitle);

      // Build contiguous segments for Precision: missing observations must break lines!
      const precSegments = [];
      let currentPrecSeg = [];

      items.forEach(item => {
        if (item.precision !== null) {
          const x = getX(item.z);
          const y = padTop + plotHeight - (item.precision / 100) * plotHeight;
          currentPrecSeg.push({ x, y, val: item.precision, z: item.z });
        } else {
          if (currentPrecSeg.length > 0) {
            precSegments.push(currentPrecSeg);
            currentPrecSeg = [];
          }
        }
      });
      if (currentPrecSeg.length > 0) {
        precSegments.push(currentPrecSeg);
      }

      // Build contiguous segments for Recall: missing observations must break lines!
      const recSegments = [];
      let currentRecSeg = [];

      items.forEach(item => {
        if (item.recall !== null) {
          const x = getX(item.z);
          const y = padTop + plotHeight - (item.recall / 100) * plotHeight;
          currentRecSeg.push({ x, y, val: item.recall, z: item.z });
        } else {
          if (currentRecSeg.length > 0) {
            recSegments.push(currentRecSeg);
            currentRecSeg = [];
          }
        }
      });
      if (currentRecSeg.length > 0) {
        recSegments.push(currentRecSeg);
      }

      // Render Precision polylines for each contiguous segment
      precSegments.forEach(seg => {
        if (seg.length > 1) {
          const path = document.createElementNS(svgNS, 'polyline');
          path.setAttribute('points', seg.map(p => `${p.x},${p.y}`).join(' '));
          path.setAttribute('fill', 'none');
          path.setAttribute('stroke', 'var(--accent-interactive, #B69AFF)');
          path.setAttribute('stroke-width', '2');
          path.setAttribute('data-series', 'precision');
          svg.appendChild(path);
        }
      });

      // Render Recall polylines for each contiguous segment
      recSegments.forEach(seg => {
        if (seg.length > 1) {
          const path = document.createElementNS(svgNS, 'polyline');
          path.setAttribute('points', seg.map(p => `${p.x},${p.y}`).join(' '));
          path.setAttribute('fill', 'none');
          path.setAttribute('stroke', 'var(--accent-primary, #64DED9)');
          path.setAttribute('stroke-width', '2');
          path.setAttribute('stroke-dasharray', '5,3');
          path.setAttribute('data-series', 'recall');
          svg.appendChild(path);
        }
      });

      // Render Precision Markers (Circles) for all valid precision points
      precSegments.forEach(seg => {
        seg.forEach(p => {
          const circle = document.createElementNS(svgNS, 'circle');
          circle.setAttribute('cx', String(p.x));
          circle.setAttribute('cy', String(p.y));
          circle.setAttribute('r', '4');
          circle.setAttribute('fill', 'var(--accent-interactive, #B69AFF)');
          circle.setAttribute('stroke', 'var(--bg-card, #1D1833)');
          circle.setAttribute('stroke-width', '1.5');
          circle.setAttribute('data-threshold', String(p.z));
          circle.setAttribute('data-series', 'precision');
          circle.setAttribute('data-value', String(p.val));
          svg.appendChild(circle);

          const valText = document.createElementNS(svgNS, 'text');
          valText.setAttribute('x', String(p.x));
          valText.setAttribute('y', String(p.y - 7));
          valText.setAttribute('text-anchor', 'middle');
          valText.setAttribute('fill', 'var(--accent-interactive, #B69AFF)');
          valText.setAttribute('font-size', '8.5');
          valText.setAttribute('data-threshold', String(p.z));
          valText.setAttribute('data-series', 'precision');
          valText.setAttribute('data-value', String(p.val));
          valText.textContent = `${p.val}%`;
          svg.appendChild(valText);
        });
      });

      // Render Recall Markers (Squares) for all valid recall points
      recSegments.forEach(seg => {
        seg.forEach(p => {
          const rect = document.createElementNS(svgNS, 'rect');
          rect.setAttribute('x', String(p.x - 3.5));
          rect.setAttribute('y', String(p.y - 3.5));
          rect.setAttribute('width', '7');
          rect.setAttribute('height', '7');
          rect.setAttribute('fill', 'var(--accent-primary, #64DED9)');
          rect.setAttribute('stroke', 'var(--bg-card, #1D1833)');
          rect.setAttribute('stroke-width', '1.5');
          rect.setAttribute('data-threshold', String(p.z));
          rect.setAttribute('data-series', 'recall');
          rect.setAttribute('data-value', String(p.val));
          svg.appendChild(rect);

          const valText = document.createElementNS(svgNS, 'text');
          valText.setAttribute('x', String(p.x));
          valText.setAttribute('y', String(p.y + 14));
          valText.setAttribute('text-anchor', 'middle');
          valText.setAttribute('fill', 'var(--accent-primary, #64DED9)');
          valText.setAttribute('font-size', '8.5');
          valText.setAttribute('data-threshold', String(p.z));
          valText.setAttribute('data-series', 'recall');
          valText.setAttribute('data-value', String(p.val));
          valText.textContent = `${p.val}%`;
          svg.appendChild(valText);
        });
      });

      container.appendChild(svg);
    },

    renderEfficiencyChart(baselines, ablInfo) {
      const container = document.getElementById('benchmark-efficiency-chart-viewport');
      const takeawayElem = document.getElementById('benchmark-efficiency-chart-takeaway');
      if (!container) return;
      container.innerHTML = '';

      if (!baselines || typeof baselines !== 'object' || Object.keys(baselines).length === 0) {
        const msg = document.createElement('div');
        msg.className = 'chart-empty-msg';
        msg.textContent = (ablInfo && ablInfo.error) ? ablInfo.error : 'Efficiency metrics unavailable for visualization.';
        container.appendChild(msg);
        if (takeawayElem) {
          takeawayElem.textContent = 'Efficiency metrics unavailable for visualization.';
        }
        return;
      }

      // Collect points with valid, finite latency and token counts (>= 0)
      const points = [];
      let maxLatency = 0;
      let maxTokens = 0;

      Object.keys(baselines).forEach(bName => {
        const b = baselines[bName] || {};
        const lat = b.avg_latency_ms;
        const tok = b.total_tokens_spent;

        const latValid = typeof lat === 'number' && Number.isFinite(lat) && lat >= 0;
        const tokValid = typeof tok === 'number' && Number.isFinite(tok) && tok >= 0;

        if (latValid && tokValid) {
          points.push({ name: bName, latency: lat, tokens: tok });
          if (lat > maxLatency) maxLatency = lat;
          if (tok > maxTokens) maxTokens = tok;
        }
      });

      if (points.length === 0) {
        const msg = document.createElement('div');
        msg.className = 'chart-empty-msg';
        msg.textContent = 'No baseline condition contains both valid latency and token metrics.';
        container.appendChild(msg);
        if (takeawayElem) {
          takeawayElem.textContent = 'No baseline condition contains both valid latency and token metrics.';
        }
        return;
      }

      // Dynamic takeaway: identify baseline with lowest measured latency among valid ones
      if (takeawayElem) {
        let minLat = Infinity;
        points.forEach(pt => {
          if (pt.latency < minLat) minLat = pt.latency;
        });
        const fastestBaselines = points.filter(pt => Math.abs(pt.latency - minLat) < 1e-6);
        const fastestNames = fastestBaselines.map(pt => pt.name).join(', ');
        takeawayElem.textContent = `Lowest measured latency: ${fastestNames} (${minLat} ms, ${fastestBaselines[0].tokens} tokens). Visualizes latency against token consumption across conditions.`;
      }

      // Establish sensible chart domains with padding
      const maxLatDomain = maxLatency > 0 ? maxLatency * 1.25 : 10;
      const maxTokDomain = maxTokens > 0 ? maxTokens * 1.2 : 1000;

      const svgNS = 'http://www.w3.org/2000/svg';
      const chartWidth = 780;
      const chartHeight = 260;
      const padLeft = 70;
      const padRight = 140; // Room for baseline label callouts
      const padTop = 25;
      const padBottom = 45;

      const plotWidth = chartWidth - padLeft - padRight;
      const plotHeight = chartHeight - padTop - padBottom;

      const svg = document.createElementNS(svgNS, 'svg');
      svg.setAttribute('viewBox', `0 0 ${chartWidth} ${chartHeight}`);
      svg.setAttribute('width', '100%');
      svg.setAttribute('height', 'auto');
      svg.setAttribute('role', 'img');
      svg.setAttribute('aria-hidden', 'true');
      svg.style.fontFamily = 'var(--font-mono, monospace)';

      // X-axis: Total Tokens Spent
      const numXTicks = 4;
      for (let i = 0; i <= numXTicks; i++) {
        const val = Math.round((i / numXTicks) * maxTokDomain);
        const x = padLeft + (i / numXTicks) * plotWidth;

        const gridLine = document.createElementNS(svgNS, 'line');
        gridLine.setAttribute('x1', String(x));
        gridLine.setAttribute('y1', String(padTop));
        gridLine.setAttribute('x2', String(x));
        gridLine.setAttribute('y2', String(padTop + plotHeight));
        gridLine.setAttribute('stroke', 'rgba(255, 255, 255, 0.08)');
        gridLine.setAttribute('stroke-dasharray', i === 0 ? 'none' : '3,3');
        svg.appendChild(gridLine);

        const text = document.createElementNS(svgNS, 'text');
        text.setAttribute('x', String(x));
        text.setAttribute('y', String(padTop + plotHeight + 16));
        text.setAttribute('text-anchor', 'middle');
        text.setAttribute('fill', 'var(--text-muted, #9889B8)');
        text.setAttribute('font-size', '9');
        text.textContent = String(val);
        svg.appendChild(text);
      }

      // X-axis Title
      const xTitle = document.createElementNS(svgNS, 'text');
      xTitle.setAttribute('x', String(padLeft + plotWidth / 2));
      xTitle.setAttribute('y', String(chartHeight - 6));
      xTitle.setAttribute('text-anchor', 'middle');
      xTitle.setAttribute('fill', 'var(--text-muted, #9889B8)');
      xTitle.setAttribute('font-size', '10');
      xTitle.textContent = 'Total Tokens Consumed (Tokens)';
      svg.appendChild(xTitle);

      // Y-axis: Average Latency (ms)
      const numYTicks = 4;
      for (let i = 0; i <= numYTicks; i++) {
        const val = ((i / numYTicks) * maxLatDomain).toFixed(1);
        const y = padTop + plotHeight - (i / numYTicks) * plotHeight;

        const gridLine = document.createElementNS(svgNS, 'line');
        gridLine.setAttribute('x1', String(padLeft));
        gridLine.setAttribute('y1', String(y));
        gridLine.setAttribute('x2', String(padLeft + plotWidth));
        gridLine.setAttribute('y2', String(y));
        gridLine.setAttribute('stroke', 'rgba(255, 255, 255, 0.08)');
        gridLine.setAttribute('stroke-dasharray', i === 0 ? 'none' : '3,3');
        svg.appendChild(gridLine);

        const text = document.createElementNS(svgNS, 'text');
        text.setAttribute('x', String(padLeft - 8));
        text.setAttribute('y', String(y + 3));
        text.setAttribute('text-anchor', 'end');
        text.setAttribute('fill', 'var(--text-muted, #9889B8)');
        text.setAttribute('font-size', '9');
        text.textContent = `${val} ms`;
        svg.appendChild(text);
      }

      // Y-axis Title
      const yTitle = document.createElementNS(svgNS, 'text');
      yTitle.setAttribute('transform', `rotate(-90 18 ${padTop + plotHeight / 2})`);
      yTitle.setAttribute('x', '18');
      yTitle.setAttribute('y', String(padTop + plotHeight / 2));
      yTitle.setAttribute('text-anchor', 'middle');
      yTitle.setAttribute('fill', 'var(--text-muted, #9889B8)');
      yTitle.setAttribute('font-size', '10');
      yTitle.textContent = 'Avg Latency (ms)';
      svg.appendChild(yTitle);

      // Plot Points & Labels
      points.forEach((pt, pIdx) => {
        const cx = padLeft + (pt.tokens / maxTokDomain) * plotWidth;
        const cy = padTop + plotHeight - (pt.latency / maxLatDomain) * plotHeight;

        // Data point marker
        const circle = document.createElementNS(svgNS, 'circle');
        circle.setAttribute('cx', String(cx));
        circle.setAttribute('cy', String(cy));
        circle.setAttribute('r', '5');
        circle.setAttribute('fill', 'var(--accent-primary, #64DED9)');
        circle.setAttribute('stroke', 'var(--bg-main, #120F24)');
        circle.setAttribute('stroke-width', '1.5');
        circle.setAttribute('data-baseline', pt.name);
        circle.setAttribute('data-latency', String(pt.latency));
        circle.setAttribute('data-tokens', String(pt.tokens));
        svg.appendChild(circle);

        // Data point callout text with anti-collision offsets
        const label = document.createElementNS(svgNS, 'text');
        const placeLeft = (pIdx % 2 === 1) || (cx > padLeft + plotWidth * 0.75);
        const lx = placeLeft ? cx - 8 : cx + 8;
        const yOffsets = [-8, 14, -18, 22];
        const ly = cy + yOffsets[pIdx % yOffsets.length];

        label.setAttribute('x', String(lx));
        label.setAttribute('y', String(ly));
        label.setAttribute('text-anchor', placeLeft ? 'end' : 'start');
        label.setAttribute('fill', 'var(--text-main, #E2DEED)');
        label.setAttribute('font-size', '9');
        label.setAttribute('font-weight', '500');
        label.setAttribute('data-baseline', pt.name);
        label.setAttribute('data-latency', String(pt.latency));
        label.setAttribute('data-tokens', String(pt.tokens));
        label.textContent = `${pt.name} (${pt.latency}ms, ${pt.tokens} tok)`;
        svg.appendChild(label);
      });

      container.appendChild(svg);
    },

    // -------------------------------------------------------------------------
    // Workbench Section 3: Per-Case Evaluation Inspector
    // -------------------------------------------------------------------------
    renderBenchmarkCasesList() {
      const listUl = document.getElementById('benchmark-case-list');
      if (!listUl) return;
      const areaCaseList = document.getElementById('area-benchmark-case-list');
      listUl.innerHTML = '';

      const data = this.state.benchmarkData || {};
      const pc = data.per_case_results || {};
      const caseList = (pc.available && Array.isArray(pc.data)) ? pc.data : [];

      if (!pc.available || caseList.length === 0) {
        const emptyLi = document.createElement('li');
        emptyLi.className = 'text-muted text-center';
        emptyLi.setAttribute('role', 'option');
        emptyLi.setAttribute('aria-selected', 'false');
        emptyLi.style.padding = '1.5rem 1rem';
        emptyLi.textContent = pc.error || 'No per-case evaluation results available.';
        listUl.appendChild(emptyLi);

        const countBadge = document.getElementById('benchmark-case-count');
        if (countBadge) countBadge.textContent = '0';
        return;
      }

      let filtered = caseList.filter(c => {
        if (!c) return false;

        // Baseline Filter
        if (this.state.caseBaselineFilter !== 'ALL' && c.baseline !== this.state.caseBaselineFilter) {
          return false;
        }

        // Scenario Family Filter
        if (this.state.caseFamilyFilter !== 'ALL') {
          const fam = c.scenario_family || c.family || c.category;
          if (fam !== this.state.caseFamilyFilter) {
            return false;
          }
        }

        // Outcome Filter
        if (this.state.caseOutcomeFilter !== 'ALL') {
          const targetFilter = this.state.caseOutcomeFilter.toUpperCase();
          const classification = (c.classification || '').toUpperCase();
          const actualOutcome = (c.actual_outcome || '').toUpperCase();
          const status = (c.status || c.outcome || '').toUpperCase();

          if (classification !== targetFilter && actualOutcome !== targetFilter && status !== targetFilter) {
            return false;
          }
        }

        // Search Filter
        if (this.state.caseSearchQuery) {
          const q = this.state.caseSearchQuery;
          const caseId = (c.case_id || '').toLowerCase();
          const family = (c.scenario_family || c.family || c.category || '').toLowerCase();
          const reason = (c.decision_reason || c.reason || '').toLowerCase();
          const baseline = (c.baseline || '').toLowerCase();
          const actual = (c.actual_outcome || c.status || '').toLowerCase();
          const expected = (c.expected_outcome || '').toLowerCase();

          return caseId.includes(q) || family.includes(q) || reason.includes(q) || baseline.includes(q) || actual.includes(q) || expected.includes(q);
        }

        return true;
      });

      const countBadge = document.getElementById('benchmark-case-count');
      if (countBadge) {
        const total = caseList.length;
        const visible = filtered.length;
        countBadge.textContent = total === visible ? `${total}` : `${visible} of ${total}`;
        countBadge.setAttribute('aria-label', total === visible ? `${total} cases` : `${visible} of ${total} cases shown`);
      }

      // Clean up any previously attached clear-action bar
      const existingCaseClear = areaCaseList?.querySelector('.stream-clear-action-bar');
      if (existingCaseClear) existingCaseClear.remove();

      if (filtered.length === 0) {
        const emptyLi = document.createElement('li');
        emptyLi.className = 'text-muted text-center';
        emptyLi.setAttribute('role', 'option');
        emptyLi.setAttribute('aria-selected', 'false');
        emptyLi.style.padding = '1.5rem 1rem';

        const hasFilters = this.state.caseSearchQuery || this.state.caseBaselineFilter !== 'ALL' || this.state.caseFamilyFilter !== 'ALL' || this.state.caseOutcomeFilter !== 'ALL';
        if (hasFilters) {
          emptyLi.textContent = 'No benchmark cases match active search query or filter.';

          const clearBar = document.createElement('div');
          clearBar.className = 'stream-clear-action-bar text-center';
          clearBar.style.padding = '0.5rem 1rem 1rem';

          const clearBtn = document.createElement('button');
          clearBtn.type = 'button';
          clearBtn.className = 'btn-refresh';
          clearBtn.textContent = 'Clear Case Filters';
          clearBtn.setAttribute('aria-label', 'Clear case search query and filters');
          clearBtn.setAttribute('title', 'Clear active case search query and filters');
          clearBtn.addEventListener('click', () => {
            this.state.caseSearchQuery = '';
            this.state.caseBaselineFilter = 'ALL';
            this.state.caseFamilyFilter = 'ALL';
            this.state.caseOutcomeFilter = 'ALL';
            const searchInput = document.getElementById('benchmark-case-search');
            if (searchInput) {
              searchInput.value = '';
              searchInput.focus();
            }
            const baseSelect = document.getElementById('benchmark-case-baseline-filter');
            if (baseSelect) baseSelect.value = 'ALL';
            const famSelect = document.getElementById('benchmark-case-family-filter');
            if (famSelect) famSelect.value = 'ALL';
            const outcomeSelect = document.getElementById('benchmark-case-outcome-filter');
            if (outcomeSelect) outcomeSelect.value = 'ALL';
            this.announce('Benchmark case filters cleared. Showing all cases.');
            this.renderBenchmarkCasesList();
          });

          clearBar.appendChild(clearBtn);
          areaCaseList?.appendChild(clearBar);
        } else {
          emptyLi.textContent = 'No recorded benchmark case instances in artifact.';
        }

        listUl.appendChild(emptyLi);
        return;
      }

      filtered.forEach((c, index) => {
        const isSelected = this.state.selectedCaseIndex === index;

        const li = document.createElement('li');
        li.className = `trace-item ${isSelected ? 'active' : ''}`;
        li.setAttribute('role', 'option');
        li.setAttribute('tabindex', '0');
        li.setAttribute('aria-selected', isSelected ? 'true' : 'false');
        li.setAttribute('aria-label', `Benchmark case ${c.case_id || 'unnamed'}, classification ${c.classification || c.actual_outcome || 'unknown'}`);

        li.addEventListener('click', () => this.selectBenchmarkCase(c, index));
        li.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.selectBenchmarkCase(c, index);
          } else if (e.key === 'ArrowDown') {
            e.preventDefault();
            const items = listUl.querySelectorAll('.trace-item');
            if (index + 1 < items.length) items[index + 1].focus();
          } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            const items = listUl.querySelectorAll('.trace-item');
            if (index - 1 >= 0) items[index - 1].focus();
          } else if (e.key === 'Home') {
            e.preventDefault();
            const items = listUl.querySelectorAll('.trace-item');
            if (items.length > 0) items[0].focus();
          } else if (e.key === 'End') {
            e.preventDefault();
            const items = listUl.querySelectorAll('.trace-item');
            if (items.length > 0) items[items.length - 1].focus();
          }
        });

        const headerDiv = document.createElement('div');
        headerDiv.className = 'trace-item-header';

        const idSpan = document.createElement('span');
        idSpan.className = 'font-mono';
        idSpan.style.fontWeight = '700';
        idSpan.style.fontSize = '0.8rem';
        idSpan.style.color = 'var(--accent-primary)';
        idSpan.textContent = c.case_id || 'UNNAMED_CASE';

        const badgeSpan = document.createElement('span');
        const classification = (c.classification || c.actual_outcome || 'N/A').toUpperCase();
        if (classification === 'TC') {
          badgeSpan.className = 'status-badge status-badge-verified';
          badgeSpan.textContent = 'TC';
        } else if (classification === 'TR') {
          badgeSpan.className = 'status-badge status-badge-halted';
          badgeSpan.textContent = 'TR';
        } else if (classification === 'FC' || classification === 'FR') {
          badgeSpan.className = 'status-badge status-badge-failed';
          badgeSpan.textContent = classification;
        } else {
          badgeSpan.className = 'status-badge status-badge-unknown';
          badgeSpan.textContent = classification;
        }

        headerDiv.appendChild(idSpan);
        headerDiv.appendChild(badgeSpan);

        const subDiv = document.createElement('div');
        subDiv.className = 'text-muted';
        subDiv.style.fontSize = '0.75rem';
        subDiv.style.marginTop = '0.2rem';
        subDiv.textContent = `${c.baseline || 'Default Baseline'} • ${c.scenario_family || c.family || c.category || 'Unclassified'}`;

        const metaDiv = document.createElement('div');
        metaDiv.className = 'font-mono text-dim';
        metaDiv.style.fontSize = '0.7rem';
        metaDiv.style.marginTop = '0.15rem';

        const latStr = (c.latency_ms !== undefined && c.latency_ms !== null) ? `${c.latency_ms} ms` : 'Latency unavailable';
        const tokStr = (c.tokens_consumed !== undefined && c.tokens_consumed !== null) ? `${c.tokens_consumed} tokens` : 'Tokens unavailable';
        metaDiv.textContent = `${latStr} • ${tokStr}`;

        li.appendChild(headerDiv);
        li.appendChild(subDiv);
        li.appendChild(metaDiv);
        listUl.appendChild(li);
      });
    },

    selectBenchmarkCase(caseRecord, index) {
      this.state.selectedCaseIndex = index;
      if (caseRecord && caseRecord.case_id) {
        this.announce(`Selected benchmark case ${caseRecord.case_id}`);
      }
      this.renderBenchmarkCasesList();

      const emptyDiv = document.getElementById('benchmark-case-empty');
      const contentDiv = document.getElementById('benchmark-case-content');

      if (!caseRecord) {
        if (emptyDiv) emptyDiv.classList.remove('hidden');
        if (contentDiv) contentDiv.classList.add('hidden');
        return;
      }

      if (emptyDiv) emptyDiv.classList.add('hidden');
      if (contentDiv) {
        contentDiv.classList.remove('hidden');
        this.renderCaseDetailInspector(caseRecord, contentDiv);
      }
    },

    renderCaseDetailInspector(c, container) {
      container.innerHTML = '';

      // Header Bar with Copy buttons
      const headerBar = document.createElement('div');
      headerBar.style.display = 'flex';
      headerBar.style.justifyContent = 'space-between';
      headerBar.style.alignItems = 'center';
      headerBar.style.marginBottom = '1rem';
      headerBar.style.flexWrap = 'wrap';
      headerBar.style.gap = '0.5rem';

      const titleGroup = document.createElement('div');
      const title = document.createElement('h3');
      title.style.fontSize = '1.05rem';
      title.style.fontWeight = '700';
      title.style.margin = '0';
      title.className = 'font-mono';
      title.textContent = `Case: ${c.case_id || 'UNNAMED_CASE'}`;
      titleGroup.appendChild(title);

      const actionBtnGroup = document.createElement('div');
      actionBtnGroup.style.display = 'flex';
      actionBtnGroup.style.gap = '0.5rem';

      const copyIdBtn = document.createElement('button');
      copyIdBtn.type = 'button';
      copyIdBtn.className = 'copy-btn';
      copyIdBtn.textContent = 'Copy Case ID';
      copyIdBtn.setAttribute('aria-label', `Copy Case ID ${c.case_id}`);
      copyIdBtn.setAttribute('title', `Copy Case ID ${c.case_id} to clipboard`);
      copyIdBtn.addEventListener('click', () => this.copyToClipboard(c.case_id, copyIdBtn));
      actionBtnGroup.appendChild(copyIdBtn);

      const copyJsonBtn = document.createElement('button');
      copyJsonBtn.type = 'button';
      copyJsonBtn.className = 'copy-btn';
      copyJsonBtn.textContent = 'Copy Record JSON';
      copyJsonBtn.setAttribute('aria-label', `Copy full JSON payload for case ${c.case_id}`);
      copyJsonBtn.setAttribute('title', `Copy JSON payload for case ${c.case_id}`);
      copyJsonBtn.addEventListener('click', () => this.copyToClipboard(JSON.stringify(c, null, 2), copyJsonBtn));
      actionBtnGroup.appendChild(copyJsonBtn);

      headerBar.appendChild(titleGroup);
      headerBar.appendChild(actionBtnGroup);
      container.appendChild(headerBar);

      // Card 1: Structured Case Metadata Breakdown
      const metaCard = document.createElement('div');
      metaCard.className = 'card mb-1';

      const metaHeader = document.createElement('div');
      metaHeader.className = 'card-header';
      metaHeader.textContent = 'Recorded Case Outcomes & Telemetry';
      metaCard.appendChild(metaHeader);

      const fieldList = [
        { label: 'Case Identifier', value: c.case_id, mono: true, copyable: true },
        { label: 'Baseline Condition', value: c.baseline, bold: true },
        { label: 'Scenario Family', value: c.scenario_family || c.family || c.category },
        { label: 'Expected Outcome', value: c.expected_outcome, mono: true },
        { label: 'Actual Outcome', value: c.actual_outcome || c.status || c.outcome, mono: true, bold: true },
        { label: 'Classification Label', value: c.classification, bold: true },
        { label: 'Decision Reason / Details', value: c.decision_reason || c.reason || c.gate_action },
        { label: 'Observed Latency', value: (c.latency_ms !== undefined && c.latency_ms !== null) ? `${c.latency_ms} ms` : null, mono: true },
        { label: 'Tokens Consumed', value: (c.tokens_consumed !== undefined && c.tokens_consumed !== null) ? `${c.tokens_consumed} tokens` : null, mono: true },
        { label: 'Run Identifier', value: c.run_id, mono: true, copyable: true },
        { label: 'Dataset SHA-256 Digest', value: c.dataset_sha256_digest, mono: true, copyable: true }
      ];

      fieldList.forEach(item => {
        const row = document.createElement('div');
        row.style.marginBottom = '0.4rem';
        row.style.fontSize = '0.8rem';
        row.style.wordBreak = 'break-all';

        const lbl = document.createElement('span');
        lbl.style.color = 'var(--text-secondary)';
        lbl.style.fontWeight = '600';
        lbl.textContent = `${item.label}: `;
        row.appendChild(lbl);

        const valSpan = document.createElement('span');
        if (item.value !== null && item.value !== undefined && item.value !== '') {
          valSpan.textContent = String(item.value);
          if (item.mono) valSpan.className = 'font-mono';
          if (item.bold) valSpan.style.fontWeight = '700';
          row.appendChild(valSpan);

          if (item.copyable) {
            const btn = document.createElement('button');
              btn.type = 'button';
            btn.className = 'copy-btn';
            btn.style.marginLeft = '0.4rem';
            btn.style.padding = '0.1rem 0.35rem';
            btn.style.fontSize = '0.65rem';
            btn.textContent = 'Copy';
            btn.setAttribute('aria-label', `Copy ${item.label}`);
              btn.setAttribute('title', `Copy ${item.label} to clipboard`);
            btn.addEventListener('click', () => this.copyToClipboard(String(item.value), btn));
            row.appendChild(btn);
          }
        } else {
          valSpan.className = 'text-dim';
          valSpan.textContent = 'UNAVAILABLE / NOT RECORDED';
          row.appendChild(valSpan);
        }

        metaCard.appendChild(row);
      });

      container.appendChild(metaCard);

      // Epistemic Notice Callout Box
      const epistemicBox = document.createElement('div');
      epistemicBox.className = 'epistemic-disclaimer-box mb-1';
      epistemicBox.textContent = 'EPISTEMIC NOTICE: Individual outcome classification labels (TC/FC/TR/FR) reflect automated harness comparison against expected target outcomes. Recorded decision reasons reflect recorded telemetry from the gate evaluation loop.';
      container.appendChild(epistemicBox);

      // Card 2: Original Raw Case Record Payload
      const jsonCard = document.createElement('div');
      jsonCard.className = 'card';

      const jsonHeader = document.createElement('div');
      jsonHeader.className = 'card-header';
      jsonHeader.textContent = 'Original Raw Case JSON Payload';
      jsonCard.appendChild(jsonHeader);

      const pre = document.createElement('pre');
      pre.className = 'inspector-block';
      pre.setAttribute('tabindex', '0');
      pre.setAttribute('role', 'region');
      pre.setAttribute('aria-label', 'Original Raw Case JSON Payload');
      pre.textContent = JSON.stringify(c, null, 2);

      jsonCard.appendChild(pre);
      container.appendChild(jsonCard);
    },

    // -------------------------------------------------------------------------
    // Workbench Section 4: Methodology & Limitations
    // -------------------------------------------------------------------------
    renderMethodologyAndLimitations() {
      const data = this.state.benchmarkData || {};
      const ablData = data.ablation_table?.available ? data.ablation_table.data : null;

      const attrContainer = document.getElementById('attribution-container');
      if (attrContainer) {
        attrContainer.innerHTML = '';
        const attr = ablData?.attribution;

        if (attr && typeof attr === 'object' && Object.keys(attr).length > 0) {
          const ul = document.createElement('ul');
          ul.style.marginLeft = '1.25rem';
          ul.style.display = 'flex';
          ul.style.flexDirection = 'column';
          ul.style.gap = '0.45rem';

          Object.keys(attr).forEach(k => {
            const li = document.createElement('li');
            li.style.fontSize = '0.825rem';

            const strong = document.createElement('strong');
            strong.textContent = `${k.replace(/_/g, ' ')}: `;

            const span = document.createElement('span');
            span.textContent = String(attr[k]);

            li.appendChild(strong);
            li.appendChild(span);
            ul.appendChild(li);
          });
          attrContainer.appendChild(ul);
        } else {
          const p = document.createElement('p');
          p.className = 'text-muted';
          p.style.fontSize = '0.825rem';
          p.textContent = 'Documented interpretive takeaways unavailable in ablation table artifact.';
          attrContainer.appendChild(p);
        }
      }
    },

    // Helper method
    setText(id, text) {
      const el = document.getElementById(id);
      if (el) el.textContent = text;
    }
  };

  window.ObservatoryApp = ObservatoryApp;
  ObservatoryApp.init();
});
