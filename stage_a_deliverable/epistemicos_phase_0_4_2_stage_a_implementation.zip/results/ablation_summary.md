# EpistemicOS Empirical Evaluation Summary (N=100)

**Version:** 1.0.0 | **Seed:** 42 | **Evaluated Sample Size:** N = 100

## 1. Baseline Performance Comparison

> **Note on Metric Definitions:** Metrics consistently use rollback/security detection as the primary positive class: TP = True Rollback (TR), FP = False Rollback (FR), FN = False Commit (FC), TN = True Commit (TC). Precision = TR / (TR + FR), Recall = TR / (TR + FC), F1 = 2 × Precision × Recall / (Precision + Recall).

| Baseline Condition | Sample Count | Accuracy (95% CI) | Rollback Precision | Rollback Recall | F1 Score | Commit Precision | Commit Recall | FPR (Benign) | FNR (Security) | Avg Latency (ms) | Total Tokens |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **Ungated Generation** | 100 | 60.0% [50.2%, 69.06%] | 100.0% | 38.46% | 0.5556 | 46.67% | 100.0% | 0.0% | 61.54% | 24.334 ms | 2000 |
| **Entropy-Only Gating** | 100 | 90.0% [82.56%, 94.48%] | 100.0% | 84.62% | 0.9167 | 77.78% | 100.0% | 0.0% | 15.38% | 56.762 ms | 2000 |
| **Permission-Only Gating** | 100 | 100.0% [96.3%, 100.0%] | 100.0% | 100.0% | 1.0 | 100.0% | 100.0% | 0.0% | 0.0% | 76.758 ms | 2000 |
| **Combined Gating** | 100 | 100.0% [96.3%, 100.0%] | 100.0% | 100.0% | 1.0 | 100.0% | 100.0% | 0.0% | 0.0% | 95.354 ms | 2000 |
| **Active Execution-Gated Recovery** | 100 | 100.0% [96.3%, 100.0%] | 100.0% | 100.0% | 1.0 | 100.0% | 100.0% | 0.0% | 0.0% | 165.725 ms | 4600 |
| **Synthetic Token-Budget Control** | 100 | 60.0% [50.2%, 69.06%] | 100.0% | 38.46% | 0.5556 | 46.67% | 100.0% | 0.0% | 61.54% | 181.017 ms | 5000 |

## 2. Paired McNemar Inferential Comparisons (Exact Two-Tailed Binomial Test)

| Comparison | Method | Discordant A+/B- (b) | Discordant A-/B+ (c) | Total Discordant (b+c) | p-value | Significant (α=0.05) |
|---|---|---|---|---|---|---|
| Combined Gating vs Ungated Generation | exact_binomial | 40 | 0 | 40 | 1.8190e-12 | YES |
| Combined Gating vs Synthetic Token-Budget Control | exact_binomial | 40 | 0 | 40 | 1.8190e-12 | YES |
| Active Recovery vs Combined Gating | exact_binomial | 0 | 0 | 0 | 1.0 | NO |
| Permission-Only vs Ungated Generation | exact_binomial | 40 | 0 | 40 | 1.8190e-12 | YES |
| Entropy-Only vs Ungated Generation | exact_binomial | 30 | 0 | 30 | 1.8626e-09 | YES |

## 3. Scenario Family Breakdown (Combined Gating)

| Scenario Family | Cases | Accuracy (%) | Adversarial Recall (%) | Benign FPR (%) |
|---|---|---|---|---|
| Commercial Underwriting & Operations | 20 | 100.0% | N/A | 0.0% |
| Cyber, Shell & DB Threat Vectors | 15 | 100.0% | 100.0% | N/A |
| Multi-Turn & Obfuscated Prompt Injections | 15 | 100.0% | 100.0% | N/A |
| Impossible Paradoxes & Introspection | 15 | 100.0% | 100.0% | N/A |
| High-Noise Benign Controls | 15 | 100.0% | N/A | 0.0% |
| Unauthorized Operations & Boundary Failures | 10 | 100.0% | 100.0% | N/A |
| Gate Exceptions & Edge Cases | 10 | 100.0% | 100.0% | N/A |

## 4. Entropy Gate Threshold Ablation Study

| Z-Threshold | True Commit (TC) | False Commit (FC) | True Rollback (TR) | False Rollback (FR) | Rollback Precision (%) | Rollback Recall (%) | F1 Score |
|---|---|---|---|---|---|---|---|
| 1.0 | 20 | 10 | 55 | 15 | 78.57% | 84.62% | 0.8148 |
| 1.5 | 35 | 10 | 55 | 0 | 100.0% | 84.62% | 0.9167 |
| 2.0 | 35 | 10 | 55 | 0 | 100.0% | 84.62% | 0.9167 |
| 2.85 | 35 | 10 | 55 | 0 | 100.0% | 84.62% | 0.9167 |
